// ==================================================
// RCRA BI PORTAL - BACKGROUND SERVICE WORKER
// ==================================================

const DEFAULT_PORTAL_CONFIG = {
    defaultHomeUrl: 'https://app.powerbi.com/home',
    publicWorkspaceId: '8d966faa-0abd-4694-b3b0-be795b35ef5e',
    publicWorkspaceName: 'RCRA Public Workspace',
    workspaces: [
        { id: '8d966faa-0abd-4694-b3b0-be795b35ef5e', name: 'RCRA Public Workspace', autoExpandOnMatch: true }
    ],
    itemTypeFilters: ['Report', 'Exploration'],
    myWorkspaceItemTypeFilters: [],
    workspaceItemTypeFilters: {},
    syncPeriodMinutes: 5,
    minSyncIntervalMinutes: 2
};
const POWER_AUTOMATE_ENDPOINTS = {
    menuRead: 'https://default0598535e625d4d4386bb5240e2e61e.e0.environment.api.powerplatform.com/powerautomate/automations/direct/workflows/c3301adb467a48258ab89aaeacec8cac/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=9J9PtCDGfOG2-bAVZ3fPfrBX-mZcAMUyvUBAarZc1A4',
    settingsRead: 'https://default0598535e625d4d4386bb5240e2e61e.e0.environment.api.powerplatform.com/powerautomate/automations/direct/workflows/90213657f9244d52a47eef3c0b2f464b/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=TWEs94R0oSEDO7kXkZG4nBiFYyYdL1KcHhop92WRYvE'
};
let lastSyncStartedAt = 0;

async function getPortalConfig() {
    const stored = await chrome.storage.local.get('rcraPortalConfig');
    const config = { ...DEFAULT_PORTAL_CONFIG, ...(stored.rcraPortalConfig || {}) };
    config.itemTypeFilters = normalizeItemTypes(config.itemTypeFilters, DEFAULT_PORTAL_CONFIG.itemTypeFilters);
    config.myWorkspaceItemTypeFilters = normalizeItemTypes(config.myWorkspaceItemTypeFilters, null);
    config.workspaceItemTypeFilters = config.workspaceItemTypeFilters && typeof config.workspaceItemTypeFilters === 'object'
        ? config.workspaceItemTypeFilters
        : {};
    const configuredWorkspaces = Array.isArray(config.workspaces) ? config.workspaces : [];
    config.workspaces = configuredWorkspaces
        .map(ws => ({
            id: String(ws.id || '').trim(),
            name: String(ws.name || '').trim(),
            itemTypes: normalizeItemTypes(ws.itemTypes, null),
            autoExpandOnMatch: ws.autoExpandOnMatch !== false
        }))
        .filter(ws => /^[a-f0-9-]{36}$/i.test(ws.id));
    if (config.workspaces.length === 0 && /^[a-f0-9-]{36}$/i.test(config.publicWorkspaceId || '')) {
        config.workspaces = [{ id: config.publicWorkspaceId, name: config.publicWorkspaceName || 'Public Workspace', autoExpandOnMatch: true }];
    }
    config.publicWorkspaceId = config.workspaces[0]?.id || config.publicWorkspaceId;
    config.publicWorkspaceName = config.workspaces[0]?.name || config.publicWorkspaceName;
    return config;
}

function normalizeItemTypes(value, fallback = []) {
    const source = Array.isArray(value) ? value : String(value || '').split(',');
    const cleaned = [...new Set(source
        .map(type => String(type || '').trim())
        .filter(Boolean))];
    return cleaned.length > 0 ? cleaned : (Array.isArray(fallback) ? fallback : []);
}

function getWorkspaceItemTypes(config, workspace) {
    const workspaceOverride = normalizeItemTypes(workspace?.itemTypes, null);
    const legacyOverride = normalizeItemTypes(config.workspaceItemTypeFilters?.[workspace?.id], null);
    return workspaceOverride.length > 0 ? workspaceOverride : (legacyOverride.length > 0 ? legacyOverride : config.itemTypeFilters);
}

function getFabricItemType(item = {}) {
    return String(item.type || item.itemType || item.itemTypeName || item.typeName || item.kind || 'Report').trim();
}

function isHiddenUsageMetricsItem(item = {}) {
    const name = String(item.displayName || item.name || '').trim().toLowerCase();
    return name === 'report usage metrics report'
        || name === 'usage metrics report'
        || name === 'report usage metrics model'
        || name === 'usage metrics model';
}

function getPowerBiItemUrl(workspaceId, item) {
    const publishedUrl = item.webUrl || item.url || item.properties?.webUrl || item.properties?.url;
    if (typeof publishedUrl === 'string' && /^https:\/\//i.test(publishedUrl)) {
        return publishedUrl;
    }

    const workspaceRouteId = workspaceId === 'personal' ? 'me' : workspaceId;
    const type = getFabricItemType(item).toLowerCase();
    const routeMap = {
        dashboard: 'dashboards',
        exploration: 'explorations',
        paginatedreport: 'paginatedReports',
        report: 'reports',
        semanticmodel: 'datasets',
        dataset: 'datasets'
    };
    const segment = routeMap[type] || 'items';
    return `https://app.powerbi.com/groups/${workspaceRouteId}/${segment}/${item.id}`;
}

function getReportIdFromUrl(url = '') {
    const match = String(url).toLowerCase().match(/reports\/([a-f0-9-]{36})/);
    return match ? match[1] : null;
}

function getWorkspaceIdFromUrl(url = '') {
    const match = String(url).toLowerCase().match(/groups\/([a-f0-9-]{36}|me)\//);
    return match ? match[1] : null;
}

function getMenuArray(data) {
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.menu)) return data.menu;
    return [];
}

async function fetchPowerAutomateJson(url) {
    const res = await fetch(url, { method: 'GET', cache: 'no-store' });
    if (!res.ok) throw new Error(`Power Automate read failed: ${res.status}`);
    return await res.json();
}

function decodeJwtPayload(token) {
    try {
        const payload = String(token).split('.')[1];
        if (!payload) return {};
        const normalized = payload.replace(/-/g, '+').replace(/_/g, '/');
        const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
        return JSON.parse(atob(padded));
    } catch(e) {
        return {};
    }
}

async function storeUserEmailFromToken(token) {
    const claims = decodeJwtPayload(token);
    const email = claims.preferred_username || claims.upn || claims.email || claims.unique_name;
    if (email && String(email).includes('@')) {
        await chrome.storage.local.set({ rcraUserEmail: String(email).toLowerCase() });
    }
}

function getTokenGroupClaims(token) {
    const claims = decodeJwtPayload(token);
    const groups = Array.isArray(claims.groups) ? claims.groups : [];
    const roles = Array.isArray(claims.roles) ? claims.roles : [];
    const directoryRoles = Array.isArray(claims.wids) ? claims.wids : [];
    const hasGroupOverage =
        Boolean(claims.hasgroups) ||
        Boolean(claims._claim_names?.groups) ||
        Boolean(claims._claim_sources);

    return {
        groups,
        roles,
        directoryRoles,
        hasGroupOverage,
        user: claims.preferred_username || claims.upn || claims.email || claims.unique_name || '',
        tenantId: claims.tid || '',
        audience: claims.aud || '',
        issuer: claims.iss || ''
    };
}

async function getUserGroupsDiagnostic() {
    const stored = await chrome.storage.local.get(['pbiToken', 'fabricToken', 'rcraUserEmail']);
    const tokenResults = [];
    const allGroupIds = new Set();
    const allRoles = new Set();
    const allDirectoryRoles = new Set();
    let hasGroupOverage = false;

    [
        { source: 'powerbi_token', token: stored.pbiToken },
        { source: 'fabric_token', token: stored.fabricToken }
    ].forEach(({ source, token }) => {
        if (!token) return;
        const details = getTokenGroupClaims(token);
        details.groups.forEach(group => allGroupIds.add(group));
        details.roles.forEach(role => allRoles.add(role));
        details.directoryRoles.forEach(role => allDirectoryRoles.add(role));
        hasGroupOverage = hasGroupOverage || details.hasGroupOverage;
        tokenResults.push({
            source,
            user: details.user,
            tenantId: details.tenantId,
            audience: details.audience,
            issuer: details.issuer,
            groupCount: details.groups.length,
            roleCount: details.roles.length,
            directoryRoleCount: details.directoryRoles.length,
            hasGroupOverage: details.hasGroupOverage
        });
    });

    return {
        email: stored.rcraUserEmail || '',
        groups: Array.from(allGroupIds),
        roles: Array.from(allRoles),
        directoryRoles: Array.from(allDirectoryRoles),
        hasGroupOverage,
        tokenResults,
        source: 'token_claims',
        note: tokenResults.length
            ? 'This reads group/role claims from captured Power BI/Fabric tokens. If groups is empty, the token did not include Entra group claims. A full group lookup would require Microsoft Graph permissions/consent.'
            : 'No Power BI/Fabric token has been captured yet. Open Power BI first, then try Fetch User Identity and Fetch My Groups again.'
    };
}

async function setSyncStatus(status) {
    await chrome.storage.local.set({
        rcraSyncStatus: {
            ...status,
            timestamp: new Date().toISOString()
        }
    });
}

async function isReportBuildAllowed(sourceWorkspaceId, reportId) {
    const requestedReportId = String(reportId || '').toLowerCase();
    if (!/^[a-f0-9-]{36}$/.test(requestedReportId)) return false;

    const stored = await chrome.storage.local.get('cachedMenu');
    const stack = [...getMenuArray(stored.cachedMenu)];

    while (stack.length > 0) {
        const item = stack.pop();
        if (!item) continue;
        if (Array.isArray(item.items)) stack.push(...item.items);
        if (!item.url) continue;

        const menuReportId = getReportIdFromUrl(item.url);
        if (menuReportId !== requestedReportId) continue;

        const menuWorkspaceId = getWorkspaceIdFromUrl(item.url);
        const source = String(sourceWorkspaceId || '').toLowerCase();
        const workspaceMatches = !menuWorkspaceId || menuWorkspaceId === source || (menuWorkspaceId === 'me' && source === 'personal');

        if (workspaceMatches && (item.allowBuild === true || item.allowBuild === "true")) {
            return true;
        }
    }

    return false;
}

// ==========================================
// 1. HELPER: DYNAMIC HOME URL
// ==========================================
async function getDynamicHomeUrl() {
  try {
    const config = await getPortalConfig();
    const stored = await chrome.storage.local.get('cachedMenu');
    let data = stored.cachedMenu;
    if (!data || data.length === 0) {
       data = await fetchPowerAutomateJson(POWER_AUTOMATE_ENDPOINTS.menuRead);
       await chrome.storage.local.set({ cachedMenu: data });
    }
    let menuArray = getMenuArray(data);
    const findFirstLink = (items) => {
        for (const item of items) {
            if (item.url && item.url !== "#") return item.url;
            if (item.items && item.items.length > 0) {
                const found = findFirstLink(item.items);
                if (found) return found;
            }
        }
        return null;
    };
    const firstUrl = findFirstLink(menuArray);
    if (firstUrl) {
         if (!firstUrl.startsWith('http') && !firstUrl.startsWith('//')) return config.defaultHomeUrl; 
         return firstUrl;
    }
  } catch (e) { console.warn("Failed dynamic home", e); }
  const config = await getPortalConfig();
  return config.defaultHomeUrl;
}

// ==========================================
// 2. FABRIC API: MY WORKSPACE SYNC
// ==========================================
let isSyncing = false; 

async function syncFabricWorkspace(force = false) {
    if (isSyncing) return;
    const config = await getPortalConfig();
    const minSyncIntervalMs = Math.max(1, Number(config.minSyncIntervalMinutes) || 2) * 60 * 1000;
    if (!force && Date.now() - lastSyncStartedAt < minSyncIntervalMs) return;
    lastSyncStartedAt = Date.now();
    isSyncing = true;
    
    try {
        await setSyncStatus({ state: 'syncing' });
        const data = await chrome.storage.local.get(['fabricToken', 'pbiToken']);
        const token = data.fabricToken || data.pbiToken;
        if (!token) {
            await setSyncStatus({ state: 'waiting_for_token' });
            return;
        }

        const headers = { 'Authorization': `Bearer ${token}` };

        async function fetchWorkspaceData(wsId, itemTypes = config.itemTypeFilters) {
            const normalizedTypes = normalizeItemTypes(itemTypes, config.itemTypeFilters);
            const shouldFetchAll = normalizedTypes.length === 0 || normalizedTypes.some(type => type === '*' || type.toLowerCase() === 'all');
            const itemUrls = shouldFetchAll
                ? [`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/items`]
                : normalizedTypes.map(type => `https://api.fabric.microsoft.com/v1/workspaces/${wsId}/items?type=${encodeURIComponent(type)}`);
            const [foldersRes, ...itemResponses] = await Promise.all([
                fetch(`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/folders`, { headers }),
                ...itemUrls.map(url => fetch(url, { headers }))
            ]);

            if (!foldersRes.ok || itemResponses.some(res => !res.ok)) throw new Error(`API Sync Failed for ${wsId}`);

            const foldersData = await foldersRes.json();
            const itemPayloads = await Promise.all(itemResponses.map(res => res.json()));
            const workspaceItems = itemPayloads.flatMap(payload => payload.value || []);

            const folderMap = {};
            const rootNodes = [];

            (foldersData.value || []).forEach(f => {
                folderMap[f.id] = { name: f.displayName, category: f.displayName, items: [], id: f.id, parentId: f.parentFolderId, _isWorkspaceFolder: true, _expanded: false };
            });

            const seenItems = new Set();
            workspaceItems.forEach(r => {
                // Ignore Microsoft's hidden auto-generated usage metrics artifacts.
                if (isHiddenUsageMetricsItem(r)) {
                    return; 
                }

                const itemType = getFabricItemType(r);
                const itemId = r.id || r.itemId || r.objectId || '';
                const itemKey = `${itemType.toLowerCase()}:${itemId || r.displayName || r.name || ''}`;
                if (seenItems.has(itemKey)) return;
                seenItems.add(itemKey);

                const reportItem = {
                    name: r.displayName || r.name || 'Untitled Item',
                    url: getPowerBiItemUrl(wsId, r),
                    linkType: itemType.toLowerCase() === 'report' ? 'report' : itemType.toLowerCase(),
                    itemType,
                    _isWorkspaceItem: true
                };
                if (r.folderId && folderMap[r.folderId]) folderMap[r.folderId].items.push(reportItem);
                else rootNodes.push(reportItem);
            });

            Object.values(folderMap).forEach(f => {
                const parentId = f.parentId;
                delete f.id; delete f.parentId;
                if (parentId && folderMap[parentId]) folderMap[parentId].items.push(f);
                else rootNodes.push(f);
            });

            function sortTree(nodes) {
                nodes.sort((a, b) => {
                    const aIsFolder = Array.isArray(a.items);
                    const bIsFolder = Array.isArray(b.items);
                    if (aIsFolder !== bIsFolder) return aIsFolder ? -1 : 1;
                    const aName = (a.name || a.category || "").toLowerCase();
                    const bName = (b.name || b.category || "").toLowerCase();
                    return aName.localeCompare(bName);
                });
                nodes.forEach(n => { if (n.items) sortTree(n.items); });
            }
            sortTree(rootNodes);
            return rootNodes;
        }

        const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers });
        if (!wsRes.ok) throw new Error(`Fabric API rejected token.`);
        const wsData = await wsRes.json();
        const personalWs = wsData.value.find(ws => ws.type === 'Personal');

        let updates = {};
        const errors = [];
        if (personalWs) {
            const personalTypes = config.myWorkspaceItemTypeFilters.length > 0 ? config.myWorkspaceItemTypeFilters : config.itemTypeFilters;
            try { updates.rcraMyWorkspace = await fetchWorkspaceData(personalWs.id, personalTypes); } catch(e) { errors.push(`My Workspace: ${e.message}`); }
        }

        await new Promise(resolve => setTimeout(resolve, 300));

        const workspaceMap = {};
        for (const workspace of config.workspaces) {
            try {
                workspaceMap[workspace.id] = await fetchWorkspaceData(workspace.id, getWorkspaceItemTypes(config, workspace));
                await new Promise(resolve => setTimeout(resolve, 150));
            } catch (e) {
                errors.push(`${workspace.name || workspace.id}: ${e.message}`);
            }
        }
        updates.rcraWorkspaceData = workspaceMap;
        if (config.publicWorkspaceId && workspaceMap[config.publicWorkspaceId]) {
            updates.rcraPublicWorkspace = workspaceMap[config.publicWorkspaceId];
        }

        if (Object.keys(updates).length > 0) {
            await chrome.storage.local.set(updates);
        }
        await setSyncStatus({
            state: errors.length > 0 ? 'partial' : 'ok',
            errors
        });

    } catch (error) {
        console.error("RCRA Sync Error:", error.message);
        await setSyncStatus({ state: 'error', errors: [error.message] });
    } finally {
        isSyncing = false; 
    }
}

getPortalConfig().then(config => {
    chrome.alarms.create("syncFabricData", { periodInMinutes: Math.max(1, Number(config.syncPeriodMinutes) || 5) });
});
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "syncFabricData") syncFabricWorkspace();
});

// ==========================================
// 3. LISTENER: MESSAGE BUS (Tokens & API)
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    if (request.action === 'RCRA_FABRIC_TOKEN' && request.token) {
        if (typeof request.token !== 'string' || request.token.length < 100) return;
        storeUserEmailFromToken(request.token);
        chrome.storage.local.get('fabricToken', (data) => {
            if (data.fabricToken !== request.token) {
                chrome.storage.local.set({ fabricToken: request.token }, () => syncFabricWorkspace(true));
            }
        });
    }

    if (request.action === 'RCRA_PBI_TOKEN' && request.token) {
        if (typeof request.token !== 'string' || request.token.length < 100) return;
        storeUserEmailFromToken(request.token);
        chrome.storage.local.get('pbiToken', (data) => {
            if (data.pbiToken !== request.token) {
                chrome.storage.local.set({ pbiToken: request.token }, () => syncFabricWorkspace(true));
            }
        });
    }
    
    if (request.action === 'FORCE_SYNC') syncFabricWorkspace(true);

    if (request.action === 'GET_USER_IDENTITY') {
        chrome.storage.local.get('rcraUserEmail', (stored) => {
            if (stored.rcraUserEmail) {
                sendResponse({ email: stored.rcraUserEmail, source: 'powerbi_token' });
                return;
            }
            chrome.identity.getProfileUserInfo((userInfo) => {
                const email = (userInfo.email || "").toLowerCase();
                if (email) chrome.storage.local.set({ rcraUserEmail: email });
                sendResponse({ email, source: email ? 'chrome_identity' : 'none' });
            });
        });
        return true; 
    }

    if (request.action === 'GET_USER_GROUPS') {
        getUserGroupsDiagnostic()
            .then(result => sendResponse({ success: true, ...result }))
            .catch(error => sendResponse({ success: false, error: error.message || String(error) }));
        return true;
    }

    if (request.action === 'GET_PORTAL_CONFIG') {
        getPortalConfig().then(config => sendResponse({ success: true, config }));
        return true;
    }

    if (request.action === 'SAVE_PORTAL_CONFIG') {
        getPortalConfig().then(async currentConfig => {
            const nextConfig = { ...currentConfig, ...(request.config || {}) };
            await chrome.storage.local.set({
                rcraPortalConfig: nextConfig,
                rcraMenuFetchedAt: 0
            });
            chrome.alarms.create("syncFabricData", { periodInMinutes: Math.max(1, Number(nextConfig.syncPeriodMinutes) || 5) });
            sendResponse({ success: true, config: nextConfig });
        }).catch(error => sendResponse({ success: false, error: error.message }));
        return true;
    }

    // --- Fetch Folders for UI ---
    if (request.action === 'GET_FOLDERS') {
        chrome.storage.local.get(['fabricToken', 'pbiToken'], async (data) => {
            const token = data.fabricToken || data.pbiToken;
            if (!token) return sendResponse({ success: false, error: "Missing Authentication Token. Please refresh the page." });
            
            try {
                let targetWsId = request.workspaceId;
                if (targetWsId === "personal") {
                    const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers: { 'Authorization': `Bearer ${token}` } });
                    if (!wsRes.ok) return sendResponse({ success: false, error: `Failed to locate Personal Workspace (Status: ${wsRes.status})` });
                    const wsData = await wsRes.json();
                    const personalWs = wsData.value.find(ws => ws.type === 'Personal');
                    if (personalWs) targetWsId = personalWs.id;
                }

                const res = await fetch(`https://api.fabric.microsoft.com/v1/workspaces/${targetWsId}/folders`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                
                if (res.ok) {
                    const json = await res.json();
                    sendResponse({ success: true, folders: json.value || [] });
                } else {
                    const errData = await res.json().catch(() => ({}));
                    const exactError = errData.error?.message || errData.message || `HTTP Status ${res.status}`;
                    sendResponse({ success: false, error: exactError });
                }
            } catch(e) {
                sendResponse({ success: false, error: e.message });
            }
        });
        return true;
    }

    // --- Create Folder ---
    if (request.action === 'CREATE_FOLDER') {
        chrome.storage.local.get(['fabricToken', 'pbiToken'], async (data) => {
            const token = data.fabricToken || data.pbiToken;
            if (!token) return sendResponse({ success: false, error: "Missing Authentication Token. Please refresh the page." });
            
            try {
                let targetWsId = request.workspaceId;
                if (targetWsId === "personal") {
                    const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers: { 'Authorization': `Bearer ${token}` } });
                    const wsData = await wsRes.json();
                    const personalWs = wsData.value.find(ws => ws.type === 'Personal');
                    if (personalWs) targetWsId = personalWs.id;
                }

                // Add parentFolderId to payload if we are nesting
                const payload = { displayName: request.folderName };
                if (request.parentFolderId) {
                    payload.parentFolderId = request.parentFolderId;
                }

                const res = await fetch(`https://api.fabric.microsoft.com/v1/workspaces/${targetWsId}/folders`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                
                if (res.ok) {
                    sendResponse({ success: true });
                    syncFabricWorkspace(); 
                } else {
                    const err = await res.json();
                    sendResponse({ success: false, error: err.error?.message || "Creation Failed" });
                }
            } catch(e) {
                sendResponse({ success: false, error: e.message });
            }
        });
        return true;
    }

    // --- Clone & Move Report Execution ---
    if (request.action === 'CLONE_REPORT') {
        chrome.storage.local.get(['fabricToken', 'pbiToken'], async (data) => {
            const pbiToken = data.pbiToken || data.fabricToken;
            const fabricToken = data.fabricToken || data.pbiToken;
            
            if (!pbiToken) {
                sendResponse({ success: false, error: "Authentication missing. Try interacting with the report, then try again." });
                return;
            }

            const validGuid = /^[a-f0-9-]{36}$/i;
            if (!validGuid.test(request.sourceWorkspaceId || '') || !validGuid.test(request.reportId || '')) {
                sendResponse({ success: false, error: "Invalid source report request." });
                return;
            }
            if (request.targetId !== "personal" && !validGuid.test(request.targetId || '')) {
                sendResponse({ success: false, error: "Invalid target workspace request." });
                return;
            }
            if (request.folderId && !validGuid.test(request.folderId)) {
                sendResponse({ success: false, error: "Invalid target folder request." });
                return;
            }

            if (!await isReportBuildAllowed(request.sourceWorkspaceId, request.reportId)) {
                sendResponse({ success: false, error: "This report is not approved for Save a Copy." });
                return;
            }

            const apiUrl = `https://api.powerbi.com/v1.0/myorg/groups/${request.sourceWorkspaceId}/reports/${request.reportId}/Clone`;
            const bodyPayload = { name: request.newName };
            
            let realWorkspaceId = request.targetId;
            
            if (request.targetId === "personal") {
                bodyPayload.targetWorkspaceId = "00000000-0000-0000-0000-000000000000";
                try {
                    const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers: { 'Authorization': `Bearer ${fabricToken}` } });
                    if (wsRes.ok) {
                        const wsData = await wsRes.json();
                        const personalWs = wsData.value.find(ws => ws.type === 'Personal');
                        if (personalWs) realWorkspaceId = personalWs.id;
                    }
                } catch(e) { console.warn("Failed to lookup personal workspace GUID", e); }
            } else {
                bodyPayload.targetWorkspaceId = request.targetId;
            }

            try {
                // 1. Fire the Clone to the Workspace Root
                const res = await fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${pbiToken}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify(bodyPayload)
                });

                if (res.ok) {
                    const clonedData = await res.json();
                    const newReportId = clonedData.id;
                    const reportUrl = clonedData.webUrl || `https://app.powerbi.com/groups/${request.targetId === 'personal' ? 'me' : request.targetId}/reports/${newReportId}`;
                    
                    // 2. If a folder was selected, use Fabric API to Move the item
                    if (request.folderId && realWorkspaceId && realWorkspaceId !== "personal") {
                        const moveUrl = `https://api.fabric.microsoft.com/v1/workspaces/${realWorkspaceId}/items/${newReportId}/move`;
                        const moveRes = await fetch(moveUrl, {
                            method: 'POST',
                            headers: { 'Authorization': `Bearer ${fabricToken}`, 'Content-Type': 'application/json' },
                            body: JSON.stringify({ targetFolderId: request.folderId })
                        });
                        
                        if (!moveRes.ok) console.warn("Clone succeeded, but folder move failed.");
                    }

                    sendResponse({ success: true, url: reportUrl });
                } else {
                    const err = await res.json();
                    sendResponse({ success: false, error: err.error?.message || "Unknown permissions error." });
                }
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        });
        return true; 
    }
});

// ==========================================
// 4. BROWSER LISTENERS
// ==========================================
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const targetUrl = await getDynamicHomeUrl();
    chrome.tabs.create({ url: targetUrl });
    chrome.storage.local.set({ isSidebarOpen: true });
    syncFabricWorkspace(); 
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url.includes("app.powerbi.com")) return;
  const data = await chrome.storage.local.get('isSidebarOpen');
  const newState = !data.isSidebarOpen;
  await chrome.storage.local.set({ isSidebarOpen: newState });

  if (newState) {
    syncFabricWorkspace();
    const homeUrl = await getDynamicHomeUrl();
    const currentClean = tab.url.toLowerCase().replace(/\/$/, "");
    const homeClean = homeUrl.toLowerCase().replace(/\/$/, "");
    
    if (!currentClean.includes(homeClean)) await chrome.tabs.update(tab.id, { url: homeUrl });
    else {
        try { await chrome.tabs.sendMessage(tab.id, { action: 'OPEN_SIDEBAR' }); } 
        catch (err) { injectSidebar(tab.id); }
    }
  } else {
    try { await chrome.tabs.sendMessage(tab.id, { action: 'REMOVE_SIDEBAR' }); } catch (err) { }
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading') {
    const data = await chrome.storage.local.get('isSidebarOpen');
    if (data.isSidebarOpen && tab.url && tab.url.startsWith('https://app.powerbi.com/')) {
        syncFabricWorkspace();
        injectSidebar(tabId);
    }
  }
});

function injectSidebar(tabId) {
    chrome.scripting.executeScript({ target: { tabId: tabId }, files: ['interceptor.js'], world: 'MAIN' }).catch(() => {});
    chrome.scripting.executeScript({ target: { tabId: tabId }, files: ['content.js'] }).catch(() => {});
}
