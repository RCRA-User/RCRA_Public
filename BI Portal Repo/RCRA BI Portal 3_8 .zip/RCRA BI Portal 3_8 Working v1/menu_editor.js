// ==========================================
// RCRA MENU EDITOR - MAIN LOGIC
// ==========================================

// Global State
let rootData = [];
let settingsData = {
    portalName: "RCRA BI Portal",
    defaultSide: "left",
    showLayoutBtns: true,
    welcomeTitle: "👋 Welcome!",
    welcomeDesc: "RCRA BI Portal Extension",
    welcomeSteps: [], 
    customCss: ""
};

let selectedPath = null;
let currentMenuSha = null;
let currentSettingsSha = null;
let dragSrcPath = null; 

// --- INIT ---
document.addEventListener('DOMContentLoaded', () => {
    console.log("Admin Editor Loaded");

    const owner = localStorage.getItem('gh_owner');
    const repo = localStorage.getItem('gh_repo');
    const path = localStorage.getItem('gh_path');
    const settingsPath = localStorage.getItem('gh_settings_path') || 'settings.json';
    const token = localStorage.getItem('gh_token');

    if(owner) document.getElementById('gh-owner').value = owner;
    if(repo) document.getElementById('gh-repo').value = repo;
    if(path) document.getElementById('gh-path').value = path;
    if(settingsPath) document.getElementById('gh-settings-path').value = settingsPath;
    if(token) document.getElementById('gh-token').value = token;

    document.getElementById('btn-save-creds').addEventListener('click', saveCreds);
    document.getElementById('btn-load').addEventListener('click', loadFromCloud);
    document.getElementById('btn-publish').addEventListener('click', publishToCloud);
    
    document.getElementById('btn-add-root').addEventListener('click', () => addItem(true));
    document.getElementById('btn-update').addEventListener('click', updateItem);
    document.getElementById('btn-delete').addEventListener('click', deleteItem);
    document.getElementById('inp-type').addEventListener('change', toggleUI);
    document.getElementById('btn-add-sub-folder').addEventListener('click', () => addItem(false, 'folder'));
    document.getElementById('btn-add-sub-link').addEventListener('click', () => addItem(false, 'report'));
    document.getElementById('btn-up').addEventListener('click', () => moveItem(-1));
    document.getElementById('btn-down').addEventListener('click', () => moveItem(1));

    document.getElementById('btn-save-global').addEventListener('click', saveGlobalSettings);
    
    document.getElementById('btn-add-step').addEventListener('click', () => {
        saveWelcomeStepsToData(); 
        settingsData.welcomeSteps = settingsData.welcomeSteps || [];
        settingsData.welcomeSteps.push({ icon: "📌", title: "New Step", text: "Description here..." });
        renderWelcomeSteps();
    });

    document.getElementById('btn-test-identity').addEventListener('click', testIdentity);

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            e.target.classList.add('active');
            document.getElementById(e.target.getAttribute('data-target')).classList.add('active');
        });
    });

    if (token && owner && repo) {
        loadFromCloud();
    } else {
        toast("System Ready - Please set GitHub Credentials");
    }
});

// ==========================================
// TABS & GLOBAL SETTINGS LOGIC
// ==========================================
function populateGlobalSettingsUI() {
    document.getElementById('set-portal-name').value = settingsData.portalName || "RCRA BI Portal";
    document.getElementById('set-default-side').value = settingsData.defaultSide || "left";
    document.getElementById('set-show-layout').checked = settingsData.showLayoutBtns !== false;
    document.getElementById('set-welcome-title').value = settingsData.welcomeTitle || "👋 Welcome!";
    document.getElementById('set-welcome-desc').value = settingsData.welcomeDesc || "RCRA BI Portal Extension";
    document.getElementById('set-custom-css').value = settingsData.customCss || "";
    
    renderWelcomeSteps();
}

function renderWelcomeSteps() {
    const list = document.getElementById('welcome-steps-list');
    list.innerHTML = '';
    
    if (!settingsData.welcomeSteps || settingsData.welcomeSteps.length === 0) {
        settingsData.welcomeSteps = [
            { icon: "⭐", title: "Bookmark this Page!", text: "Press <b>Ctrl + D</b> (or Cmd + D) to save this page so you can easily return to the portal later." },
            { icon: "⬅️", title: "Use the Sidebar", text: "The menu lives on the left.<br><br> Click the <b>Star Icon</b> at the top to <b>Minimize/Maximize</b> the menu." }
        ];
    }

    settingsData.welcomeSteps.forEach((step, index) => {
        const div = document.createElement('div');
        div.style.background = "#1a1a20";
        div.style.border = "1px solid #444";
        div.style.padding = "10px";
        div.style.borderRadius = "6px";
        div.style.display = "flex";
        div.style.gap = "10px";

        div.innerHTML = `
            <div style="width: 50px;">
                <input type="text" class="step-icon" value="${step.icon}" placeholder="Emoji" style="text-align:center; font-size: 18px; padding: 8px;">
            </div>
            <div style="flex: 1; display: flex; flex-direction: column; gap: 5px;">
                <input type="text" class="step-title" value="${step.title}" placeholder="Step Title">
                <textarea class="step-text" style="min-height: 40px;" placeholder="HTML allowed (e.g. <b>bold</b> or <br>)">${step.text}</textarea>
            </div>
            <div>
                <button class="btn btn-danger btn-remove-step" data-idx="${index}">X</button>
            </div>
        `;
        list.appendChild(div);
    });

    document.querySelectorAll('.btn-remove-step').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const idx = parseInt(e.target.getAttribute('data-idx'));
            saveWelcomeStepsToData(); 
            settingsData.welcomeSteps.splice(idx, 1);
            renderWelcomeSteps();
        });
    });
}

function saveWelcomeStepsToData() {
    const list = document.getElementById('welcome-steps-list');
    const items = list.children;
    const newSteps = [];
    for (let i = 0; i < items.length; i++) {
        newSteps.push({
            icon: items[i].querySelector('.step-icon').value,
            title: items[i].querySelector('.step-title').value,
            text: items[i].querySelector('.step-text').value
        });
    }
    settingsData.welcomeSteps = newSteps;
}

function saveGlobalSettings() {
    settingsData.portalName = document.getElementById('set-portal-name').value;
    settingsData.defaultSide = document.getElementById('set-default-side').value;
    settingsData.showLayoutBtns = document.getElementById('set-show-layout').checked;
    settingsData.welcomeTitle = document.getElementById('set-welcome-title').value;
    settingsData.welcomeDesc = document.getElementById('set-welcome-desc').value;
    settingsData.customCss = document.getElementById('set-custom-css').value;
    
    saveWelcomeStepsToData(); 
    toast("Global Settings Saved to Memory (Don't forget to Publish!)");
}

function testIdentity() {
    const out = document.getElementById('dev-output');
    out.innerText = "Requesting identity from background script...";
    
    if (chrome && chrome.runtime) {
        chrome.runtime.sendMessage({ action: 'GET_USER_IDENTITY' }, (response) => {
            if (chrome.runtime.lastError) {
                out.innerText = "Error: " + chrome.runtime.lastError.message;
            } else {
                out.innerText = "Success!\n\n" + JSON.stringify(response, null, 2);
            }
        });
    } else {
        out.innerText = "Error: Extension APIs not available. Are you running this packed?";
    }
}


// ==========================================
// GITHUB ACTIONS
// ==========================================
async function saveCreds() {
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const path = document.getElementById('gh-path').value.trim();
    const settingsPath = document.getElementById('gh-settings-path').value.trim();
    const token = document.getElementById('gh-token').value.trim();
    
    localStorage.setItem('gh_owner', owner);
    localStorage.setItem('gh_repo', repo);
    localStorage.setItem('gh_path', path);
    localStorage.setItem('gh_settings_path', settingsPath);
    localStorage.setItem('gh_token', token);

    const statusEl = document.getElementById('gh-status');
    statusEl.innerHTML = '⏳ Testing Connection...';
    statusEl.className = 'status-msg active';
    
    if(!token || !owner || !repo) {
        statusEl.innerHTML = '❌ Missing Fields';
        statusEl.classList.add('error');
        return;
    }

    try {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
        const res = await fetch(url + '?t=' + new Date().getTime(), { 
            method: 'GET',
            headers: { Authorization: `token ${token}` } 
        });
        
        if(res.ok) {
            statusEl.innerHTML = '✅ Connection Verified!';
            statusEl.classList.add('success');
            setTimeout(() => {
               document.getElementById('details-settings').removeAttribute('open');
               statusEl.classList.remove('active');
            }, 1500);

            if (rootData.length === 0) loadFromCloud();
            else toast("Credentials Saved & Verified");
        } else {
            throw new Error(`GitHub Error: ${res.status} (${res.statusText})`);
        }
    } catch(e) {
        statusEl.innerHTML = `❌ Failed: ${e.message}`;
        statusEl.classList.add('error');
    }
}

async function loadFromCloud() {
    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const menuPath = document.getElementById('gh-path').value.trim();
    const settingsPath = document.getElementById('gh-settings-path').value.trim();

    if(!token || !owner) return toast("⚠️ Check Settings");

    toast("⏳ Loading Files...");
    
    const fetchGithubFile = async (filePath) => {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`;
        const res = await fetch(url + '?t=' + new Date().getTime(), { 
            headers: { Authorization: `token ${token}` } 
        });
        if (!res.ok) return null;
        return await res.json();
    };

    try {
        const [menuData, settingsResData] = await Promise.all([
            fetchGithubFile(menuPath),
            fetchGithubFile(settingsPath)
        ]);

        if (!menuData) throw new Error("Could not load Menu file.");
        
        currentMenuSha = menuData.sha;
        const menuJsonStr = decodeURIComponent(escape(window.atob(menuData.content)));
        const parsedMenu = JSON.parse(menuJsonStr);
        
        if (Array.isArray(parsedMenu)) {
            rootData = parsedMenu;
        } else if (parsedMenu.menu) {
            rootData = parsedMenu.menu;
            if (!settingsResData && parsedMenu.settings) {
                settingsData = parsedMenu.settings; 
            }
        }

        if (settingsResData) {
            currentSettingsSha = settingsResData.sha;
            const settingsJsonStr = decodeURIComponent(escape(window.atob(settingsResData.content)));
            const parsedSettings = JSON.parse(settingsJsonStr);
            settingsData = { ...settingsData, ...parsedSettings };
        } else {
            console.log("Settings file not found. A new one will be created on publish.");
            currentSettingsSha = null; 
        }
        
        populateGlobalSettingsUI();
        renderTree();
        toast("✅ Loaded Both Files");
        
        document.getElementById('editor-ui').style.display = 'none';
        document.getElementById('empty-msg').style.display = 'flex';

    } catch(e) {
        alert("Load Error: " + e.message);
    }
}

async function publishToCloud() {
    if(!currentMenuSha) return alert("You must LOAD first before publishing.");
    if(!confirm("Publish changes live to Power BI users?")) return;

    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const menuPath = document.getElementById('gh-path').value.trim();
    const settingsPath = document.getElementById('gh-settings-path').value.trim();

    toast("⏳ Publishing...");
    
    const cleanData = (items) => {
        return items.map(item => {
            const newItem = { ...item };
            delete newItem._expanded; 
            delete newItem._moveId;
            if (newItem.items) {
                newItem.items = cleanData(newItem.items);
            }
            return newItem;
        });
    };

    const finalMenuArray = cleanData(rootData);

    const pushFile = async (filePath, contentObj, fileSha) => {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`;
        const contentStr = JSON.stringify(contentObj, null, 2);
        const encoded = window.btoa(unescape(encodeURIComponent(contentStr)));

        const payload = { message: "Update via Admin Tool", content: encoded };
        if (fileSha) payload.sha = fileSha;

        const res = await fetch(url, {
            method: 'PUT',
            headers: { Authorization: `token ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        if(!res.ok) throw new Error(res.statusText);
        return await res.json();
    };

    try {
        const menuResult = await pushFile(menuPath, finalMenuArray, currentMenuSha);
        currentMenuSha = menuResult.content.sha;

        const settingsResult = await pushFile(settingsPath, settingsData, currentSettingsSha);
        currentSettingsSha = settingsResult.content.sha;

        toast("🚀 Published Both Files Successfully!");
    } catch(e) {
        alert("Publish Error: " + e.message);
    }
}

// ==========================================
// TREE RENDERER
// ==========================================
function renderTree() {
    const container = document.getElementById('tree-root');
    container.innerHTML = '';

    function buildNode(item, path) {
        const wrapper = document.createElement('div');
        if (item._expanded) wrapper.className = 'expanded';

        const nodeDiv = document.createElement('div');
        const isSel = selectedPath && JSON.stringify(path) === JSON.stringify(selectedPath);
        const isFolder = item.items !== undefined || item.type === 'workspace';
        const hasKids = isFolder && item.items && item.items.length > 0;

        let classes = 'node ' + (isSel ? 'selected' : '');
        if (item.inDevelopment === true) classes += ' dev-flag';
        nodeDiv.className = classes;
        nodeDiv.draggable = true;
        
        if (item.isHidden) nodeDiv.style.opacity = '0.4';
        
        const label = item.category || item.name || 'Untitled';
        
        const arrowSpan = document.createElement('span');
        arrowSpan.className = 'toggle-icon';
        arrowSpan.style.pointerEvents = 'auto'; 
        arrowSpan.style.marginRight = '5px';
        
        if (isFolder && item.type !== 'workspace') {
            arrowSpan.innerText = item._expanded ? '▼' : '▶'; 
            arrowSpan.onclick = (e) => {
                e.stopPropagation(); 
                item._expanded = !item._expanded;
                if (item._expanded) {
                    wrapper.classList.add('expanded');
                    arrowSpan.innerText = '▼';
                } else {
                    wrapper.classList.remove('expanded');
                    arrowSpan.innerText = '▶';
                }
            };
        } else {
            arrowSpan.innerText = ''; 
        }

        let iconChar = '🔗';
        if (item.type === 'workspace') iconChar = '☁️';
        else if (isFolder) iconChar = '📁';
        else if (item.linkType === 'excel') iconChar = '📗';
        
        if (item.inDevelopment === true) iconChar = '🚧 ' + iconChar;

        const textSpan = document.createElement('span');
        textSpan.innerText = `${iconChar} ${label}`;
        
        if (isFolder && item.color) {
            textSpan.style.color = item.color;
        }

        nodeDiv.appendChild(arrowSpan);
        nodeDiv.appendChild(textSpan);

        if (isFolder && item.type !== 'workspace') {
            const actionsDiv = document.createElement('div');
            actionsDiv.className = 'node-actions';
            
            const plusBtn = document.createElement('div');
            plusBtn.className = 'action-btn btn-plus';
            plusBtn.title = "Add Child Item";
            
            const expandGroup = document.createElement('div');
            expandGroup.style.display = 'none';
            expandGroup.style.gap = '4px';

            const addLinkBtn = document.createElement('div');
            addLinkBtn.className = 'action-btn btn-add-link';
            addLinkBtn.title = "Add Link";
            
            const addFolderBtn = document.createElement('div');
            addFolderBtn.className = 'action-btn btn-add-folder';
            addFolderBtn.title = "Add Folder";

            plusBtn.onclick = (e) => {
                e.stopPropagation();
                plusBtn.style.display = 'none';
                expandGroup.style.display = 'flex';
                expandGroup.classList.add('actions-expanded');
                actionsDiv.classList.add('active'); 
            };

            addLinkBtn.onclick = (e) => { e.stopPropagation(); addItemToPath(path, 'report'); };
            addFolderBtn.onclick = (e) => { e.stopPropagation(); addItemToPath(path, 'folder'); };

            expandGroup.appendChild(addFolderBtn);
            expandGroup.appendChild(addLinkBtn);
            actionsDiv.appendChild(plusBtn);
            actionsDiv.appendChild(expandGroup);

            nodeDiv.addEventListener('mouseleave', () => {
                plusBtn.style.display = 'flex';
                expandGroup.style.display = 'none';
                actionsDiv.classList.remove('active');
            });
            nodeDiv.appendChild(actionsDiv);
        }

        nodeDiv.addEventListener('click', (e) => { e.stopPropagation(); select(path); });

        // --- DRAG EVENTS ---
        nodeDiv.addEventListener('dragstart', (e) => {
            e.stopPropagation(); dragSrcPath = path; e.dataTransfer.effectAllowed = 'move';
            nodeDiv.style.opacity = '0.5';
        });

        nodeDiv.addEventListener('dragend', () => { 
            nodeDiv.style.opacity = item.isHidden ? '0.4' : '1'; 
            clearDragClasses(); 
        });

        nodeDiv.addEventListener('dragover', (e) => {
            e.preventDefault(); e.stopPropagation(); clearDragClasses();
            const rect = nodeDiv.getBoundingClientRect();
            const relY = e.clientY - rect.top;
            const height = rect.height;
            
            if (relY < height * 0.25) {
                nodeDiv.classList.add('drop-above'); nodeDiv.style.borderTop = "2px solid #9575cd";
            } else if (relY > height * 0.75) {
                nodeDiv.classList.add('drop-below'); nodeDiv.style.borderBottom = "2px solid #9575cd";
            } else {
                if (isFolder && item.type !== 'workspace') { nodeDiv.classList.add('drop-inside'); nodeDiv.style.background = "rgba(149, 117, 205, 0.3)"; } 
                else { nodeDiv.classList.add('drop-below'); nodeDiv.style.borderBottom = "2px solid #9575cd"; }
            }
        });

        nodeDiv.addEventListener('dragleave', () => clearDragClasses());

        nodeDiv.addEventListener('drop', (e) => {
            e.stopPropagation(); e.preventDefault();
            let action = 'inside';
            if (nodeDiv.classList.contains('drop-above')) action = 'above';
            else if (nodeDiv.classList.contains('drop-below')) action = 'below';
            clearDragClasses(); handleDrop(path, action);
        });

        wrapper.appendChild(nodeDiv);
        if(hasKids) {
            const kidsBox = document.createElement('div');
            kidsBox.className = 'children'; 
            item.items.forEach((k, i) => kidsBox.appendChild(buildNode(k, [...path, i])));
            wrapper.appendChild(kidsBox);
        }
        return wrapper;
    }

    rootData.forEach((item, i) => container.appendChild(buildNode(item, [i])));
}

function clearDragClasses() {
    document.querySelectorAll('.node').forEach(el => {
        el.style.borderTop = "none"; el.style.borderBottom = "none";
        if (!el.classList.contains('selected')) el.style.background = "";
        else el.style.background = "rgba(149, 117, 205, 0.15)";
        el.classList.remove('drop-above', 'drop-below', 'drop-inside');
    });
}

function handleDrop(targetPath, action) {
    if (!dragSrcPath) return;
    if (JSON.stringify(dragSrcPath) === JSON.stringify(targetPath)) return;

    let srcParent = rootData;
    if (dragSrcPath.length > 1) {
        for(let i=0; i<dragSrcPath.length-1; i++) srcParent = srcParent[dragSrcPath[i]].items;
    }
    const srcIndex = dragSrcPath[dragSrcPath.length-1];
    const itemToMove = srcParent[srcIndex];

    const uniqueId = Date.now() + Math.random();
    itemToMove._moveId = uniqueId;
    
    const clonedItem = JSON.parse(JSON.stringify(itemToMove));
    delete clonedItem._moveId; 

    let destNode = rootData[targetPath[0]];
    for(let i=1; i<targetPath.length; i++) destNode = destNode.items[targetPath[i]];

    let isBecomingRoot = false;

    if (action === 'inside') {
        if(!destNode.items) destNode.items = [];
        destNode.items.push(clonedItem);
        destNode._expanded = true;
    } else {
        if (targetPath.length === 1) isBecomingRoot = true;
        
        let destParent = rootData;
        if (targetPath.length > 1) {
            for(let i=0; i<targetPath.length-1; i++) destParent = destParent[targetPath[i]].items;
        }
        const destIndex = targetPath[targetPath.length-1];
        const insertAt = action === 'above' ? destIndex : destIndex + 1;
        destParent.splice(insertAt, 0, clonedItem);
    }

    if (isBecomingRoot) {
        if (clonedItem.name && !clonedItem.category) { clonedItem.category = clonedItem.name; delete clonedItem.name; }
    } else {
        if (clonedItem.category && !clonedItem.name) { clonedItem.name = clonedItem.category; delete clonedItem.category; }
    }

    deleteById(rootData, uniqueId);
    delete itemToMove._moveId; 
    dragSrcPath = null; selectedPath = null;
    renderTree(); toast("Moved & Saved State");
}

function deleteById(items, id) {
    for (let i = 0; i < items.length; i++) {
        if (items[i]._moveId === id) { items.splice(i, 1); return true; }
        if (items[i].items) { if (deleteById(items[i].items, id)) return true; }
    }
    return false;
}

// ==========================================
// EDITOR ACTIONS
// ==========================================
function select(path) {
    selectedPath = path;
    renderTree();
    
    let node = rootData[path[0]];
    for(let i=1; i<path.length; i++) node = node.items[path[i]];

    document.getElementById('editor-ui').style.display = 'block';
    document.getElementById('empty-msg').style.display = 'none';
    
    let typeVal = 'report';
    if (node.type === 'workspace') typeVal = 'workspace';
    else if (node.items !== undefined) typeVal = 'folder';
    
    document.getElementById('inp-type').value = typeVal;
    document.getElementById('inp-name').value = node.category || node.name || "";
    document.getElementById('inp-url').value = node.url || "";
    document.getElementById('inp-page-css').value = node.pageCss || "";
    document.getElementById('inp-folder-url').value = node.folderUrl || "";
    document.getElementById('inp-workspace-id').value = node.workspaceId || "personal";
    document.getElementById('inp-hidden').checked = node.isHidden === true;
    
    const linkTypeEl = document.getElementById('inp-link-type');
    if (linkTypeEl) linkTypeEl.value = node.linkType || 'report';
    
    const devBox = document.getElementById('inp-dev');
    if (devBox) devBox.checked = node.inDevelopment === true;
    
    // Check our new Allow Build checkbox
    const buildBox = document.getElementById('inp-allow-build');
    if (buildBox) buildBox.checked = node.allowBuild === true;
    
    const newTabBox = document.getElementById('inp-new-tab');
    if (newTabBox) newTabBox.checked = node.openNewTab === true;

    const colorBox = document.getElementById('inp-folder-color');
    if (colorBox) colorBox.value = node.color || "#aea0c0";
    
    toggleUI();
}

function updateItem() {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const node = parent[index];
    const name = document.getElementById('inp-name').value;
    const type = document.getElementById('inp-type').value;

    if(selectedPath.length === 1) { 
        node.category = name; delete node.name; 
    } else { 
        node.name = name; delete node.category; 
    }

    node.isHidden = document.getElementById('inp-hidden').checked;
    node.type = type;

    if(type === 'report') {
        node.url = document.getElementById('inp-url').value.trim();
        node.linkType = document.getElementById('inp-link-type').value;
        node.inDevelopment = document.getElementById('inp-dev').checked;
        node.allowBuild = document.getElementById('inp-allow-build').checked;
        node.openNewTab = document.getElementById('inp-new-tab').checked;
        node.pageCss = document.getElementById('inp-page-css').value;
        
        delete node.items; delete node.color; delete node.folderUrl; delete node.workspaceId;
    } else if (type === 'workspace') {
        node.workspaceId = document.getElementById('inp-workspace-id').value;
        node.folderUrl = document.getElementById('inp-folder-url').value.trim();
        const colorVal = document.getElementById('inp-folder-color').value;
        
        if (colorVal !== "#aea0c0") node.color = colorVal; else delete node.color;
        
        node.items = []; 
        delete node.url; delete node.linkType; delete node.inDevelopment; delete node.allowBuild; delete node.openNewTab; delete node.pageCss;
    } else { // folder
        node.folderUrl = document.getElementById('inp-folder-url').value.trim();
        const colorVal = document.getElementById('inp-folder-color').value;
        if (colorVal !== "#aea0c0") node.color = colorVal;
        else delete node.color;
        
        if(!node.items) node.items = [];
        
        delete node.url; delete node.linkType; delete node.inDevelopment; delete node.allowBuild; delete node.openNewTab; delete node.pageCss; delete node.workspaceId;
    }
    
    if(!node.isHidden) delete node.isHidden; 
    
    renderTree();
    toast("Saved Successfully");
}

function addItem(isRoot, type) {
    if(isRoot) {
        rootData.push({ category: "New Root", items: [] });
        select([rootData.length-1]);
    } else {
        if (!selectedPath) return toast("Select a folder first");
        addItemToPath(selectedPath, type);
    }
}

function addItemToPath(parentPath, type) {
    let node = rootData[parentPath[0]];
    for(let i=1; i<parentPath.length; i++) node = node.items[parentPath[i]];
    if(!node.items) node.items = [];
    node._expanded = true;

    const newItem = type === 'folder' 
        ? { name: "New Folder", items: [] } 
        : { name: "New Link", url: "", linkType: "report" };
            
    const newIndex = node.items.push(newItem) - 1;
    const newPath = [...parentPath, newIndex];
    renderTree(); select(newPath); toast(`Added new ${type}`);
}

function deleteItem() {
    if(!confirm("Are you sure you want to delete this item?")) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    parent.splice(index, 1);
    selectedPath = null;
    
    document.getElementById('editor-ui').style.display = 'none';
    document.getElementById('empty-msg').style.display = 'flex';
    renderTree(); toast("Item Deleted");
}

function moveItem(dir) {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const newIdx = index + dir;
    if(newIdx >= 0 && newIdx < parent.length) {
        [parent[index], parent[newIdx]] = [parent[newIdx], parent[index]];
        selectedPath[selectedPath.length-1] = newIdx;
        renderTree();
    }
}

function getParentAndIndex(path) {
    let parent = rootData;
    if(path.length > 1) { for(let i=0; i<path.length-1; i++) parent = parent[path[i]].items; }
    return { parent, index: path[path.length-1] };
}

function toggleUI() {
    const type = document.getElementById('inp-type').value;
    document.getElementById('box-url').style.display = type === 'report' ? 'grid' : 'none';
    document.getElementById('box-folder').style.display = (type === 'folder' || type === 'workspace') ? 'grid' : 'none';
    document.getElementById('box-workspace').style.display = type === 'workspace' ? 'grid' : 'none';
}

function toast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg; t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 3000);
}