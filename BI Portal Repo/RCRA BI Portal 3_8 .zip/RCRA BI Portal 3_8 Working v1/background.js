// ==================================================
// RCRA BI PORTAL - BACKGROUND SERVICE WORKER
// ==================================================

const MENU_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/menu2.json';
const DEFAULT_HOME = "https://app.powerbi.com/home";

// ==========================================
// 1. HELPER: DYNAMIC HOME URL
// ==========================================
async function getDynamicHomeUrl() {
  try {
    const stored = await chrome.storage.local.get('cachedMenu');
    let data = stored.cachedMenu;
    if (!data || data.length === 0) {
       const res = await fetch(MENU_URL);
       data = await res.json();
       await chrome.storage.local.set({ cachedMenu: data });
    }
    let menuArray = Array.isArray(data) ? data : (data.menu || []);
    const findFirstLink = (items) => {
        for (const item of items) {
            if (item.url && item.url !== "#") return item.url;
            if (item.items && item.items.length > 0) {
                const found = findFirstLink(item.items);
                if (found) return found;
            }
        }
        return null;
    };
    const firstUrl = findFirstLink(menuArray);
    if (firstUrl) {
         if (!firstUrl.startsWith('http') && !firstUrl.startsWith('//')) return DEFAULT_HOME; 
         return firstUrl;
    }
  } catch (e) { console.warn("Failed dynamic home", e); }
  return DEFAULT_HOME;
}

// ==========================================
// 2. FABRIC API: MY WORKSPACE SYNC
// ==========================================
let isSyncing = false; 

async function syncFabricWorkspace() {
    if (isSyncing) return;
    isSyncing = true;
    
    try {
        const data = await chrome.storage.local.get(['fabricToken', 'pbiToken']);
        const token = data.fabricToken || data.pbiToken;
        if (!token) return;

        const headers = { 'Authorization': `Bearer ${token}` };

        async function fetchWorkspaceData(wsId) {
            const [foldersRes, reportsRes] = await Promise.all([
                fetch(`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/folders`, { headers }),
                fetch(`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/items?type=Report`, { headers })
            ]);

            if (!foldersRes.ok || !reportsRes.ok) throw new Error(`API Sync Failed for ${wsId}`);

            const foldersData = await foldersRes.json();
            const reportsData = await reportsRes.json();

            const folderMap = {};
            const rootNodes = [];

            (foldersData.value || []).forEach(f => {
                folderMap[f.id] = { name: f.displayName, category: f.displayName, items: [], id: f.id, parentId: f.parentFolderId, _isWorkspaceFolder: true, _expanded: false };
            });

           (reportsData.value || []).forEach(r => {
                // Ignore Microsoft's hidden auto-generated usage metrics reports
                if (r.displayName === "Report Usage Metrics Report" || r.displayName === "Usage Metrics Report") {
                    return; 
                }

                const reportItem = { name: r.displayName, url: `https://app.powerbi.com/groups/${wsId === 'personal' ? 'me' : wsId}/reports/${r.id}`, linkType: 'report', _isWorkspaceItem: true };
                if (r.folderId && folderMap[r.folderId]) folderMap[r.folderId].items.push(reportItem);
                else rootNodes.push(reportItem);
            });

            Object.values(folderMap).forEach(f => {
                const parentId = f.parentId;
                delete f.id; delete f.parentId;
                if (parentId && folderMap[parentId]) folderMap[parentId].items.push(f);
                else rootNodes.push(f);
            });

            function sortTree(nodes) {
                nodes.sort((a, b) => (a.name || a.category || "").toLowerCase().localeCompare((b.name || b.category || "").toLowerCase()));
                nodes.forEach(n => { if (n.items) sortTree(n.items); });
            }
            sortTree(rootNodes);
            return rootNodes;
        }

        const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers });
        if (!wsRes.ok) throw new Error(`Fabric API rejected token.`);
        const wsData = await wsRes.json();
        const personalWs = wsData.value.find(ws => ws.type === 'Personal');

        let updates = {};
        if (personalWs) {
            try { updates.rcraMyWorkspace = await fetchWorkspaceData(personalWs.id); } catch(e) {}
        }

        await new Promise(resolve => setTimeout(resolve, 300));

        try { updates.rcraPublicWorkspace = await fetchWorkspaceData('8d966faa-0abd-4694-b3b0-be795b35ef5e'); } catch (e) {}

        if (Object.keys(updates).length > 0) {
            await chrome.storage.local.set(updates);
        }

    } catch (error) {
        console.error("RCRA Sync Error:", error.message);
    } finally {
        isSyncing = false; 
    }
}

chrome.alarms.create("syncFabricData", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "syncFabricData") syncFabricWorkspace();
});

// ==========================================
// 3. LISTENER: MESSAGE BUS (Tokens & API)
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    if (request.action === 'RCRA_FABRIC_TOKEN' && request.token) {
        chrome.storage.local.get('fabricToken', (data) => {
            if (data.fabricToken !== request.token) {
                chrome.storage.local.set({ fabricToken: request.token }, () => syncFabricWorkspace());
            }
        });
    }

    if (request.action === 'RCRA_PBI_TOKEN' && request.token) {
        chrome.storage.local.set({ pbiToken: request.token });
    }
    
    if (request.action === 'FORCE_SYNC') syncFabricWorkspace();

    if (request.action === 'GET_USER_IDENTITY') {
        chrome.identity.getProfileUserInfo((userInfo) => { sendResponse({ email: userInfo.email || "" }); });
        return true; 
    }

    // --- Fetch Folders for UI ---
    if (request.action === 'GET_FOLDERS') {
        chrome.storage.local.get(['fabricToken', 'pbiToken'], async (data) => {
            const token = data.fabricToken || data.pbiToken;
            if (!token) return sendResponse({ success: false, error: "Missing Authentication Token. Please refresh the page." });
            
            try {
                let targetWsId = request.workspaceId;
                if (targetWsId === "personal") {
                    const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers: { 'Authorization': `Bearer ${token}` } });
                    if (!wsRes.ok) return sendResponse({ success: false, error: `Failed to locate Personal Workspace (Status: ${wsRes.status})` });
                    const wsData = await wsRes.json();
                    const personalWs = wsData.value.find(ws => ws.type === 'Personal');
                    if (personalWs) targetWsId = personalWs.id;
                }

                const res = await fetch(`https://api.fabric.microsoft.com/v1/workspaces/${targetWsId}/folders`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                
                if (res.ok) {
                    const json = await res.json();
                    sendResponse({ success: true, folders: json.value || [] });
                } else {
                    const errData = await res.json().catch(() => ({}));
                    const exactError = errData.error?.message || errData.message || `HTTP Status ${res.status}`;
                    sendResponse({ success: false, error: exactError });
                }
            } catch(e) {
                sendResponse({ success: false, error: e.message });
            }
        });
        return true;
    }

    // --- Create Folder ---
    if (request.action === 'CREATE_FOLDER') {
        chrome.storage.local.get(['fabricToken', 'pbiToken'], async (data) => {
            const token = data.fabricToken || data.pbiToken;
            if (!token) return sendResponse({ success: false, error: "Missing Authentication Token. Please refresh the page." });
            
            try {
                let targetWsId = request.workspaceId;
                if (targetWsId === "personal") {
                    const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers: { 'Authorization': `Bearer ${token}` } });
                    const wsData = await wsRes.json();
                    const personalWs = wsData.value.find(ws => ws.type === 'Personal');
                    if (personalWs) targetWsId = personalWs.id;
                }

                // Add parentFolderId to payload if we are nesting
                const payload = { displayName: request.folderName };
                if (request.parentFolderId) {
                    payload.parentFolderId = request.parentFolderId;
                }

                const res = await fetch(`https://api.fabric.microsoft.com/v1/workspaces/${targetWsId}/folders`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                
                if (res.ok) {
                    sendResponse({ success: true });
                    syncFabricWorkspace(); 
                } else {
                    const err = await res.json();
                    sendResponse({ success: false, error: err.error?.message || "Creation Failed" });
                }
            } catch(e) {
                sendResponse({ success: false, error: e.message });
            }
        });
        return true;
    }

    // --- Clone & Move Report Execution ---
    if (request.action === 'CLONE_REPORT') {
        chrome.storage.local.get(['fabricToken', 'pbiToken'], async (data) => {
            const pbiToken = data.pbiToken || data.fabricToken;
            const fabricToken = data.fabricToken || data.pbiToken;
            
            if (!pbiToken) {
                sendResponse({ success: false, error: "Authentication missing. Try interacting with the report, then try again." });
                return;
            }

            const apiUrl = `https://api.powerbi.com/v1.0/myorg/groups/${request.sourceWorkspaceId}/reports/${request.reportId}/Clone`;
            const bodyPayload = { name: request.newName };
            
            let realWorkspaceId = request.targetId;
            
            if (request.targetId === "personal") {
                bodyPayload.targetWorkspaceId = "00000000-0000-0000-0000-000000000000";
                try {
                    const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers: { 'Authorization': `Bearer ${fabricToken}` } });
                    if (wsRes.ok) {
                        const wsData = await wsRes.json();
                        const personalWs = wsData.value.find(ws => ws.type === 'Personal');
                        if (personalWs) realWorkspaceId = personalWs.id;
                    }
                } catch(e) { console.warn("Failed to lookup personal workspace GUID", e); }
            } else {
                bodyPayload.targetWorkspaceId = request.targetId;
            }

            try {
                // 1. Fire the Clone to the Workspace Root
                const res = await fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${pbiToken}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify(bodyPayload)
                });

                if (res.ok) {
                    const clonedData = await res.json();
                    const newReportId = clonedData.id;
                    const reportUrl = clonedData.webUrl || `https://app.powerbi.com/groups/${request.targetId === 'personal' ? 'me' : request.targetId}/reports/${newReportId}`;
                    
                    // 2. If a folder was selected, use Fabric API to Move the item
                    if (request.folderId && realWorkspaceId && realWorkspaceId !== "personal") {
                        const moveUrl = `https://api.fabric.microsoft.com/v1/workspaces/${realWorkspaceId}/items/${newReportId}/move`;
                        const moveRes = await fetch(moveUrl, {
                            method: 'POST',
                            headers: { 'Authorization': `Bearer ${fabricToken}`, 'Content-Type': 'application/json' },
                            body: JSON.stringify({ targetFolderId: request.folderId })
                        });
                        
                        if (!moveRes.ok) console.warn("Clone succeeded, but folder move failed.");
                    }

                    sendResponse({ success: true, url: reportUrl });
                } else {
                    const err = await res.json();
                    sendResponse({ success: false, error: err.error?.message || "Unknown permissions error." });
                }
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        });
        return true; 
    }
});

// ==========================================
// 4. BROWSER LISTENERS
// ==========================================
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const targetUrl = await getDynamicHomeUrl();
    chrome.tabs.create({ url: targetUrl });
    chrome.storage.local.set({ isSidebarOpen: true });
    syncFabricWorkspace(); 
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url.includes("app.powerbi.com")) return;
  const data = await chrome.storage.local.get('isSidebarOpen');
  const newState = !data.isSidebarOpen;
  await chrome.storage.local.set({ isSidebarOpen: newState });

  if (newState) {
    syncFabricWorkspace();
    const homeUrl = await getDynamicHomeUrl();
    const currentClean = tab.url.toLowerCase().replace(/\/$/, "");
    const homeClean = homeUrl.toLowerCase().replace(/\/$/, "");
    
    if (!currentClean.includes(homeClean)) await chrome.tabs.update(tab.id, { url: homeUrl });
    else {
        try { await chrome.tabs.sendMessage(tab.id, { action: 'OPEN_SIDEBAR' }); } 
        catch (err) { injectSidebar(tab.id); }
    }
  } else {
    try { await chrome.tabs.sendMessage(tab.id, { action: 'REMOVE_SIDEBAR' }); } catch (err) { }
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading') {
    const data = await chrome.storage.local.get('isSidebarOpen');
    if (data.isSidebarOpen && tab.url && tab.url.startsWith('https://app.powerbi.com/')) {
        syncFabricWorkspace();
        injectSidebar(tabId);
    }
  }
});

function injectSidebar(tabId) {
    chrome.scripting.executeScript({ target: { tabId: tabId }, files: ['content.js'] }).catch(() => {});
}