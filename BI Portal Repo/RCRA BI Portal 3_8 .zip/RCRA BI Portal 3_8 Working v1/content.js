// ==================================================
// RCRA BI PORTAL - CONTENT SCRIPT (FINAL)
// ==================================================

(() => {
    if (window.rcraContentLoaded) return;
    window.rcraContentLoaded = true;

    var pendingLayout = { width: '0px', height: '100vh', push: '0px', side: 'left', isFloating: false };
    let lastCheckedUrl = ""; 
    let urlCheckTimeout;
    let isDevBarActive = false;
    let currentReportAllowBuild = false; // State manager for the "Save a Copy" button

    window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data) return;
        if (event.data.action === 'RCRA_FABRIC_TOKEN' || event.data.action === 'RCRA_PBI_TOKEN') {
            chrome.runtime.sendMessage({ action: event.data.action, token: event.data.token });
        }
    });

    // ==================================================
    // 1. SIDEBAR & LAYOUT LOGIC
    // ==================================================
    function initSidebar() {
      if (document.getElementById('rcra-sidebar-frame')) return;
      const iframe = document.createElement('iframe');
      iframe.id = 'rcra-sidebar-frame';
      iframe.src = chrome.runtime.getURL('sidebar.html') + '?parent=' + encodeURIComponent(window.location.href);
      iframe.style.cssText = `position: fixed; top: 0; height: 100vh; border: none; z-index: 2147483648; background: transparent !important; transition: all 0.3s ease;`;
      iframe.onload = () => iframe.contentWindow.postMessage({ action: 'REQUEST_LAYOUT' }, '*');
      document.documentElement.appendChild(iframe);
      checkWelcomeStatus();
      injectGlobalCss();
    }

    function applyLayout(data) {
        if (data) pendingLayout = { ...data };
        const frame = document.getElementById('rcra-sidebar-frame');
        const htmlNode = document.documentElement;
        const topOffset = isDevBarActive ? '40px' : '0px';

        if (frame) {
            frame.style.width = pendingLayout.width;
            frame.style.height = isDevBarActive ? `calc(100vh - 40px)` : pendingLayout.height;
            frame.style.top = topOffset;
            frame.style.boxShadow = pendingLayout.isFloating ? 'none' : '0 0 10px rgba(0,0,0,0.2)';
            if (pendingLayout.side === 'left') {
                frame.style.left = '0'; frame.style.right = 'auto';
                frame.style.borderRight = '1px solid rgba(0,0,0,0.1)'; frame.style.borderLeft = 'none';
            } else {
                frame.style.right = '0'; frame.style.left = 'auto';
                frame.style.borderLeft = '1px solid rgba(0,0,0,0.1)'; frame.style.borderRight = 'none';
            }
        }
        if (htmlNode) {
            htmlNode.style.transition = 'margin 0.3s ease';
            htmlNode.style.marginTop = topOffset;
            if (pendingLayout.side === 'left') {
                htmlNode.style.marginLeft = pendingLayout.push;
                htmlNode.style.marginRight = '0px';
            } else {
                htmlNode.style.marginRight = pendingLayout.push;
                htmlNode.style.marginLeft = '0px';
            }
        }
    }

    // ==================================================
    // 2. DEV TOP BAR LOGIC
    // ==================================================
    async function showDevBar() {
        if (isDevBarActive) return;
        let container = document.getElementById('rcra-dev-wrapper');
        if (!container) {
            const response = await fetch(chrome.runtime.getURL('dev_bar.html'));
            container = document.createElement('div');
            container.id = "rcra-dev-wrapper";
            container.innerHTML = await response.text();
            document.body.prepend(container);
            setTimeout(() => {
                const btnClose = document.getElementById('rcra-bar-close');
                if (btnClose) btnClose.addEventListener('click', removeDevBar);
            }, 100);
        }
        setTimeout(() => document.getElementById('rcra-dev-bar')?.classList.add('visible'), 50);
        isDevBarActive = true; applyLayout(); 
    }

    function removeDevBar() {
        if (!isDevBarActive) return;
        document.getElementById('rcra-dev-bar')?.classList.remove('visible');
        isDevBarActive = false; applyLayout();
        setTimeout(() => document.getElementById('rcra-dev-wrapper')?.remove(), 300);
    }

    // ==================================================
    // 3. AUTOMATIC URL MONITOR
    // ==================================================
    async function checkCurrentUrlAndInject() {
        const browserUrl = window.location.href.toLowerCase();
        const getReportId = (url) => { const match = url.match(/reports\/([a-f0-9\-]{36})/); return match ? match[1] : url.split('?')[0]; };
        const currentId = getReportId(browserUrl);
        
        if (currentId === lastCheckedUrl) return; 
        lastCheckedUrl = currentId;
        
        currentReportAllowBuild = false; // Reset security flag on navigation change

        const data = await chrome.storage.local.get('cachedMenu');
        let matchFound = false, targetPageCss = null;

        if (data?.cachedMenu) {
            let menuArray = Array.isArray(data.cachedMenu) ? data.cachedMenu : (data.cachedMenu.menu || []);
            const scanMenu = (items) => {
                for (const item of items) {
                    if (item.url) {
                        const menuId = getReportId(item.url.toLowerCase());
                        if (currentId.includes(menuId) || menuId.includes(currentId)) {
                            if (item.inDevelopment === true || item.inDevelopment === "true") matchFound = true;
                            if (item.pageCss) targetPageCss = item.pageCss;
                            if (item.allowBuild === true || item.allowBuild === "true") currentReportAllowBuild = true;
                        }
                    }
                    if (item.items) scanMenu(item.items);
                }
            };
            scanMenu(menuArray);
        }

        if (matchFound) showDevBar(); else if (isDevBarActive) removeDevBar();

        let pageCssTag = document.getElementById('rcra-page-specific-css');
        if (targetPageCss) {
            if (!pageCssTag) {
                pageCssTag = document.createElement('style');
                pageCssTag.id = 'rcra-page-specific-css';
                document.documentElement.appendChild(pageCssTag);
            }
            pageCssTag.innerHTML = targetPageCss;
        } else if (pageCssTag) pageCssTag.remove();
    }

    const urlObserver = new MutationObserver(() => {
        clearTimeout(urlCheckTimeout);
        urlCheckTimeout = setTimeout(checkCurrentUrlAndInject, 2000); 
    });
    urlObserver.observe(document.querySelector('title') || document.documentElement, { subtree: true, childList: true });

    // ==================================================
    // 4. CUSTOM "SAVE AS" MODAL UI & BUTTON
    // ==================================================
    function createSaveModal(sourceWorkspaceId, reportId, defaultName) {
        if (document.getElementById('rcra-save-overlay')) return;

        let allFolders = [];
        let currentFolderId = null;
        let currentPath = []; 

        const overlay = document.createElement('div');
        overlay.id = 'rcra-save-overlay';
        overlay.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.4); z-index: 2147483647;
            display: flex; align-items: center; justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        `;

        const modal = document.createElement('div');
        modal.style.cssText = `
            background: #ffffff; width: 650px; border-radius: 4px; box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            display: flex; flex-direction: column; overflow: hidden;
        `;

        modal.innerHTML = `
            <div style="padding: 20px 24px; border-bottom: 1px solid #edebe9; display: flex; justify-content: space-between; align-items: center;">
                <h2 style="margin: 0; font-size: 20px; font-weight: 600; color: #252423;">Save your report</h2>
                <button id="rcra-new-folder-btn" style="padding: 6px 12px; border: 1px solid #8a8886; background: white; cursor: pointer; border-radius: 4px; display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: #323130; transition: background 0.2s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path><line x1="12" y1="11" x2="12" y2="17"></line><line x1="9" y1="14" x2="15" y2="14"></line></svg>
                    New folder
                </button>
            </div>
            <div style="padding: 24px; display: flex; flex-direction: column; gap: 20px;">
                
                <div style="display: flex; align-items: center; gap: 15px;">
                    <label style="width: 120px; font-size: 14px; color: #323130; font-weight: 500;">Destination</label>
                    <select id="rcra-save-dest" style="flex: 1; padding: 6px 12px; font-size: 14px; border: 1px solid #8a8886; border-radius: 2px; outline: none; background: white; color: #323130;">
                        <option value="8d966faa-0abd-4694-b3b0-be795b35ef5e">RCRA Public Workspace</option>
                        <option value="personal">My Workspace</option>
                    </select>
                </div>

                <div style="border: 1px solid #edebe9; border-radius: 4px; height: 260px; display: flex; flex-direction: column; background: #ffffff;">
                    <div id="rcra-breadcrumbs" style="padding: 10px 16px; border-bottom: 1px solid #edebe9; background: #faf9f8; font-size: 13px; font-weight: 500; display: flex; align-items: center; gap: 6px;">
                    </div>
                    
                    <div style="flex: 1; overflow-y: auto;">
                        <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 13px;">
                            <tbody id="rcra-folder-list">
                                <tr><td style="padding: 20px; text-align: center; color: #605e5c;">Loading folders...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div style="display: flex; align-items: center; gap: 15px;">
                    <label style="width: 120px; font-size: 14px; color: #323130; font-weight: 500;">Enter a name</label>
                    <input type="text" id="rcra-save-name" value="${defaultName}" style="flex: 1; padding: 6px 12px; font-size: 14px; border: 1px solid #8a8886; border-radius: 2px; outline: none; color: #323130;">
                </div>
                
                <div id="rcra-save-error" style="color: #a4262c; font-size: 12px; display: none;"></div>
            </div>
            <div style="padding: 16px 24px; background: #faf9f8; border-top: 1px solid #edebe9; display: flex; justify-content: flex-end; gap: 10px;">
                <button id="rcra-save-cancel" style="padding: 6px 16px; border: 1px solid #8a8886; background: #ffffff; color: #323130; font-size: 14px; cursor: pointer; border-radius: 2px; font-weight: 600;">Cancel</button>
                <button id="rcra-save-confirm" style="padding: 6px 16px; border: none; background: #f2c811; color: #252423; font-size: 14px; cursor: pointer; border-radius: 2px; font-weight: 600;">Save</button>
            </div>
        `;

        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        const renderFolderView = () => {
            const tbody = document.getElementById('rcra-folder-list');
            const breadcrumbs = document.getElementById('rcra-breadcrumbs');
            
            breadcrumbs.innerHTML = '';
            currentPath.forEach((step, index) => {
                const stepEl = document.createElement('span');
                stepEl.innerText = step.name;
                
                if (index < currentPath.length - 1) {
                    stepEl.style.cssText = 'color: #0078d4; cursor: pointer; transition: color 0.1s;';
                    stepEl.onmouseenter = () => stepEl.style.textDecoration = 'underline';
                    stepEl.onmouseleave = () => stepEl.style.textDecoration = 'none';
                    stepEl.onclick = () => {
                        currentPath = currentPath.slice(0, index + 1);
                        currentFolderId = step.id;
                        renderFolderView();
                    };
                } else {
                    stepEl.style.color = '#323130';
                }
                
                breadcrumbs.appendChild(stepEl);
                
                if (index < currentPath.length - 1) {
                    const sep = document.createElement('span');
                    sep.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#605e5c" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>';
                    breadcrumbs.appendChild(sep);
                }
            });

            const visibleFolders = allFolders.filter(f => {
                if (currentFolderId === null) return !f.parentFolderId;
                else return f.parentFolderId === currentFolderId;
            });

            tbody.innerHTML = '';
            if (visibleFolders.length === 0) {
                tbody.innerHTML = `<tr><td style="padding: 40px 20px; text-align: center;">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="#c8c6c4" stroke="none"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"></path></svg>
                    <div style="font-size: 16px; font-weight: 600; color: #323130; margin-top: 10px;">This folder is empty</div>
                    <div style="font-size: 13px; color: #605e5c; margin-top: 5px;">Create, save, or move your items to this folder</div>
                </td></tr>`;
            } else {
                visibleFolders.sort((a,b) => a.displayName.localeCompare(b.displayName));
                visibleFolders.forEach(f => {
                    const tr = document.createElement('tr');
                    tr.style.cssText = 'border-bottom: 1px solid #edebe9; cursor: pointer; transition: background 0.2s;';
                    tr.onmouseenter = () => tr.style.background = '#f3f2f1';
                    tr.onmouseleave = () => tr.style.background = 'transparent';
                    
                    tr.innerHTML = `
                        <td style="padding: 10px 16px; color: #323130; display: flex; align-items: center; gap: 10px;">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="#FCE100" stroke="#E6BE00" stroke-width="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                            ${f.displayName}
                        </td>
                        <td style="padding: 10px 16px; color: #605e5c; width: 100px;">Folder</td>
                    `;
                    
                    tr.onclick = () => {
                        currentFolderId = f.id;
                        currentPath.push({ id: f.id, name: f.displayName });
                        renderFolderView();
                    };
                    tbody.appendChild(tr);
                });
            }
        };

        const fetchFolders = () => {
            const wsDropdown = document.getElementById('rcra-save-dest');
            const wsId = wsDropdown.value;
            const wsName = wsDropdown.options[wsDropdown.selectedIndex].text;
            
            currentFolderId = null;
            currentPath = [{ id: null, name: wsName }];
            allFolders = [];
            
            const tbody = document.getElementById('rcra-folder-list');
            document.getElementById('rcra-breadcrumbs').innerHTML = '';
            tbody.innerHTML = '<tr><td style="padding: 20px; text-align: center; color: #605e5c;">Loading...</td></tr>';
            
            chrome.runtime.sendMessage({ action: 'GET_FOLDERS', workspaceId: wsId }, (res) => {
                if (res && res.success) {
                    allFolders = res.folders || [];
                    renderFolderView();
                } else {
                    const exactError = res?.error || "Unknown Communication Error";
                    tbody.innerHTML = `<tr><td style="padding: 20px; text-align: center; color: #a4262c; font-weight: 500;">Error: ${exactError}</td></tr>`;
                }
            });
        };

        fetchFolders();
        document.getElementById('rcra-save-dest').addEventListener('change', fetchFolders);

        const folderBtn = document.getElementById('rcra-new-folder-btn');
        folderBtn.addEventListener('mouseenter', () => folderBtn.style.background = '#f3f2f1');
        folderBtn.addEventListener('mouseleave', () => folderBtn.style.background = 'white');
        folderBtn.addEventListener('click', () => {
            const folderName = prompt("Enter a name for the new folder:");
            if (!folderName || folderName.trim() === "") return;
            
            const wsId = document.getElementById('rcra-save-dest').value;
            const originalText = folderBtn.innerHTML;
            folderBtn.innerHTML = "Creating...";
            folderBtn.disabled = true;

            chrome.runtime.sendMessage({ 
                action: 'CREATE_FOLDER', 
                workspaceId: wsId, 
                folderName: folderName.trim(),
                parentFolderId: currentFolderId 
            }, (res) => {
                folderBtn.innerHTML = originalText;
                folderBtn.disabled = false;
                if (res && res.success) {
                    chrome.runtime.sendMessage({ action: 'GET_FOLDERS', workspaceId: wsId }, (refreshRes) => {
                        if (refreshRes && refreshRes.success) {
                            allFolders = refreshRes.folders || [];
                            renderFolderView();
                        }
                    });
                } else {
                    alert("Failed to create folder: " + (res?.error || "Unknown error"));
                }
            });
        });

        document.getElementById('rcra-save-cancel').onclick = () => overlay.remove();
        
        const confirmBtn = document.getElementById('rcra-save-confirm');
        confirmBtn.onclick = () => {
            const finalName = document.getElementById('rcra-save-name').value.trim();
            const targetId = document.getElementById('rcra-save-dest').value;
            const errorDiv = document.getElementById('rcra-save-error');
            
            if (!finalName) {
                errorDiv.innerText = "Please enter a report name.";
                errorDiv.style.display = "block";
                return;
            }

            confirmBtn.innerText = "Saving...";
            confirmBtn.disabled = true;
            confirmBtn.style.opacity = "0.7";
            errorDiv.style.display = "none";

            chrome.runtime.sendMessage({
                action: 'CLONE_REPORT',
                sourceWorkspaceId: sourceWorkspaceId,
                reportId: reportId,
                newName: finalName,
                targetId: targetId,
                folderId: currentFolderId 
            }, (response) => {
                if (response && response.success) {
                    confirmBtn.innerText = "Redirecting...";
                    confirmBtn.style.backgroundColor = "#4caf50";
                    confirmBtn.style.color = "white";
                    
                    setTimeout(() => {
                        window.location.href = response.url;
                    }, 800);
                } else {
                    errorDiv.innerText = `Error: ${response?.error || "Failed to save."}`;
                    errorDiv.style.display = "block";
                    confirmBtn.innerText = "Save";
                    confirmBtn.disabled = false;
                    confirmBtn.style.opacity = "1";
                }
            });
        };
    }

    function injectSaveAsButton() {
        const url = window.location.href.toLowerCase();
        const isPersonalWorkspace = url.includes('/groups/me/');
        
        const existingBtn = document.getElementById('rcra-custom-clone-btn');

        // Security Check: Hide the button if "Allow Build" is false, OR if they are inside My Workspace
        if (!currentReportAllowBuild || isPersonalWorkspace) {
            if (existingBtn) existingBtn.remove();
            return;
        }

        if (existingBtn) return;
        
        const menuBar = document.querySelector('trident-menu-button-bar');
        if (!menuBar) return;

        const btnWrapper = document.createElement('trident-focus-mode-button');
        btnWrapper.className = "tri-overflow-item";
        btnWrapper.id = 'rcra-custom-clone-btn';

        const btn = document.createElement('button');
        btn.innerText = "💾 Save a Copy";
        btn.style.cssText = "background-color: #F2C811; color: black; border: none; padding: 0 15px; font-weight: bold; cursor: pointer; border-radius: 4px; height: 32px; margin-left: 8px; font-size: 13px; display: flex; align-items: center;";

        btn.addEventListener('click', () => {
            const currentUrl = window.location.href;
            const groupMatch = currentUrl.match(/groups\/([a-f0-9\-]+)/i);
            const reportMatch = currentUrl.match(/reports\/([a-f0-9\-]+)/i);

            if (!groupMatch || !reportMatch) {
                alert("Could not identify the Workspace or Report ID from the URL.");
                return;
            }
            
            const defaultName = document.title.split('-')[0].trim() || "Copied Report";
            createSaveModal(groupMatch[1], reportMatch[1], "Copy of " + defaultName);
        });

        btnWrapper.appendChild(btn);
        menuBar.appendChild(btnWrapper);
    }

    // ==================================================
    // 5. UTILITIES & CSS INJECTION
    // ==================================================
    function forceFavicon() {
        const iconUrl = chrome.runtime.getURL("icon48.png");
        const links = document.querySelectorAll("link[rel*='icon']");
        let found = false;
        links.forEach(link => { if (link.href !== iconUrl) link.href = iconUrl; found = true; });
        if (!found) {
            const link = document.createElement('link');
            link.type = 'image/png'; link.rel = 'icon'; link.href = iconUrl;
            document.head.appendChild(link);
        }
    }

    async function injectGlobalCss() {
        const storageData = await chrome.storage.local.get('cachedSettings');
        if (storageData?.cachedSettings?.customCss) {
            const cssString = storageData.cachedSettings.customCss;
            let styleTag = document.getElementById('rcra-custom-dynamic-css');
            if (!styleTag) {
                styleTag = document.createElement('style');
                styleTag.id = 'rcra-custom-dynamic-css';
                styleTag.innerHTML = cssString;
                document.documentElement.appendChild(styleTag);
            } else if (document.documentElement.lastElementChild !== styleTag) {
                document.documentElement.appendChild(styleTag);
            }
        }
    }

    async function checkWelcomeStatus() {
        const data = await chrome.storage.local.get('welcomeDismissed');
        if (data.welcomeDismissed) return;
        if (document.getElementById('rcra-welcome-container')) return;
        
        const response = await fetch(chrome.runtime.getURL('welcome.html'));
        const container = document.createElement('div');
        container.id = 'rcra-welcome-container';
        container.innerHTML = await response.text();
        document.body.appendChild(container);

        const storageData = await chrome.storage.local.get('cachedSettings');
        if (storageData?.cachedSettings) {
            const settings = storageData.cachedSettings;
            if (settings.welcomeTitle) document.getElementById('dynamic-welcome-title').innerText = settings.welcomeTitle;
            if (settings.welcomeDesc) document.getElementById('dynamic-welcome-desc').innerText = settings.welcomeDesc;
            
            const stepsContainer = document.getElementById('dynamic-welcome-steps');
            if (stepsContainer && settings.welcomeSteps?.length > 0) {
                stepsContainer.innerHTML = ''; 
                settings.welcomeSteps.forEach(step => {
                    stepsContainer.insertAdjacentHTML('beforeend', `
                        <div class="rcra-step">
                            <div class="rcra-icon">${step.icon}</div>
                            <div class="rcra-text"><strong>${step.title}</strong><p>${step.text}</p></div>
                        </div>`);
                });
            }
        }

        setTimeout(() => {
            document.getElementById('rcra-close-btn')?.addEventListener('click', () => {
                if (document.getElementById('rcra-dont-show')?.checked) chrome.storage.local.set({ welcomeDismissed: true });
                document.getElementById('rcra-welcome-overlay').style.opacity = '0';
                setTimeout(() => container.remove(), 300);
            });
        }, 100);
    }

    if (document.documentElement) {
      initSidebar();
      setTimeout(checkCurrentUrlAndInject, 2500);
      setInterval(() => { forceFavicon(); injectGlobalCss(); injectSaveAsButton(); }, 2000); 
    }

    window.addEventListener('load', () => { if (pendingLayout.width !== '0px') applyLayout(); });
    window.addEventListener('message', (event) => {
        if (event.data.action === 'UPDATE_LAYOUT') applyLayout(event.data);
        if (event.data.action === 'RELOAD_CSS') injectGlobalCss();
    });

    chrome.runtime.onMessage.addListener((request) => {
        if (request.action === 'REMOVE_SIDEBAR') {
            document.getElementById('rcra-sidebar-frame')?.remove();
            document.documentElement.style.marginLeft = '0px'; document.documentElement.style.marginTop = '0px';
            isDevBarActive = false; removeDevBar();
            document.getElementById('rcra-custom-dynamic-css')?.remove();
            document.getElementById('rcra-page-specific-css')?.remove();
        }
        if (request.action === 'OPEN_SIDEBAR') initSidebar();
    });
})();