// ==========================================
// 1. CONFIGURATION
// ==========================================
const DEFAULT_PORTAL_CONFIG = {
    githubOwner: 'RCRA-User',
    githubRepo: 'RCRA_Public',
    githubBranch: 'main',
    menuPath: 'menu2.json',
    settingsPath: 'settings.json',
    publicWorkspaceId: '8d966faa-0abd-4694-b3b0-be795b35ef5e',
    publicWorkspaceName: 'RCRA Public Workspace',
    workspaces: [
        { id: '8d966faa-0abd-4694-b3b0-be795b35ef5e', name: 'RCRA Public Workspace', autoExpandOnMatch: true }
    ]
};
const MENU_REFRESH_TTL_MS = 5 * 60 * 1000;
const DEFAULT_ACCESS_DENIED_TITLE = "RCRA BI Portal Access Not Verified";
const DEFAULT_ACCESS_DENIED_MESSAGE = "Your menu is hidden because this Power BI account is not currently recognized as an approved facility user.\n\nPlease confirm you are signed into Power BI with your approved facility email address, then refresh this page.\n\nIf you believe you should have access, contact your RCRA BI Portal administrator and include the email address shown in your Power BI profile.";

let currentSettings = {};
let sidebarMessageListenerAttached = false;
let currentParentUrl = '';

function buildRawGithubUrl(config, path) {
    return `https://raw.githubusercontent.com/${encodeURIComponent(config.githubOwner)}/${encodeURIComponent(config.githubRepo)}/${encodeURIComponent(config.githubBranch)}/${path.split('/').map(encodeURIComponent).join('/')}`;
}

async function getPortalConfig() {
    const stored = await chrome.storage.local.get('rcraPortalConfig');
    const config = { ...DEFAULT_PORTAL_CONFIG, ...(stored.rcraPortalConfig || {}) };
    config.workspaces = (Array.isArray(config.workspaces) ? config.workspaces : [])
        .map(ws => ({
            id: String(ws.id || '').trim(),
            name: String(ws.name || '').trim(),
            autoExpandOnMatch: ws.autoExpandOnMatch !== false
        }))
        .filter(ws => /^[a-f0-9-]{36}$/i.test(ws.id));
    if (config.workspaces.length === 0 && /^[a-f0-9-]{36}$/i.test(config.publicWorkspaceId || '')) {
        config.workspaces = [{ id: config.publicWorkspaceId, name: config.publicWorkspaceName || 'Public Workspace', autoExpandOnMatch: true }];
    }
    config.publicWorkspaceId = config.workspaces[0]?.id || config.publicWorkspaceId;
    config.publicWorkspaceName = config.workspaces[0]?.name || config.publicWorkspaceName;
    return config;
}

function escapeHtml(value = '') {
    return String(value).replace(/[&<>"']/g, ch => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[ch]));
}

function safeColor(value, fallback = 'currentColor') {
    const color = String(value || '').trim();
    return /^#[0-9a-f]{3,8}$/i.test(color) || /^[a-z]+$/i.test(color) ? color : fallback;
}

function isSafeOpenUrl(url = '') {
    try {
        const parsed = new URL(url, window.location.href);
        return parsed.protocol === 'https:' || parsed.protocol === 'chrome-extension:';
    } catch(e) {
        return false;
    }
}

function getPowerBiItemId(url = '') {
    const match = String(url).toLowerCase().match(/\/(reports|explorations|dashboards|datasets|items|paginatedreports)\/([a-f0-9-]{36})/);
    return match ? match[2] : null;
}

function getReportId(url = '') {
    const match = String(url).toLowerCase().match(/\/reports\/([a-f0-9-]{36})/);
    return match ? match[1] : null;
}

function normalizeApprovedDomains(value) {
    const source = Array.isArray(value) ? value : String(value || '').split(/[\n,;]/);
    return [...new Set(source
        .map(domain => String(domain || '').trim().toLowerCase().replace(/^@+/, ''))
        .filter(domain => /^[a-z0-9.-]+\.[a-z]{2,}$/.test(domain)))];
}

function getEmailDomain(email = '') {
    const parts = String(email || '').trim().toLowerCase().split('@');
    return parts.length === 2 ? parts[1] : '';
}

function normalizeComparableUrl(url = '') {
    return String(url || '').toLowerCase().replace(/\/$/, "");
}

function setCurrentParentUrl(url = '') {
    const cleanUrl = normalizeComparableUrl(url);
    if (!cleanUrl || cleanUrl === currentParentUrl) return false;
    currentParentUrl = cleanUrl;
    return true;
}

function cloneWorkspaceItems(items = []) {
    try {
        return JSON.parse(JSON.stringify(Array.isArray(items) ? items : []));
    } catch(e) {
        return Array.isArray(items) ? items.slice() : [];
    }
}

function applyActiveAutoExpandPreference(items = [], autoExpandOnMatch = true) {
    (items || []).forEach(item => {
        item._suppressActiveAutoExpand = autoExpandOnMatch === false;
        if (Array.isArray(item.items)) applyActiveAutoExpandPreference(item.items, autoExpandOnMatch);
    });
}

function normalizeMenuLabel(value = '') {
    return String(value || '').trim().toLowerCase();
}

function collectWorkspaceMenuEntries(items = []) {
    const entries = { ids: new Set(), labels: new Set() };
    const visit = (nodes = []) => {
        (nodes || []).forEach(item => {
            if (!item) return;
            if (item.type === 'workspace') {
                const id = String(item.workspaceId || '').trim();
                const label = normalizeMenuLabel(item.category || item.name);
                if (id) entries.ids.add(id);
                if (label) entries.labels.add(label);
            }
            if (Array.isArray(item.items)) visit(item.items);
        });
    };
    visit(items);
    return entries;
}

function hasWorkspaceMenuEntry(entries, workspace = {}) {
    const id = String(workspace.id || '').trim();
    const label = normalizeMenuLabel(workspace.name);
    return (id && entries.ids.has(id)) || (label && entries.labels.has(label));
}

function hasPersonalWorkspaceMenuEntry(entries) {
    return entries.ids.has('personal') || entries.labels.has('my workspace');
}

// ==========================================
// 2. INITIALIZATION & LOGIC
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initMenu(); 
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    initMenu();
  }
});

// Watch for background local updates to Workspace Data
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && (changes.rcraMyWorkspace || changes.rcraPublicWorkspace || changes.rcraWorkspaceData || changes.rcraPortalConfig || changes.cachedSettings || changes.rcraUserEmail || changes.fabricToken || changes.pbiToken)) {
        initMenu();
    }
    if (namespace === 'sync' && changes.rcraDismissedAlerts) {
        initMenu();
    }
});

function applyGlobalSettings() {
    const titleEl = document.querySelector('.title');
    if (titleEl && currentSettings.portalName) {
        titleEl.textContent = currentSettings.portalName;
    }

    if (currentSettings.customCss) {
        let styleTag = document.getElementById('rcra-custom-dynamic-css');
        if (!styleTag) {
            styleTag = document.createElement('style');
            styleTag.id = 'rcra-custom-dynamic-css';
            document.head.appendChild(styleTag);
        }
        styleTag.textContent = currentSettings.customCss;
    }

    const btnLeft = document.getElementById('btn-left');
    const btnRight = document.getElementById('btn-right');
    if (btnLeft && btnRight) {
        const displayVal = currentSettings.showLayoutBtns === false ? 'none' : 'block';
        btnLeft.style.display = displayVal;
        btnRight.style.display = displayVal;
    }

    initSidebar();
}

function initSidebar() {
  const body = document.body;
  const toggleBtn = document.getElementById('sidebar-toggle');
  const hideBtn = document.getElementById('hide-sidebar-btn');
  const floatIcon = document.getElementById('floating-icon');
  const btnLeft = document.getElementById('btn-left');
  const btnRight = document.getElementById('btn-right');
  const resizeHandle = document.getElementById('sidebar-resize-handle');
  const SIDEBAR_MIN_WIDTH = 300;
  const SIDEBAR_MAX_WIDTH = 520;

  const getExpandedWidth = () => {
    const storedWidth = parseInt(localStorage.getItem('sidebar-width'), 10);
    if (!Number.isFinite(storedWidth)) return SIDEBAR_MIN_WIDTH;
    return Math.min(SIDEBAR_MAX_WIDTH, Math.max(SIDEBAR_MIN_WIDTH, storedWidth));
  };

  const updateParentLayout = () => {
    const isFloating = body.classList.contains('floating-mode');
    const isMini = body.classList.contains('mini-mode');
    const isHoverExpanded = body.classList.contains('hover-expanded');
    
    const defaultGlobalSide = currentSettings.defaultSide || 'left';
    const side = localStorage.getItem('sidebar-side') || defaultGlobalSide;
    
    let frameWidth, frameHeight, pagePush;

    if (isFloating) {
        frameWidth = '60px';   
        frameHeight = '60px';  
        pagePush = '0px';      
    } else {
        frameWidth = (isMini && !isHoverExpanded) ? '65px' : `${getExpandedWidth()}px`;
        frameHeight = '100vh'; 
        pagePush = frameWidth; 
    }

    const parentOrigin = new URLSearchParams(window.location.search).get('parent');
    const targetOrigin = parentOrigin ? new URL(parentOrigin).origin : 'https://app.powerbi.com';
    window.parent.postMessage({ 
      action: 'UPDATE_LAYOUT', 
      width: frameWidth, height: frameHeight, push: pagePush,
      side: side, isFloating: isFloating,
      isMini: isMini,
      isHoverExpanded: isHoverExpanded
    }, targetOrigin);
  };

  if (toggleBtn && !toggleBtn.dataset.listener) {
    toggleBtn.addEventListener('click', () => {
      if (body.classList.contains('mini-mode') && body.classList.contains('hover-expanded')) {
        body.classList.remove('hover-expanded');
      } else {
        body.classList.toggle('mini-mode');
        body.classList.remove('hover-expanded');
      }
      localStorage.setItem('sidebar-mini', body.classList.contains('mini-mode'));
      updateParentLayout();
    });
    toggleBtn.dataset.listener = "true";
  }

  if (hideBtn && !hideBtn.dataset.listener) {
      hideBtn.addEventListener('click', () => {
          body.classList.remove('hover-expanded');
          body.classList.add('floating-mode');
          localStorage.setItem('sidebar-floating', 'true');
          updateParentLayout();
      });
      hideBtn.dataset.listener = "true";
  }

  if (floatIcon && !floatIcon.dataset.listener) {
      floatIcon.addEventListener('click', () => {
          body.classList.remove('floating-mode');
          body.classList.remove('hover-expanded');
          localStorage.setItem('sidebar-floating', 'false');
          body.classList.remove('mini-mode');
          localStorage.setItem('sidebar-mini', 'false'); 
          updateParentLayout();
      });
      floatIcon.dataset.listener = "true";
  }

  const setSide = (side) => {
    localStorage.setItem('sidebar-side', side);
    body.classList.toggle('sidebar-left', side === 'left');
    body.classList.toggle('sidebar-right', side === 'right');
    if (btnLeft && btnRight) {
        if (side === 'left') {
          btnLeft.style.background = '#6a4c93'; btnLeft.style.color = 'white';
          btnRight.style.background = 'rgba(0,0,0,0.2)'; btnRight.style.color = '#aea0c0';
        } else {
          btnRight.style.background = '#6a4c93'; btnRight.style.color = 'white';
          btnLeft.style.background = 'rgba(0,0,0,0.2)'; btnLeft.style.color = '#aea0c0';
        }
    }
    updateParentLayout();
  };

  if (btnLeft && btnRight && !btnLeft.dataset.listener) {
    btnLeft.addEventListener('click', () => setSide('left'));
    btnRight.addEventListener('click', () => setSide('right'));
    btnLeft.dataset.listener = "true";
  }

  if (resizeHandle && !resizeHandle.dataset.listener) {
    resizeHandle.addEventListener('pointerdown', (event) => {
      if (body.classList.contains('floating-mode') || (body.classList.contains('mini-mode') && !body.classList.contains('hover-expanded'))) return;
      event.preventDefault();
      resizeHandle.setPointerCapture(event.pointerId);
      body.classList.add('resizing-sidebar');
      const startX = event.clientX;
      const startWidth = getExpandedWidth();
      const side = localStorage.getItem('sidebar-side') || currentSettings.defaultSide || 'left';

      const onPointerMove = (moveEvent) => {
        const delta = moveEvent.clientX - startX;
        const nextWidth = side === 'right' ? startWidth - delta : startWidth + delta;
        localStorage.setItem('sidebar-width', String(Math.min(SIDEBAR_MAX_WIDTH, Math.max(SIDEBAR_MIN_WIDTH, nextWidth))));
        updateParentLayout();
      };

      const onPointerUp = (upEvent) => {
        body.classList.remove('resizing-sidebar');
        resizeHandle.releasePointerCapture(upEvent.pointerId);
        resizeHandle.removeEventListener('pointermove', onPointerMove);
        resizeHandle.removeEventListener('pointerup', onPointerUp);
        resizeHandle.removeEventListener('pointercancel', onPointerUp);
      };

      resizeHandle.addEventListener('pointermove', onPointerMove);
      resizeHandle.addEventListener('pointerup', onPointerUp);
      resizeHandle.addEventListener('pointercancel', onPointerUp);
    });
    resizeHandle.dataset.listener = "true";
  }

  if (localStorage.getItem('sidebar-floating') === 'true') {
      body.classList.add('floating-mode');
  } else if (localStorage.getItem('sidebar-mini') === 'true' || localStorage.getItem('sidebar-mini') === null) {
      body.classList.add('mini-mode');
      if (localStorage.getItem('sidebar-mini') === null) localStorage.setItem('sidebar-mini', 'true');
  }
  
  const defaultGlobalSide = currentSettings.defaultSide || 'left';
  const savedSide = localStorage.getItem('sidebar-side') || defaultGlobalSide;
  setSide(savedSide);

  if (!sidebarMessageListenerAttached) {
    window.addEventListener('message', (event) => {
      if (event.origin && event.origin !== 'https://app.powerbi.com') return;
      if (event.data.action === 'REQUEST_LAYOUT') updateParentLayout();
      if (event.data.action === 'RELOAD_MENU') initMenu();
      if (event.data.action === 'CURRENT_URL_CHANGED' && setCurrentParentUrl(event.data.url)) initMenu();
      if (event.data.action === 'COLLAPSE_HOVER') {
          if (document.body.classList.contains('hover-expanded')) {
              document.body.classList.remove('hover-expanded');
              document.body.classList.add('mini-mode');
              localStorage.setItem('sidebar-mini', 'true');
              updateParentLayout();
          }
      }
    });
    sidebarMessageListenerAttached = true;
  }

  if (!body.dataset.hoverExpandListener) {
    const HOVER_COLLAPSE_DELAY_MS = 250;
    let hoverCollapseTimer = null;
    const forceParentMiniLayout = () => {
      try {
        const parentOrigin = new URLSearchParams(window.location.search).get('parent');
        const targetOrigin = parentOrigin ? new URL(parentOrigin).origin : 'https://app.powerbi.com';
        window.parent.postMessage({ action: 'FORCE_MINI_LAYOUT' }, targetOrigin);
      } catch(e) {}
    };
    const cancelParentMiniCollapse = () => {
      try {
        const parentOrigin = new URLSearchParams(window.location.search).get('parent');
        const targetOrigin = parentOrigin ? new URL(parentOrigin).origin : 'https://app.powerbi.com';
        window.parent.postMessage({ action: 'CANCEL_MINI_COLLAPSE' }, targetOrigin);
      } catch(e) {}
    };
    const cancelHoverCollapse = () => {
      if (hoverCollapseTimer) {
        clearTimeout(hoverCollapseTimer);
        hoverCollapseTimer = null;
      }
      cancelParentMiniCollapse();
    };
    const collapseHover = () => {
      if (hoverCollapseTimer) {
        clearTimeout(hoverCollapseTimer);
        hoverCollapseTimer = null;
      }
      const wasExpanded = body.classList.remove('hover-expanded');
      if (wasExpanded) {
        updateParentLayout();
      }
      if (body.classList.contains('mini-mode') && !body.classList.contains('floating-mode')) forceParentMiniLayout();
    };
    const scheduleHoverCollapse = () => {
      if (hoverCollapseTimer) clearTimeout(hoverCollapseTimer);
      hoverCollapseTimer = setTimeout(collapseHover, HOVER_COLLAPSE_DELAY_MS);
    };
    const shouldSuppressHoverExpand = (event) => {
      return event.target.closest('#hide-sidebar-btn') || event.clientY > window.innerHeight - 84;
    };
    const isOutsideSidebarBounds = (event) => {
      if (!body.classList.contains('hover-expanded')) return false;
      const wrapper = document.querySelector('.main-wrapper');
      if (!wrapper) return false;
      const rect = wrapper.getBoundingClientRect();
      return event.clientX < rect.left ||
        event.clientX > rect.right ||
        event.clientY < rect.top ||
        event.clientY > rect.bottom;
    };

    body.addEventListener('mousemove', (event) => {
      if (!body.classList.contains('mini-mode') || body.classList.contains('floating-mode')) return;
      if (isOutsideSidebarBounds(event)) {
        scheduleHoverCollapse();
        return;
      }
      if (!body.classList.contains('hover-expanded') && shouldSuppressHoverExpand(event)) {
        scheduleHoverCollapse();
        return;
      }
      cancelHoverCollapse();
      if (!body.classList.contains('hover-expanded')) {
        body.classList.add('hover-expanded');
        updateParentLayout();
      }
    });
    body.addEventListener('mouseenter', cancelHoverCollapse);
    document.addEventListener('mouseenter', cancelHoverCollapse);
    body.addEventListener('mouseleave', scheduleHoverCollapse);
    document.addEventListener('mouseleave', scheduleHoverCollapse);
    window.addEventListener('blur', scheduleHoverCollapse);
    window.addEventListener('mouseout', (event) => {
      if (!event.relatedTarget && !event.toElement) scheduleHoverCollapse();
    });
    document.addEventListener('click', (event) => {
      if (!event.target.closest('.main-wrapper') && !event.target.closest('#floating-icon')) collapseHover();
    });
    body.dataset.hoverExpandListener = "true";
  }

  initInteractions();
}

// ==========================================
// FAVORITES LOGIC
// ==========================================

async function getFavorites() {
    const result = await chrome.storage.sync.get('rcraFavorites');
    return result.rcraFavorites || [];
}

async function toggleFavorite(url) {
    if (!url) return;
    let favs = await getFavorites();
    if (favs.includes(url)) favs = favs.filter(u => u !== url); 
    else favs.push(url); 
    
    await chrome.storage.sync.set({ rcraFavorites: favs });
    initMenu(); 
}

function findItemByUrl(items, url) {
    for (const item of items) {
        if (item.url === url) return item;
        if (item.items && item.items.length > 0) {
            const found = findItemByUrl(item.items, url);
            if (found) return found;
        }
    }
    return null;
}

async function getCurrentUserEmail() {
    const stored = await chrome.storage.local.get('rcraUserEmail');
    if (stored.rcraUserEmail) return String(stored.rcraUserEmail).toLowerCase();
    return new Promise(resolve => {
        chrome.runtime.sendMessage({ action: 'GET_USER_IDENTITY' }, response => {
            resolve((response?.email || '').toLowerCase());
        });
    });
}

async function getCurrentPowerBiUserEmail() {
    const stored = await chrome.storage.local.get(['rcraUserEmail', 'fabricToken', 'pbiToken']);
    if (!stored.fabricToken && !stored.pbiToken) return '';
    return String(stored.rcraUserEmail || '').toLowerCase();
}

function isApprovedDomainUser(userEmail, approvedDomains = []) {
    if (approvedDomains.length === 0) return true;
    const domain = getEmailDomain(userEmail);
    return Boolean(domain && approvedDomains.includes(domain));
}

function setAuthenticatedUi(isAuthenticated) {
    const searchContainer = document.querySelector('.search-container');
    const filterSection = document.querySelector('.filter-section');
    const alertsContainer = document.getElementById('alerts-container');
    const editBtn = document.getElementById('btn-edit');
    if (searchContainer) searchContainer.style.display = isAuthenticated ? '' : 'none';
    if (filterSection) filterSection.style.display = isAuthenticated ? '' : 'none';
    if (alertsContainer) {
        alertsContainer.style.display = isAuthenticated ? '' : 'none';
        if (!isAuthenticated) alertsContainer.replaceChildren();
    }
    if (!isAuthenticated) sendOverlayAlerts([]);
    if (editBtn) editBtn.style.display = isAuthenticated ? '' : 'none';
}

function renderAccessDenied(container) {
    if (!container) return;
    const title = currentSettings.accessDeniedTitle || DEFAULT_ACCESS_DENIED_TITLE;
    const message = currentSettings.accessDeniedMessage || DEFAULT_ACCESS_DENIED_MESSAGE;
    const paragraphs = String(message)
        .split(/\n{2,}/)
        .map(part => part.trim())
        .filter(Boolean)
        .map(part => `<p>${escapeHtml(part).replace(/\n/g, '<br>')}</p>`)
        .join('');
    container.innerHTML = `
        <div class="access-denied-panel">
            <div class="access-denied-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="4" y="11" width="16" height="10" rx="2"></rect>
                    <path d="M8 11V7a4 4 0 0 1 8 0v4"></path>
                </svg>
            </div>
            <h2>${escapeHtml(title)}</h2>
            ${paragraphs}
        </div>
    `;
}

function buildAllowedEmailSet(groups = [], selectedGroupIds = []) {
    const selected = new Set(selectedGroupIds || []);
    const emails = new Set();
    groups.forEach(group => {
        if (!selected.has(group.id)) return;
        (group.emails || []).forEach(email => {
            if (email) emails.add(String(email).trim().toLowerCase());
        });
    });
    return emails;
}

function getRestrictionGroupNames(item = {}) {
    const allowedGroups = Array.isArray(item.allowedGroups) ? item.allowedGroups.filter(Boolean) : [];
    if (allowedGroups.length === 0) return [];
    const groupNameById = new Map((currentSettings.securityGroups || []).map(group => [
        group.id,
        String(group.name || group.id || '').trim()
    ]));
    return allowedGroups.map(groupId => groupNameById.get(groupId) || groupId);
}

function buildRestrictionBadge(item = {}) {
    const groupNames = getRestrictionGroupNames(item);
    if (groupNames.length === 0) return '';
    const title = `Restricted: ${groupNames.join(', ')}`;
    return `
        <span class="restriction-badge" title="${escapeHtml(title)}" aria-label="${escapeHtml(title)}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <rect x="4" y="11" width="16" height="10" rx="2"></rect>
                <path d="M8 11V7a4 4 0 0 1 8 0v4"></path>
            </svg>
        </span>
    `;
}

function normalizeAlert(alert = {}, defaults = {}) {
    const severity = ["info", "warning", "critical"].includes(alert.severity) ? alert.severity : "info";
    const scope = ["global", "page"].includes(alert.scope) ? alert.scope : (defaults.scope || "global");
    const rawPlacement = ["sidebar", "overlay"].includes(alert.placement) ? alert.placement : (defaults.placement || "sidebar");
    const placement = scope === "page" ? "overlay" : rawPlacement;
    const targetSource = Array.isArray(alert.targetUrls) ? alert.targetUrls : (Array.isArray(alert.pageUrls) ? alert.pageUrls : []);
    return {
        id: String(alert.id || ''),
        enabled: alert.enabled !== false,
        severity,
        scope,
        placement,
        title: String(alert.title || '').trim(),
        message: String(alert.message || '').trim(),
        dismissible: alert.dismissible !== false,
        reshowOnEdit: alert.reshowOnEdit !== false,
        dismissVersion: String(alert.dismissVersion || '').trim(),
        startAt: String(alert.startAt || '').trim(),
        endAt: String(alert.endAt || '').trim(),
        targetUrls: scope === "page" ? [...new Set(targetSource.map(url => String(url || "").trim()).filter(Boolean))] : []
    };
}

function normalizeAlerts(alerts = [], defaults = {}) {
    return (Array.isArray(alerts) ? alerts : [])
        .map(alert => normalizeAlert(alert, defaults))
        .filter(alert => alert.id && (alert.title || alert.message));
}

function getAlertDismissKey(alert) {
    if (!alert?.id) return '';
    return alert.reshowOnEdit && alert.dismissVersion ? `${alert.id}:${alert.dismissVersion}` : alert.id;
}

function isAlertDismissed(alert, dismissedIds = []) {
    const dismissKey = getAlertDismissKey(alert);
    if (!dismissKey) return false;
    if (alert.reshowOnEdit) return dismissedIds.includes(dismissKey);
    return dismissedIds.includes(alert.id) || dismissedIds.some(id => String(id).startsWith(`${alert.id}:`));
}

function isAlertActive(alert, dismissedIds = []) {
    if (!alert.enabled) return false;
    if (alert.dismissible && isAlertDismissed(alert, dismissedIds)) return false;
    const now = Date.now();
    if (alert.startAt) {
        const start = Date.parse(alert.startAt);
        if (Number.isFinite(start) && now < start) return false;
    }
    if (alert.endAt) {
        const end = Date.parse(alert.endAt);
        if (Number.isFinite(end) && now > end) return false;
    }
    return true;
}

async function getDismissedAlertIds() {
    const stored = await chrome.storage.sync.get('rcraDismissedAlerts');
    return Array.isArray(stored.rcraDismissedAlerts) ? stored.rcraDismissedAlerts : [];
}

async function dismissAlert(alert) {
    const dismissKey = typeof alert === 'string' ? alert : getAlertDismissKey(alert);
    if (!dismissKey) return;
    const dismissed = await getDismissedAlertIds();
    if (!dismissed.includes(dismissKey)) {
        await chrome.storage.sync.set({ rcraDismissedAlerts: [...dismissed, dismissKey] });
    }
}

function alertItemMatchesCurrentUrl(item, currentUrl) {
    if (!item?.url) return false;
    let itemUrlFull = item.url;
    if (!itemUrlFull.startsWith('http') && !itemUrlFull.startsWith('//') && !itemUrlFull.startsWith('chrome')) {
        itemUrlFull = chrome.runtime.getURL(itemUrlFull);
    }
    const cleanItemUrl = normalizeComparableUrl(itemUrlFull);
    const currentItemId = getPowerBiItemId(currentUrl);
    const itemPowerBiId = getPowerBiItemId(cleanItemUrl);
    return (currentItemId && itemPowerBiId && currentItemId === itemPowerBiId)
        || (!itemPowerBiId && cleanItemUrl.length > 5 && normalizeComparableUrl(currentUrl) === cleanItemUrl);
}

function collectCurrentPageAlerts(items = [], currentUrl = '') {
    const alerts = [];
    const visit = (nodes) => {
        (nodes || []).forEach(item => {
            if (alertItemMatchesCurrentUrl(item, currentUrl)) {
                alerts.push(...normalizeAlerts(item.pageAlerts || [], { scope: "page", placement: "sidebar" }));
            }
            if (Array.isArray(item.items)) visit(item.items);
        });
    };
    visit(items);
    return alerts;
}

function alertTargetsCurrentUrl(alert, currentUrl = '') {
    if (alert.scope !== "page") return false;
    return (alert.targetUrls || []).some(targetUrl => alertItemMatchesCurrentUrl({ url: targetUrl }, currentUrl));
}

function sendOverlayAlerts(alerts = []) {
    window.parent.postMessage({
        action: 'RCRA_RENDER_ALERT_OVERLAYS',
        alerts: alerts.map(alert => ({
            id: alert.id,
            dismissKey: getAlertDismissKey(alert),
            severity: alert.severity,
            title: alert.title,
            message: alert.message,
            dismissible: alert.dismissible
        }))
    }, '*');
}

async function renderSidebarAlerts(menuData = []) {
    const container = document.getElementById('alerts-container');
    if (!container) return;
    const rawParentUrl = new URLSearchParams(window.location.search).get('parent') || currentParentUrl;
    setCurrentParentUrl(rawParentUrl);
    const currentUrl = currentParentUrl;
    const dismissedIds = await getDismissedAlertIds();
    const configuredAlerts = normalizeAlerts(currentSettings.globalAlerts || []);
    const legacyPageAlerts = collectCurrentPageAlerts(menuData, currentUrl);
    const activeAlerts = [
        ...configuredAlerts.filter(alert => alert.scope === "global" || alertTargetsCurrentUrl(alert, currentUrl)),
        ...legacyPageAlerts
    ].filter(alert => isAlertActive(alert, dismissedIds));
    const sidebarAlerts = activeAlerts.filter(alert => alert.placement === "sidebar");
    const overlayAlerts = activeAlerts.filter(alert => alert.placement === "overlay");

    container.replaceChildren();
    container.style.display = sidebarAlerts.length > 0 ? '' : 'none';
    sendOverlayAlerts(overlayAlerts);
    if (sidebarAlerts.length === 0) return;

    sidebarAlerts.forEach(alert => {
        const card = document.createElement('div');
        card.className = `sidebar-alert sidebar-alert-${alert.severity}`;
        card.dataset.alertId = alert.id;
        const titleHtml = alert.title ? `<strong>${escapeHtml(alert.title)}</strong>` : '';
        const messageHtml = alert.message ? `<p>${escapeHtml(alert.message).replace(/\n/g, '<br>')}</p>` : '';
        const closeHtml = alert.dismissible ? '<button class="sidebar-alert-close" type="button" title="Dismiss Alert">x</button>' : '';
        card.innerHTML = `
            <div class="sidebar-alert-head">
                ${titleHtml}
                ${closeHtml}
            </div>
            ${messageHtml}
        `;
        const closeBtn = card.querySelector('.sidebar-alert-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', async (event) => {
                event.preventDefault();
                event.stopPropagation();
                await dismissAlert(alert);
                card.remove();
                if (!container.querySelector('.sidebar-alert')) container.style.display = 'none';
            });
        }
        container.appendChild(card);
    });
}

function filterMenuBySecurity(items, securityGroups, userEmail) {
    const visit = (item) => {
        if (!item || item.isHidden) return null;

        const allowedGroups = Array.isArray(item.allowedGroups) ? item.allowedGroups.filter(Boolean) : [];
        if (allowedGroups.length > 0) {
            if (!userEmail) return null;
            const allowedEmails = buildAllowedEmailSet(securityGroups, allowedGroups);
            if (!allowedEmails.has(userEmail)) return null;
        }

        const copy = { ...item };
        if (Array.isArray(copy.items)) {
            copy.items = copy.items.map(visit).filter(Boolean);
        }
        return copy;
    };
    return (items || []).map(visit).filter(Boolean);
}

// ==========================================
// INIT MENU
// ==========================================
let isRenderingMenu = false; // Prevents race conditions during simultaneous reloads

async function initMenu() {
  if (isRenderingMenu) return;
  isRenderingMenu = true;

  try {
      const container = document.getElementById('nav-tree-container');
      let currentData = [];
      const portalConfig = await getPortalConfig();

      try {
        const stored = await chrome.storage.local.get(['cachedMenu', 'cachedSettings']);
        if (stored.cachedMenu) currentData = stored.cachedMenu;
        if (stored.cachedSettings) currentSettings = stored.cachedSettings;
      } catch (e) {}

      try {
        const meta = await chrome.storage.local.get('rcraMenuFetchedAt');
        const shouldRefreshMenu = !meta.rcraMenuFetchedAt || Date.now() - meta.rcraMenuFetchedAt > MENU_REFRESH_TTL_MS;
        if (shouldRefreshMenu) {
            const [menuRes, settingsRes] = await Promise.all([
                fetch(buildRawGithubUrl(portalConfig, portalConfig.menuPath) + '?t=' + new Date().getTime()),
                fetch(buildRawGithubUrl(portalConfig, portalConfig.settingsPath) + '?t=' + new Date().getTime())
            ]);

            if (menuRes.ok) {
                const liveMenu = await menuRes.json();
                if (liveMenu.menu && !Array.isArray(liveMenu)) {
                    currentData = liveMenu.menu;
                    if (liveMenu.settings && (!settingsRes.ok)) currentSettings = liveMenu.settings;
                } else {
                    currentData = liveMenu;
                }
                await chrome.storage.local.set({ cachedMenu: currentData });
            }

            if (settingsRes.ok) {
                const liveSettings = await settingsRes.json();
                currentSettings = liveSettings;
                await chrome.storage.local.set({ cachedSettings: currentSettings });
            }
            await chrome.storage.local.set({ rcraMenuFetchedAt: Date.now() });
        }
      } catch (e) { console.warn("Fetch failed, using cache"); }

      applyGlobalSettings();

      const favs = await getFavorites();
      let finalData = JSON.parse(JSON.stringify(currentData)); 
      const approvedDomains = normalizeApprovedDomains(currentSettings.approvedDomains || []);
      const userEmail = approvedDomains.length > 0 ? await getCurrentPowerBiUserEmail() : await getCurrentUserEmail();
      if (!isApprovedDomainUser(userEmail, approvedDomains)) {
          setAuthenticatedUi(false);
          renderAccessDenied(container);
          return;
      }
      setAuthenticatedUi(true);
      const securityGroups = currentSettings.securityGroups || [];

      // 1. Fetch Workspaces from Storage
      const workspaceData = await chrome.storage.local.get(['rcraMyWorkspace', 'rcraPublicWorkspace', 'rcraWorkspaceData']);
      const personalWs = workspaceData.rcraMyWorkspace || [];
      const workspaceMap = workspaceData.rcraWorkspaceData || {};
      if (portalConfig.publicWorkspaceId && workspaceData.rcraPublicWorkspace && !workspaceMap[portalConfig.publicWorkspaceId]) {
          workspaceMap[portalConfig.publicWorkspaceId] = workspaceData.rcraPublicWorkspace;
      }

      // 2. Attach dynamic workspace content to nodes mapped in the Menu Editor
      const workspaceConfigById = new Map((portalConfig.workspaces || []).map(workspace => [workspace.id, workspace]));
      function attachWorkspaces(items) {
          items.forEach(item => {
              if (item.type === 'workspace') {
                  const sourceItems = item.workspaceId === 'personal' ? personalWs : (workspaceMap[item.workspaceId] || []);
                  const workspaceConfig = workspaceConfigById.get(item.workspaceId);
                  const autoExpandOnMatch = item.workspaceId === 'personal' ? true : workspaceConfig?.autoExpandOnMatch !== false;
                  item.items = cloneWorkspaceItems(sourceItems);
                  item._isWorkspaceFolder = true;
                  item._suppressActiveAutoExpand = autoExpandOnMatch === false;
                  applyActiveAutoExpandPreference(item.items, autoExpandOnMatch);
              }
              if (item.items) attachWorkspaces(item.items);
          });
      }
      attachWorkspaces(finalData);

      // Safety Fallback: Prepend them automatically if they haven't been added to the Menu Editor yet
      const workspaceMenuEntries = collectWorkspaceMenuEntries(finalData);
      const hasPersonal = hasPersonalWorkspaceMenuEntry(workspaceMenuEntries);
      const configuredWorkspaces = portalConfig.workspaces || [];

      if (!hasPersonal && personalWs.length > 0) {
          finalData.unshift({ name: "My Workspace", category: "My Workspace", type: "workspace", workspaceId: "personal", items: cloneWorkspaceItems(personalWs), _isWorkspaceFolder: true, _suppressActiveAutoExpand: false });
      }
      configuredWorkspaces.slice().reverse().forEach(workspace => {
          const items = workspaceMap[workspace.id] || [];
          if (!hasWorkspaceMenuEntry(workspaceMenuEntries, workspace) && items.length > 0) {
              const workspaceItems = cloneWorkspaceItems(items);
              applyActiveAutoExpandPreference(workspaceItems, workspace.autoExpandOnMatch !== false);
              finalData.unshift({
                  name: workspace.name,
                  category: workspace.name,
                  type: "workspace",
                  workspaceId: workspace.id,
                  items: workspaceItems,
                  _isWorkspaceFolder: true,
                  _suppressActiveAutoExpand: workspace.autoExpandOnMatch === false
              });
          }
      });

      finalData = filterMenuBySecurity(finalData, securityGroups, userEmail);
      await renderSidebarAlerts(finalData);

      // 3. Favorites
      if (favs.length > 0) {
          const favItems = [];
          favs.forEach(favUrl => {
              const original = findItemByUrl(finalData, favUrl);
              if (original) favItems.push({ ...original }); 
          });

          if (favItems.length > 0) {
              finalData.unshift({
                  name: "Favorites", category: "Favorites",
                  items: favItems, _isFavFolder: true 
              }); 
          }
      }

      renderMenu(finalData, container, favs);
  } finally {
      isRenderingMenu = false;
  }
}

// ==========================================
// 3. RENDER LOGIC
// ==========================================
function renderMenu(menuData, container, favoritesList) {
  
  // CAPTURE WHICH FOLDERS ARE CURRENTLY OPEN BEFORE CLEARING
  const openFolders = new Set();
  container.querySelectorAll('.nav-group.expanded').forEach(g => {
      const label = g.getAttribute('data-search-label');
      if (label) openFolders.add(label);
  });
  
  container.innerHTML = '';
  const urlParams = new URLSearchParams(window.location.search);
  const rawParentUrl = urlParams.get('parent') || '';
  setCurrentParentUrl(rawParentUrl);
  const currentUrl = currentParentUrl;

  function buildNode(item, isRoot, depth = 0) {
    if (item.isHidden) return null;

    const labelText = item.category || item.name || 'Untitled';
    
    const hasChildren = item.items && Array.isArray(item.items);
    const isFolder = (item.items !== undefined || item.type === 'workspace'); 
    const isFavFolder = item._isFavFolder === true;
    const isWorkspaceFolder = item._isWorkspaceFolder === true;
    const isDev = (item.inDevelopment === true || item.inDevelopment === "true");

    const itemDiv = document.createElement('div');
    let isActive = false;
    
    if (item.url) {
        let itemUrlFull = item.url;
        if (!itemUrlFull.startsWith('http') && !itemUrlFull.startsWith('//') && !itemUrlFull.startsWith('chrome')) {
             itemUrlFull = chrome.runtime.getURL(itemUrlFull);
        }
        const cleanItemUrl = normalizeComparableUrl(itemUrlFull);
        const currentItemId = getPowerBiItemId(currentUrl);
        const itemPowerBiId = getPowerBiItemId(cleanItemUrl);
        if ((currentItemId && itemPowerBiId && currentItemId === itemPowerBiId) || (!itemPowerBiId && cleanItemUrl.length > 5 && currentUrl === cleanItemUrl)) {
            isActive = true;
        }
    }
    const activeClass = isActive ? 'active-selection' : '';
    const restrictionBadge = buildRestrictionBadge(item);

    if (isFolder) {
        itemDiv.className = 'nav-group';
        itemDiv.classList.add(`level-${Math.min(depth, 4)}`);
        
        if (isFavFolder) itemDiv.classList.add('fav-group');
        if (isWorkspaceFolder && isRoot) itemDiv.classList.add('workspace-group'); // Mark workspaces for CSS targets
        
        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        
        const header = document.createElement('div');
        header.className = 'nav-item folder';
        header.classList.add(`level-${Math.min(depth, 4)}`);
        header.title = labelText;
        
        const safeLabel = escapeHtml(labelText);
        const fColor = safeColor(item.color);
        const fTextStyle = item.color ? `color: ${fColor}; font-weight: 500;` : "";
        
        let folderIcon = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${fColor}" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`;
        
        if (isFavFolder) {
            folderIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="#FFD700" stroke="#FFD700" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
        } else if (isWorkspaceFolder && isRoot) {
            folderIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>';
        }

        let actionBtnHTML = '';
        
        if (item.folderUrl && isSafeOpenUrl(item.folderUrl)) {
            actionBtnHTML += `
            <div class="folder-url-action" data-url="${escapeHtml(item.folderUrl)}" title="Open Folder Link" style="color: var(--text-secondary); cursor: pointer;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
            </div>`;
        }

        if (isWorkspaceFolder && isRoot) {
            actionBtnHTML += `
            <div class="workspace-action-refresh" title="Sync / Refresh Workspace" style="cursor: pointer;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="23 4 23 10 17 10"></polyline>
                    <polyline points="1 20 1 14 7 14"></polyline>
                    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
            </div>`;
        }

        header.innerHTML = `
            <div class="left-col">
              <svg class="chevron-folder" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 18 15 12 9 6"></polyline></svg>
              <div class="icon-box">
                 ${folderIcon}
              </div>
              <span class="label" style="${fTextStyle}">${safeLabel}</span>
            </div>
            <div class="nav-row-actions">${restrictionBadge}${actionBtnHTML}</div>
        `;
            
        const subMenu = document.createElement('div');
        subMenu.className = 'sub-menu';
        if (hasChildren && item.items.length > 0) {
            item.items.forEach(child => {
                const childNode = buildNode(child, false, depth + 1);
                if (childNode) subMenu.appendChild(childNode);
            });
        }
        
        // CHECK IF THIS FOLDER WAS OPEN BEFORE THE RELOAD
        const wasOpen = openFolders.has(labelText.toLowerCase());
        
        const hasActiveChild = subMenu.querySelector('.active-selection');
        const suppressActiveAutoExpand = item._suppressActiveAutoExpand === true;
        const shouldExpandForActiveMatch = hasActiveChild && !suppressActiveAutoExpand;
        const shouldPreserveOpenState = wasOpen && !(hasActiveChild && suppressActiveAutoExpand);
        if (shouldExpandForActiveMatch || item._expanded || shouldPreserveOpenState) {
            itemDiv.classList.add('expanded');
            header.classList.add('active');
            header.querySelector('.chevron-folder').innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
        }
        
        if (isWorkspaceFolder && isRoot) {
            const refreshBtn = header.querySelector('.workspace-action-refresh');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', (e) => {
                    e.stopPropagation(); e.preventDefault();
                    
                    // Trigger spin animation visually right now
                    const svg = refreshBtn.querySelector('svg');
                    if (svg) {
                        svg.classList.add('spin-anim');
                        setTimeout(() => svg.classList.remove('spin-anim'), 3000); // Failsafe removal
                    }
                    
                    // Force the menu open instantly upon click
                    itemDiv.classList.add('expanded');
                    header.classList.add('active');
                    const chevron = header.querySelector('.chevron-folder');
                    if (chevron) chevron.innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
                    
                    // Tell background to fetch. The storage listener will trigger a seamless re-render!
                    chrome.runtime.sendMessage({ action: 'FORCE_SYNC' });
                });
            }
        }

        const urlBtn = header.querySelector('.folder-url-action');
        if (urlBtn) {
            urlBtn.addEventListener('click', (e) => {
                e.stopPropagation(); e.preventDefault();
                const targetUrl = urlBtn.getAttribute('data-url');
                if (!isSafeOpenUrl(targetUrl)) return;
                window.open(targetUrl, '_blank');
                
                // Force the sidebar into collapsed (mini) mode
                if (!document.body.classList.contains('mini-mode')) {
                    const toggleBtn = document.getElementById('sidebar-toggle');
                    if (toggleBtn) toggleBtn.click();
                }
            });
            urlBtn.addEventListener('mouseenter', () => urlBtn.style.color = '#fff');
            urlBtn.addEventListener('mouseleave', () => urlBtn.style.color = 'var(--text-secondary)');
        }

        itemDiv.appendChild(header);
        itemDiv.appendChild(subMenu);
        return itemDiv;
    } else {
        const itemKind = String(item.itemType || item.linkType || '').toLowerCase();
        let iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F2C811" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>';
        
        if (isDev) {
             iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#cf6679" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
        } else if (labelText === "Home") {
            iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>';
        } else if (itemKind === 'exploration') {
            iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2F7EDB" stroke-width="2"><circle cx="7" cy="15" r="4"></circle><circle cx="17" cy="15" r="4"></circle><path d="M10.5 15h3"></path><path d="M6 11l2-6h3l1 6"></path><path d="M18 11l-2-6h-3l-1 6"></path></svg>';
        } else if (itemKind === 'dashboard') {
            iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F2C811" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="3" width="7" height="7" rx="1"></rect><rect x="3" y="14" width="7" height="7" rx="1"></rect><rect x="14" y="14" width="7" height="7" rx="1"></rect></svg>';
        } else if (itemKind === 'semanticmodel' || itemKind === 'dataset') {
            iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F2C811" stroke-width="2"><ellipse cx="12" cy="5" rx="8" ry="3"></ellipse><path d="M4 5v6c0 1.66 3.58 3 8 3s8-1.34 8-3V5"></path><path d="M4 11v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6"></path></svg>';
        } else if (itemKind === 'paginatedreport') {
            iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F2C811" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="8" y1="13" x2="16" y2="13"></line><line x1="8" y1="17" x2="14" y2="17"></line></svg>';
        } else if (itemKind === 'excel') {
             iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>';
        }

        itemDiv.className = `nav-item report ${activeClass}`;
        itemDiv.classList.add(`level-${Math.min(depth, 4)}`);
        itemDiv.setAttribute('data-url', item.url);
        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        itemDiv.setAttribute('data-item-type', item.itemType || item.linkType || 'report');
        
        if(isDev) itemDiv.setAttribute('data-dev', 'true');
        if(item.openNewTab) itemDiv.setAttribute('data-new-tab', 'true');
        
        itemDiv.title = labelText;
        
        const isFav = favoritesList.includes(item.url);
        const starClass = isFav ? 'fav-active' : '';
        const starFill = isFav ? '#FFD700' : 'none';
        const starStroke = isFav ? '#FFD700' : 'currentColor';
        const actionBtnHTML = `
        <div class="fav-action ${starClass}" title="${isFav ? 'Remove Favorite' : 'Add to Favorites'}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="${starFill}" stroke="${starStroke}" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
        </div>
        `;

        itemDiv.innerHTML = `
          <div class="left-col">
              <div class="chevron-folder"></div> 
              <div class="icon-box report-icon">
                ${iconSvg}
              </div>
              <span class="label">${escapeHtml(labelText)}</span>
          </div>
          <div class="nav-row-actions">${restrictionBadge}${actionBtnHTML}</div>
        `;
        
        const favBtn = itemDiv.querySelector('.fav-action');
        favBtn.addEventListener('click', (e) => {
            e.stopPropagation(); e.preventDefault();
            toggleFavorite(item.url);
        });
        
        return itemDiv;
    }
  }
  
  menuData.forEach(rootItem => {
      const rootNode = buildNode(rootItem, true, 0);
      if (rootNode) container.appendChild(rootNode);
  });
  
  // Inject the border lines strictly via JS to bypass the CSS first-of-type limitations
  const workspaces = container.querySelectorAll('.workspace-group');
  if (workspaces.length > 0) {
      workspaces[0].classList.add('workspace-first');
      workspaces[workspaces.length - 1].classList.add('workspace-last');
  }
}

// ==========================================
// 4. MASTER INTERACTION LOGIC
// ==========================================
function initInteractions() {
    const navContainer = document.getElementById('nav-tree-container');
    if (navContainer && !navContainer.dataset.listener) {
        navContainer.addEventListener('click', (e) => {
            const folder = e.target.closest('.nav-item.folder');
            if (folder) {
                // Ignore clicks if they specifically clicked the refresh or url buttons
                if (e.target.closest('.workspace-action-refresh') || e.target.closest('.folder-url-action') || e.target.closest('.restriction-badge')) return;
                
                e.preventDefault(); e.stopPropagation();
                const parentGroup = folder.closest('.nav-group');
                if (parentGroup.classList.contains('expanded')) {
                    parentGroup.classList.remove('expanded');
                    const chevron = folder.querySelector('.chevron-folder');
                    if(chevron) chevron.innerHTML = '<polyline points="9 18 15 12 9 6"></polyline>';
                } else {
                    parentGroup.classList.add('expanded');
                    const chevron = folder.querySelector('.chevron-folder');
                    if(chevron) chevron.innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
                }
                return;
            }

            const reportItem = e.target.closest('.nav-item.report');
            if (reportItem) {
                if (e.target.closest('.fav-action') || e.target.closest('.restriction-badge')) return;
                
                e.preventDefault(); e.stopPropagation();

                let url = reportItem.getAttribute('data-url');
                let isNewTab = reportItem.getAttribute('data-new-tab') === 'true';

                if (url && url !== "undefined" && url !== "#") {
                    if (!url.startsWith('http') && !url.startsWith('//') && !url.startsWith('chrome-extension')) {
                        url = chrome.runtime.getURL(url);
                    }
                    if (!isSafeOpenUrl(url)) return;
                    if (isNewTab) {
                        window.open(url, '_blank');
                    } else {
                        localStorage.setItem('sidebar-floating', 'false');
                        localStorage.setItem('sidebar-mini', 'true');
                        window.parent.location.href = url;
                    }
                }
            }
        });
        navContainer.dataset.listener = "true";
    }

    const searchInput = document.querySelector('.search-box input');
    if (searchInput && !searchInput.dataset.listener) {
        searchInput.addEventListener('input', (e) => {
          const term = e.target.value.toLowerCase().trim();
          const allGroups = document.querySelectorAll('.nav-group');
          const allReports = document.querySelectorAll('.nav-item.report');
          if (term === '') {
            allGroups.forEach(g => {
                g.style.display = 'block';
                if (!g.querySelector('.active-selection')) g.classList.remove('expanded'); 
            });
            allReports.forEach(r => r.style.display = 'flex');
            return;
          }
          allGroups.forEach(g => g.style.display = 'none');
          allReports.forEach(r => r.style.display = 'none');
          const matches = [];
          allReports.forEach(r => { if (r.getAttribute('data-search-label').includes(term)) matches.push(r); });
          allGroups.forEach(g => { if (g.getAttribute('data-search-label').includes(term)) matches.push(g); });
          matches.forEach(match => {
              match.style.display = (match.classList.contains('nav-group')) ? 'block' : 'flex';
              if (match.classList.contains('nav-group')) {
                 match.classList.add('expanded');
                 const children = match.querySelectorAll(':scope > .sub-menu > .nav-item, :scope > .sub-menu > .nav-group');
                 children.forEach(c => c.style.display = (c.classList.contains('nav-group')) ? 'block' : 'flex');
              }
              let parent = match.parentElement.closest('.nav-group');
              while (parent) {
                  parent.style.display = 'block';
                  parent.classList.add('expanded');
                  parent = parent.parentElement.closest('.nav-group');
              }
          });
        });
        searchInput.dataset.listener = "true";
    }
}
