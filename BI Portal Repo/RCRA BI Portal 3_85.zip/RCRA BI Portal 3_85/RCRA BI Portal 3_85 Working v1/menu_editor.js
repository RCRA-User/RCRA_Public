// ==========================================
// RCRA MENU EDITOR - MAIN LOGIC
// ==========================================

// Global State
let rootData = [];
let settingsData = {
    portalName: "RCRA BI Portal",
    defaultSide: "left",
    showLayoutBtns: true,
    welcomeTitle: "👋 Welcome!",
    welcomeDesc: "RCRA BI Portal Extension",
    welcomeSteps: [], 
    customCss: "",
    approvedDomains: ["wellstar.org"],
    accessDeniedTitle: "RCRA BI Portal Access Not Verified",
    accessDeniedMessage: "Your menu is hidden because this Power BI account is not currently recognized as an approved facility user.\n\nPlease confirm you are signed into Power BI with your approved facility email address, then refresh this page.\n\nIf you believe you should have access, contact your RCRA BI Portal administrator and include the email address shown in your Power BI profile.",
    globalAlerts: [],
    securityGroups: []
};

let selectedPath = null;
let selectedSecurityGroupId = null;
let activeAlertTargetCard = null;
let activeAlertTargetSelection = new Set();
let alertTargetSearch = "";
let alertTargetCollapsedFolders = new Set();
let closeAllowedGroupsDropdown = null;
let currentMenuSha = null;
let currentSettingsSha = null;
let loadedMenuSnapshot = [];
let loadedSettingsSnapshot = {};
let dragSrcPath = null; 
let portalConfig = {
    githubOwner: 'RCRA-User',
    githubRepo: 'RCRA_Public',
    githubBranch: 'main',
    menuPath: 'menu2.json',
    settingsPath: 'settings.json',
    defaultHomeUrl: 'https://app.powerbi.com/home',
    publicWorkspaceId: '8d966faa-0abd-4694-b3b0-be795b35ef5e',
    publicWorkspaceName: 'RCRA Public Workspace',
    workspaces: [
        { id: '8d966faa-0abd-4694-b3b0-be795b35ef5e', name: 'RCRA Public Workspace', autoExpandOnMatch: true }
    ],
    itemTypeFilters: ['Report', 'Exploration'],
    myWorkspaceItemTypeFilters: [],
    workspaceItemTypeFilters: {},
    syncPeriodMinutes: 5,
    minSyncIntervalMinutes: 2
};

function escapeHtml(value = '') {
    return String(value).replace(/[&<>"']/g, ch => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[ch]));
}

// --- INIT ---
document.addEventListener('DOMContentLoaded', () => {
    console.log("Admin Editor Loaded");

    initConfig();

    const owner = localStorage.getItem('gh_owner');
    const repo = localStorage.getItem('gh_repo');
    const path = localStorage.getItem('gh_path');
    const settingsPath = localStorage.getItem('gh_settings_path') || portalConfig.settingsPath;
    const token = sessionStorage.getItem('gh_token') || localStorage.getItem('gh_token');
    localStorage.removeItem('gh_token');

    if(owner) document.getElementById('gh-owner').value = owner;
    if(repo) document.getElementById('gh-repo').value = repo;
    if(path) document.getElementById('gh-path').value = path;
    if(settingsPath) document.getElementById('gh-settings-path').value = settingsPath;
    if(token) document.getElementById('gh-token').value = token;

    document.getElementById('btn-save-creds').addEventListener('click', saveCreds);
    document.getElementById('btn-load').addEventListener('click', loadFromCloud);
    document.getElementById('btn-publish').addEventListener('click', publishToCloud);
    document.getElementById('btn-save-config').addEventListener('click', savePortalConfig);
    document.getElementById('btn-apply-config-to-github').addEventListener('click', applyConfigToGithubFields);
    document.getElementById('btn-add-workspace').addEventListener('click', () => {
        portalConfig.workspaces = readWorkspaceConfigList({ includeIncomplete: true });
        portalConfig.workspaces.push({ name: 'New Workspace', id: '', autoExpandOnMatch: true });
        renderWorkspaceConfigList();
    });
    
    document.getElementById('btn-add-root').addEventListener('click', () => addItem(true));
    document.getElementById('btn-update').addEventListener('click', updateItem);
    document.getElementById('btn-delete').addEventListener('click', deleteItem);
    document.getElementById('inp-type').addEventListener('change', toggleUI);
    document.getElementById('btn-add-sub-folder').addEventListener('click', () => addItem(false, 'folder'));
    document.getElementById('btn-add-sub-link').addEventListener('click', () => addItem(false, 'report'));
    document.getElementById('btn-up').addEventListener('click', () => moveItem(-1));
    document.getElementById('btn-down').addEventListener('click', () => moveItem(1));

    document.getElementById('btn-save-global').addEventListener('click', saveGlobalSettings);
    document.getElementById('btn-add-global-alert').addEventListener('click', () => {
        saveGlobalAlertsToData();
        settingsData.globalAlerts = settingsData.globalAlerts || [];
        const newAlert = createDefaultAlert();
        settingsData.globalAlerts.push(newAlert);
        renderGlobalAlerts(newAlert.id);
    });
    document.getElementById('btn-save-alerts').addEventListener('click', () => {
        saveGlobalAlertsToData();
        toast("Alerts Saved to Memory (Don't forget to Publish!)");
    });
    document.getElementById('btn-alert-target-close').addEventListener('click', closeAlertTargetModal);
    document.getElementById('btn-alert-target-cancel').addEventListener('click', closeAlertTargetModal);
    document.getElementById('btn-alert-target-save').addEventListener('click', saveAlertTargetModal);
    document.getElementById('btn-alert-target-clear').addEventListener('click', () => {
        activeAlertTargetSelection.clear();
        renderAlertTargetModal();
    });
    document.getElementById('btn-alert-target-select-visible').addEventListener('click', () => {
        getPageUrlsFromTargetTree(getVisibleAlertTargetTree()).forEach(url => activeAlertTargetSelection.add(url));
        renderAlertTargetModal();
    });
    document.getElementById('alert-target-search').addEventListener('input', (event) => {
        alertTargetSearch = event.target.value;
        renderAlertTargetModal();
    });
    document.getElementById('btn-add-security-group').addEventListener('click', () => {
        saveSecurityGroupsToData();
        settingsData.securityGroups = settingsData.securityGroups || [];
        const newGroup = { id: `group_${Date.now()}`, name: "New Group", emails: [] };
        settingsData.securityGroups.push(newGroup);
        selectedSecurityGroupId = newGroup.id;
        renderSecurityGroups();
        renderAllowedGroups();
    });
    document.getElementById('btn-save-security').addEventListener('click', () => {
        saveSecurityGroupsToData();
        renderSecurityGroups();
        renderAllowedGroups(selectedPath ? getSelectedAllowedGroups() : []);
        toast("Security Groups Saved to Memory (Don't forget to Publish!)");
    });
    
    document.getElementById('btn-add-step').addEventListener('click', () => {
        saveWelcomeStepsToData(); 
        settingsData.welcomeSteps = settingsData.welcomeSteps || [];
        settingsData.welcomeSteps.push({ icon: "📌", title: "New Step", text: "Description here..." });
        renderWelcomeSteps();
    });

    document.getElementById('btn-test-identity').addEventListener('click', testIdentity);
    document.getElementById('btn-test-groups').addEventListener('click', testGroups);

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => activateTab(e.currentTarget.getAttribute('data-target')));
    });

    if (token && owner && repo) {
        loadFromCloud();
    } else {
        toast("System Ready - Please set GitHub Credentials");
    }
});

async function initConfig() {
    try {
        const stored = await chrome.storage.local.get('rcraPortalConfig');
        portalConfig = { ...portalConfig, ...(stored.rcraPortalConfig || {}) };
    } catch(e) {}
    populateConfigUI();
    applyConfigToWorkspaceOptions();
    if (!document.getElementById('gh-owner')?.value) document.getElementById('gh-owner').value = portalConfig.githubOwner;
    if (!document.getElementById('gh-repo')?.value) document.getElementById('gh-repo').value = portalConfig.githubRepo;
    if (!document.getElementById('gh-path')?.value) document.getElementById('gh-path').value = portalConfig.menuPath;
    if (!document.getElementById('gh-settings-path')?.value) document.getElementById('gh-settings-path').value = portalConfig.settingsPath;
}

function populateConfigUI() {
    const set = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.value = value ?? '';
    };
    set('cfg-owner', portalConfig.githubOwner);
    set('cfg-repo', portalConfig.githubRepo);
    set('cfg-branch', portalConfig.githubBranch);
    set('cfg-menu-path', portalConfig.menuPath);
    set('cfg-settings-path', portalConfig.settingsPath);
    set('cfg-home-url', portalConfig.defaultHomeUrl);
    set('cfg-item-types', (portalConfig.itemTypeFilters || ['Report', 'Exploration']).join(', '));
    set('cfg-my-workspace-item-types', (portalConfig.myWorkspaceItemTypeFilters || []).join(', '));
    set('cfg-sync-period', portalConfig.syncPeriodMinutes);
    set('cfg-min-sync', portalConfig.minSyncIntervalMinutes);
    renderWorkspaceConfigList();
}

function readPortalConfigFromUI() {
    const workspaces = readWorkspaceConfigList();
    return {
        githubOwner: document.getElementById('cfg-owner').value.trim(),
        githubRepo: document.getElementById('cfg-repo').value.trim(),
        githubBranch: document.getElementById('cfg-branch').value.trim() || 'main',
        menuPath: document.getElementById('cfg-menu-path').value.trim() || 'menu2.json',
        settingsPath: document.getElementById('cfg-settings-path').value.trim() || 'settings.json',
        defaultHomeUrl: document.getElementById('cfg-home-url').value.trim() || 'https://app.powerbi.com/home',
        publicWorkspaceId: workspaces[0]?.id || '',
        publicWorkspaceName: workspaces[0]?.name || 'Public Workspace',
        workspaces,
        itemTypeFilters: parseItemTypes(document.getElementById('cfg-item-types')?.value || 'Report, Exploration'),
        myWorkspaceItemTypeFilters: parseItemTypes(document.getElementById('cfg-my-workspace-item-types')?.value || ''),
        workspaceItemTypeFilters: Object.fromEntries(workspaces.filter(ws => ws.itemTypes?.length > 0).map(ws => [ws.id, ws.itemTypes])),
        syncPeriodMinutes: Math.max(1, Number(document.getElementById('cfg-sync-period').value) || 5),
        minSyncIntervalMinutes: Math.max(1, Number(document.getElementById('cfg-min-sync').value) || 2)
    };
}

function parseItemTypes(value) {
    return [...new Set(String(value || '').split(',').map(type => type.trim()).filter(Boolean))];
}

function normalizeApprovedDomains(value) {
    const source = Array.isArray(value) ? value : String(value || '').split(/[\n,;]/);
    return [...new Set(source
        .map(domain => String(domain || '').trim().toLowerCase().replace(/^@+/, ''))
        .filter(domain => /^[a-z0-9.-]+\.[a-z]{2,}$/.test(domain)))];
}

function createDefaultAlert() {
    return {
        id: `alert_${Date.now()}_${Math.floor(Math.random() * 100000)}`,
        enabled: true,
        severity: "info",
        scope: "global",
        placement: "sidebar",
        title: "Alert title",
        message: "Alert message",
        dismissible: true,
        reshowOnEdit: true,
        dismissVersion: "",
        startAt: "",
        endAt: "",
        targetUrls: []
    };
}

function normalizeAlert(alert = {}) {
    const severity = ["info", "warning", "critical"].includes(alert.severity) ? alert.severity : "info";
    const scope = ["global", "page"].includes(alert.scope) ? alert.scope : "global";
    const rawPlacement = ["sidebar", "overlay"].includes(alert.placement) ? alert.placement : "sidebar";
    const placement = scope === "page" ? "overlay" : rawPlacement;
    const targetSource = Array.isArray(alert.targetUrls) ? alert.targetUrls : (Array.isArray(alert.pageUrls) ? alert.pageUrls : []);
    return {
        id: String(alert.id || `alert_${Date.now()}_${Math.floor(Math.random() * 100000)}`),
        enabled: alert.enabled !== false,
        severity,
        scope,
        placement,
        title: String(alert.title || "").trim(),
        message: String(alert.message || "").trim(),
        dismissible: alert.dismissible !== false,
        reshowOnEdit: alert.reshowOnEdit !== false,
        dismissVersion: String(alert.dismissVersion || "").trim(),
        startAt: String(alert.startAt || "").trim(),
        endAt: String(alert.endAt || "").trim(),
        targetUrls: scope === "page" ? [...new Set(targetSource.map(url => String(url || "").trim()).filter(Boolean))] : []
    };
}

function normalizeAlerts(alerts = []) {
    return (Array.isArray(alerts) ? alerts : [])
        .map(normalizeAlert)
        .filter(alert => alert.title || alert.message);
}

function getAlertFingerprint(alert = {}) {
    const normalized = normalizeAlert(alert);
    return JSON.stringify({
        enabled: normalized.enabled,
        severity: normalized.severity,
        scope: normalized.scope,
        placement: normalized.placement,
        title: normalized.title,
        message: normalized.message,
        dismissible: normalized.dismissible,
        startAt: normalized.startAt,
        endAt: normalized.endAt,
        targetUrls: normalized.targetUrls
    });
}

function alertValueForDateTimeInput(value = '') {
    if (!value) return '';
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return String(value).slice(0, 16);
    const offsetMs = date.getTimezoneOffset() * 60000;
    return new Date(date.getTime() - offsetMs).toISOString().slice(0, 16);
}

function alertValueFromDateTimeInput(value = '') {
    if (!value) return '';
    const date = new Date(value);
    return Number.isFinite(date.getTime()) ? date.toISOString() : '';
}

function getAlertTargetOptions(items = rootData) {
    const targets = [];
    const seen = new Set();
    const visit = (nodes = [], pathParts = []) => {
        nodes.forEach(item => {
            const label = item.category || item.name || "Untitled";
            const nextPath = [...pathParts, label];
            if (item.url) {
                const url = String(item.url || "").trim();
                if (url && !seen.has(url)) {
                    seen.add(url);
                    targets.push({ label: nextPath.join(" / "), url });
                }
            }
            if (Array.isArray(item.items)) visit(item.items, nextPath);
        });
    };
    visit(items);
    return targets;
}

function getAlertTargetTree(items = rootData) {
    const seen = new Set();
    const visit = (nodes = [], pathParts = []) => {
        const result = [];
        nodes.forEach((item, index) => {
            const label = item.category || item.name || "Untitled";
            const nextPath = [...pathParts, label];
            const children = Array.isArray(item.items) ? visit(item.items, nextPath) : [];
            if (item.url) {
                const url = String(item.url || "").trim();
                if (url && !seen.has(url)) {
                    seen.add(url);
                    result.push({
                        type: "page",
                        id: `page_${seen.size}`,
                        label,
                        path: nextPath.join(" / "),
                        url
                    });
                }
            }
            if (children.length > 0) {
                result.push({
                    type: "folder",
                    id: `folder_${nextPath.join("_")}_${index}`,
                    label,
                    path: nextPath.join(" / "),
                    children
                });
            }
        });
        return result;
    };
    return visit(items);
}

function getPageUrlsFromTargetTree(nodes = []) {
    const urls = [];
    const visit = (items = []) => {
        items.forEach(item => {
            if (item.type === "page" && item.url) urls.push(item.url);
            if (item.children) visit(item.children);
        });
    };
    visit(nodes);
    return urls;
}

function getFolderIdsFromTargetTree(nodes = []) {
    const ids = [];
    const visit = (items = []) => {
        items.forEach(item => {
            if (item.type === "folder") ids.push(item.id);
            if (item.children) visit(item.children);
        });
    };
    visit(nodes);
    return ids;
}

function getVisibleAlertTargetTree() {
    const tree = getAlertTargetTree();
    const query = String(alertTargetSearch || "").trim().toLowerCase();
    if (!query) return tree;

    const matchesNode = node => `${node.label} ${node.path || ""} ${node.url || ""}`.toLowerCase().includes(query);
    const filterNodes = nodes => nodes
        .map(node => {
            if (node.type === "page") return matchesNode(node) ? node : null;
            const filteredChildren = filterNodes(node.children || []);
            if (matchesNode(node)) return { ...node };
            return filteredChildren.length > 0 ? { ...node, children: filteredChildren } : null;
        })
        .filter(Boolean);

    return filterNodes(tree);
}

function parseAlertTargetUrls(value = "") {
    try {
        const parsed = JSON.parse(value || "[]");
        return Array.isArray(parsed) ? parsed.map(url => String(url || "").trim()).filter(Boolean) : [];
    } catch(e) {
        return [];
    }
}

function getAlertTargetOptionsByUrl() {
    return new Map(getAlertTargetOptions().map(option => [option.url, option]));
}

function migratePageAlertsIntoSettings() {
    const alertsById = new Map(normalizeAlerts(settingsData.globalAlerts || []).map(alert => [alert.id, alert]));
    const visit = (nodes = []) => {
        nodes.forEach(item => {
            if (item.url && Array.isArray(item.pageAlerts) && item.pageAlerts.length > 0) {
                item.pageAlerts.forEach(rawAlert => {
                    const alert = normalizeAlert(rawAlert);
                    alert.scope = "page";
                    alert.targetUrls = [String(item.url || "").trim()].filter(Boolean);
                    const existing = alertsById.get(alert.id);
                    if (existing) {
                        existing.scope = "page";
                        existing.placement = existing.placement || alert.placement;
                        existing.targetUrls = [...new Set([...(existing.targetUrls || []), ...alert.targetUrls])];
                    } else {
                        alertsById.set(alert.id, alert);
                    }
                });
                delete item.pageAlerts;
            }
            if (Array.isArray(item.items)) visit(item.items);
        });
    };
    visit(rootData);
    settingsData.globalAlerts = [...alertsById.values()];
}

function normalizeWorkspaces(options = {}) {
    const { keepIncomplete = false } = options;
    const current = Array.isArray(portalConfig.workspaces) ? portalConfig.workspaces : [];
    portalConfig.workspaces = current
        .map(ws => ({
            id: String(ws.id || '').trim(),
            name: String(ws.name || '').trim(),
            itemTypes: parseItemTypes(ws.itemTypes || portalConfig.workspaceItemTypeFilters?.[ws.id] || ''),
            autoExpandOnMatch: ws.autoExpandOnMatch !== false
        }))
        .filter(ws => keepIncomplete ? (ws.id || ws.name) : ws.id);
    if (portalConfig.workspaces.length === 0 && portalConfig.publicWorkspaceId) {
        portalConfig.workspaces = [{ id: portalConfig.publicWorkspaceId, name: portalConfig.publicWorkspaceName || 'Public Workspace', autoExpandOnMatch: true }];
    }
}

function renderWorkspaceConfigList() {
    normalizeWorkspaces({ keepIncomplete: true });
    const list = document.getElementById('workspace-config-list');
    if (!list) return;
    list.innerHTML = '';
    portalConfig.workspaces.forEach((workspace, index) => {
        const row = document.createElement('div');
        row.className = 'workspace-config-row';
        row.innerHTML = `
            <div class="workspace-config-fields">
                <div class="workspace-config-field">
                    <label>Workspace Name</label>
                    <input type="text" class="workspace-name" placeholder="Workspace name" value="${escapeHtml(workspace.name)}">
                </div>
                <div class="workspace-config-field">
                    <label>Workspace GUID</label>
                    <input type="text" class="workspace-id" placeholder="Workspace GUID" value="${escapeHtml(workspace.id)}">
                </div>
                <div class="workspace-config-field">
                    <label>Item Types for This Workspace</label>
                    <input type="text" class="workspace-item-types" placeholder="Blank = global filter" value="${escapeHtml((workspace.itemTypes || []).join(', '))}" title="Optional. Leave blank to use global item type filters. Example: Report, Exploration">
                    <div class="field-note">Example: Report, Exploration</div>
                </div>
                <div class="workspace-config-field">
                    <label>Menu Behavior</label>
                    <div class="check-group" style="margin-top:0; min-height: 20px;">
                        <input type="checkbox" class="workspace-auto-expand" ${workspace.autoExpandOnMatch !== false ? 'checked' : ''}>
                        <label>Auto-expand on matching report</label>
                    </div>
                    <div class="field-note">Turn off to keep this workspace collapsed when the current URL matches an item inside it.</div>
                </div>
            </div>
            <button class="btn btn-danger btn-remove-workspace" type="button" data-idx="${index}">Remove</button>
        `;
        list.appendChild(row);
    });
    list.querySelectorAll('.btn-remove-workspace').forEach(btn => {
        btn.addEventListener('click', () => {
            portalConfig.workspaces.splice(Number(btn.dataset.idx), 1);
            renderWorkspaceConfigList();
        });
    });
}

function readWorkspaceConfigList(options = {}) {
    const { includeIncomplete = false } = options;
    const rows = document.querySelectorAll('#workspace-config-list .workspace-config-row');
    return Array.from(rows).map(row => ({
        name: row.querySelector('.workspace-name').value.trim(),
        id: row.querySelector('.workspace-id').value.trim(),
        itemTypes: parseItemTypes(row.querySelector('.workspace-item-types')?.value || ''),
        autoExpandOnMatch: row.querySelector('.workspace-auto-expand')?.checked !== false
    })).filter(ws => includeIncomplete ? (ws.id || ws.name) : ws.id);
}

function savePortalConfig() {
    portalConfig = readPortalConfigFromUI();
    chrome.runtime.sendMessage({ action: 'SAVE_PORTAL_CONFIG', config: portalConfig }, (response) => {
        if (response?.success) {
            portalConfig = response.config;
            applyConfigToGithubFields();
            applyConfigToWorkspaceOptions();
            toast("System configuration saved");
        } else {
            alert("Config Save Error: " + (response?.error || "Unknown error"));
        }
    });
}

function applyConfigToGithubFields() {
    document.getElementById('gh-owner').value = portalConfig.githubOwner;
    document.getElementById('gh-repo').value = portalConfig.githubRepo;
    document.getElementById('gh-path').value = portalConfig.menuPath;
    document.getElementById('gh-settings-path').value = portalConfig.settingsPath;
    toast("GitHub fields updated from System Config");
}

function applyConfigToWorkspaceOptions() {
    normalizeWorkspaces();
    const select = document.getElementById('inp-workspace-id');
    if (!select) return;
    const selected = select.value;
    select.innerHTML = '';
    const personal = document.createElement('option');
    personal.value = 'personal';
    personal.textContent = 'My Workspace (Personal)';
    select.appendChild(personal);
    portalConfig.workspaces.forEach(workspace => {
        const option = document.createElement('option');
        option.value = workspace.id;
        option.textContent = workspace.name || workspace.id;
        select.appendChild(option);
    });
    if ([...select.options].some(option => option.value === selected)) select.value = selected;
}

// ==========================================
// TABS & GLOBAL SETTINGS LOGIC
// ==========================================
function activateTab(targetId) {
    const target = document.getElementById(targetId);
    const tab = document.querySelector(`.tab-btn[data-target="${targetId}"]`);
    if (!target || !tab) return;
    if (targetId === 'view-alerts') {
        saveGlobalAlertsToData();
        renderGlobalAlerts();
    }

    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    tab.classList.add('active');
    target.classList.add('active');
}

function populateGlobalSettingsUI() {
    document.getElementById('set-portal-name').value = settingsData.portalName || "RCRA BI Portal";
    document.getElementById('set-default-side').value = settingsData.defaultSide || "left";
    document.getElementById('set-show-layout').checked = settingsData.showLayoutBtns !== false;
    document.getElementById('set-welcome-title').value = settingsData.welcomeTitle || "👋 Welcome!";
    document.getElementById('set-welcome-desc').value = settingsData.welcomeDesc || "RCRA BI Portal Extension";
    document.getElementById('set-approved-domains').value = normalizeApprovedDomains(settingsData.approvedDomains || []).join('\n');
    document.getElementById('set-access-denied-title').value = settingsData.accessDeniedTitle || "RCRA BI Portal Access Not Verified";
    document.getElementById('set-access-denied-message').value = settingsData.accessDeniedMessage || "Your menu is hidden because this Power BI account is not currently recognized as an approved facility user.\n\nPlease confirm you are signed into Power BI with your approved facility email address, then refresh this page.\n\nIf you believe you should have access, contact your RCRA BI Portal administrator and include the email address shown in your Power BI profile.";
    document.getElementById('set-custom-css').value = settingsData.customCss || "";
    
    renderWelcomeSteps();
    settingsData.globalAlerts = normalizeAlerts(settingsData.globalAlerts || []);
    renderGlobalAlerts();
    renderSecurityGroups();
}

function renderSecurityGroups() {
    normalizeSecurityGroups();
    const list = document.getElementById('security-group-list');
    if (!list) return;
    list.innerHTML = '';

    if (settingsData.securityGroups.length > 0 && !settingsData.securityGroups.some(group => group.id === selectedSecurityGroupId)) {
        selectedSecurityGroupId = settingsData.securityGroups[0].id;
    }

    settingsData.securityGroups.forEach(group => {
        const card = document.createElement('div');
        card.className = `security-group-card ${group.id === selectedSecurityGroupId ? 'active' : ''}`;
        card.innerHTML = `
            <strong>${escapeHtml(group.name || 'Unnamed Group')}</strong>
            <span>${(group.emails || []).length} member${(group.emails || []).length === 1 ? '' : 's'}</span>
        `;
        card.addEventListener('click', () => {
            saveSecurityGroupsToData();
            selectedSecurityGroupId = group.id;
            renderSecurityGroups();
        });
        list.appendChild(card);
    });
    renderSecurityGroupDetail();
}

function saveSecurityGroupsToData() {
    syncSelectedSecurityGroupDetail();
    normalizeSecurityGroups();
}

function normalizeSecurityGroups() {
    settingsData.securityGroups = (settingsData.securityGroups || []).map((group, index) => ({
        id: group.id || `group_${Date.now()}_${index}`,
        name: String(group.name || 'Unnamed Group').trim() || 'Unnamed Group',
        emails: uniqueEmails(group.emails || [])
    }));
}

function getSelectedSecurityGroup() {
    return (settingsData.securityGroups || []).find(group => group.id === selectedSecurityGroupId) || null;
}

function openSecurityGroup(groupId) {
    if (!groupId) return;
    saveSecurityGroupsToData();
    if (selectedPath) updateItem();
    selectedSecurityGroupId = groupId;
    activateTab('view-security');
    renderSecurityGroups();
}

function uniqueEmails(values) {
    return [...new Set((values || [])
        .map(email => String(email).trim().toLowerCase())
        .filter(email => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)))];
}

function parseEmailsFromText(text) {
    return uniqueEmails(String(text || '').match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || []);
}

function syncSelectedSecurityGroupDetail() {
    const group = getSelectedSecurityGroup();
    if (!group) return;
    const nameInput = document.getElementById('security-detail-name');
    if (nameInput) group.name = nameInput.value.trim() || 'Unnamed Group';
}

function renderSecurityGroupDetail() {
    const detail = document.getElementById('security-group-detail');
    if (!detail) return;
    const group = getSelectedSecurityGroup();
    if (!group) {
        detail.innerHTML = '<div class="security-detail-empty">Select a group or add a new one.</div>';
        return;
    }

    detail.innerHTML = `
        <div class="form-grid" style="grid-template-columns: 1fr auto; align-items: end;">
            <div>
                <label>Group Name</label>
                <input type="text" id="security-detail-name" value="${escapeHtml(group.name)}" placeholder="Group name">
            </div>
            <button class="btn btn-danger" id="btn-delete-security-group" type="button">Delete Group</button>
        </div>

        <div class="section-title">Members</div>
        <div style="display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 10px; align-items: end;">
            <div>
                <label>Add Email</label>
                <input type="text" id="security-member-email" placeholder="person@company.com">
            </div>
            <button class="btn btn-secondary" id="btn-add-security-member" type="button">Add to Group</button>
        </div>
        <div id="security-members-list" class="security-groups-list" style="margin-top: 12px;"></div>

        <div class="section-title">Bulk Upload</div>
        <div class="security-import-box">
            <label>CSV File</label>
            <input type="file" id="security-bulk-file" accept=".csv,text/csv,text/plain">
            <div class="field-note">CSV can contain an email column or plain rows of email addresses. Duplicate and invalid emails are ignored.</div>
            <button class="btn btn-secondary" id="btn-import-security-csv" type="button" style="margin-top: 12px;">Import CSV</button>
        </div>
        <div class="security-import-box" style="margin-top: 12px;">
            <label>Paste Email List</label>
            <textarea id="security-bulk-text" placeholder="person1@company.com, person2@company.com&#10;person3@company.com" style="min-height: 110px;"></textarea>
            <div class="field-note">Paste comma-separated, semicolon-separated, or newline-separated emails. Whitespace is trimmed automatically.</div>
            <button class="btn btn-secondary" id="btn-import-security-text" type="button" style="margin-top: 12px;">Import Pasted Emails</button>
        </div>
    `;

    document.getElementById('security-detail-name').addEventListener('input', (e) => {
        group.name = e.target.value.trim() || 'Unnamed Group';
    });
    document.getElementById('security-detail-name').addEventListener('blur', () => {
        renderSecurityGroups();
    });
    document.getElementById('btn-delete-security-group').addEventListener('click', () => {
        if (!confirm("Delete this security group? It will also be removed from menu item rules.")) return;
        settingsData.securityGroups = settingsData.securityGroups.filter(item => item.id !== group.id);
        removeDeletedGroupFromMenu(group.id);
        selectedSecurityGroupId = settingsData.securityGroups[0]?.id || null;
        renderSecurityGroups();
        renderAllowedGroups();
    });
    document.getElementById('btn-add-security-member').addEventListener('click', () => addMemberToSelectedGroup());
    document.getElementById('security-member-email').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            addMemberToSelectedGroup();
        }
    });
    document.getElementById('btn-import-security-csv').addEventListener('click', importCsvToSelectedGroup);
    document.getElementById('btn-import-security-text').addEventListener('click', importTextToSelectedGroup);
    renderSecurityMembers();
}

function addMemberToSelectedGroup() {
    const group = getSelectedSecurityGroup();
    const input = document.getElementById('security-member-email');
    if (!group || !input) return;
    const emails = parseEmailsFromText(input.value);
    if (emails.length === 0) return toast("Enter a valid email address");
    group.emails = uniqueEmails([...(group.emails || []), ...emails]);
    input.value = '';
    renderSecurityMembers();
    renderSecurityGroups();
}

function renderSecurityMembers() {
    const group = getSelectedSecurityGroup();
    const list = document.getElementById('security-members-list');
    if (!group || !list) return;
    list.innerHTML = '';
    const emails = uniqueEmails(group.emails || []);
    group.emails = emails;
    if (emails.length === 0) {
        list.innerHTML = '<div class="field-note">No members yet.</div>';
        return;
    }
    emails.forEach(email => {
        const row = document.createElement('div');
        row.className = 'security-member-row';
        row.innerHTML = `<span>${escapeHtml(email)}</span><button class="btn btn-danger btn-remove-security-member" type="button" data-email="${escapeHtml(email)}">Remove</button>`;
        list.appendChild(row);
    });
    list.querySelectorAll('.btn-remove-security-member').forEach(btn => {
        btn.addEventListener('click', () => {
            group.emails = (group.emails || []).filter(email => email !== btn.dataset.email);
            renderSecurityMembers();
            renderSecurityGroups();
        });
    });
}

function importCsvToSelectedGroup() {
    const group = getSelectedSecurityGroup();
    const fileInput = document.getElementById('security-bulk-file');
    const file = fileInput?.files?.[0];
    if (!group || !file) return toast("Choose a CSV file first");
    const reader = new FileReader();
    reader.onload = () => {
        const emails = parseEmailsFromText(reader.result);
        group.emails = uniqueEmails([...(group.emails || []), ...emails]);
        renderSecurityMembers();
        renderSecurityGroups();
        toast(`Imported ${emails.length} email${emails.length === 1 ? '' : 's'}`);
    };
    reader.readAsText(file);
}

function importTextToSelectedGroup() {
    const group = getSelectedSecurityGroup();
    const input = document.getElementById('security-bulk-text');
    if (!group || !input) return;
    const emails = parseEmailsFromText(input.value);
    if (emails.length === 0) return toast("Paste at least one valid email address");
    group.emails = uniqueEmails([...(group.emails || []), ...emails]);
    input.value = '';
    renderSecurityMembers();
    renderSecurityGroups();
    toast(`Imported ${emails.length} email${emails.length === 1 ? '' : 's'}`);
}

function removeDeletedGroupFromMenu(groupId) {
    if (!groupId) return;
    const visit = (items) => {
        items.forEach(item => {
            if (Array.isArray(item.allowedGroups)) {
                item.allowedGroups = item.allowedGroups.filter(id => id !== groupId);
                if (item.allowedGroups.length === 0) delete item.allowedGroups;
            }
            if (Array.isArray(item.items)) visit(item.items);
        });
    };
    visit(rootData);
}

function renderAllowedGroups(selectedGroupIds = []) {
    const box = document.getElementById('allowed-groups-list');
    if (!box) return;
    if (closeAllowedGroupsDropdown) {
        document.removeEventListener('click', closeAllowedGroupsDropdown);
        closeAllowedGroupsDropdown = null;
    }
    saveSecurityGroupsToData();
    const selected = new Set(selectedGroupIds || []);
    box.innerHTML = '';

    if (!settingsData.securityGroups || settingsData.securityGroups.length === 0) {
        box.innerHTML = '<div class="field-note">No security groups yet. Add groups under the Security Groups tab.</div>';
        return;
    }

    const dropdown = document.createElement('div');
    dropdown.className = 'allowed-groups-dropdown';
    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'allowed-groups-trigger';
    const triggerText = document.createElement('span');
    trigger.appendChild(triggerText);
    const menu = document.createElement('div');
    menu.className = 'allowed-groups-menu';
    const updateSummary = () => {
        const checked = Array.from(menu.querySelectorAll('input:checked')).map(input => {
            const group = settingsData.securityGroups.find(item => item.id === input.value);
            return group?.name || input.value;
        });
        triggerText.textContent = checked.length === 0
            ? 'Public - no security groups selected'
            : `${checked.length} group${checked.length === 1 ? '' : 's'} selected: ${checked.join(', ')}`;
    };

    settingsData.securityGroups.forEach(group => {
        const label = document.createElement('label');
        label.className = 'allowed-group-option';
        const input = document.createElement('input');
        input.type = 'checkbox';
        input.value = group.id;
        input.checked = selected.has(group.id);
        input.addEventListener('change', updateSummary);
        const span = document.createElement('span');
        span.textContent = group.name;
        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'group-edit-link';
        editBtn.textContent = 'Edit';
        editBtn.title = `Edit ${group.name}`;
        editBtn.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            openSecurityGroup(group.id);
        });
        label.append(input, span, editBtn);
        menu.appendChild(label);
    });

    trigger.addEventListener('click', (event) => {
        event.stopPropagation();
        dropdown.classList.toggle('open');
    });
    closeAllowedGroupsDropdown = (event) => {
        if (!dropdown.contains(event.target)) dropdown.classList.remove('open');
    };
    document.addEventListener('click', closeAllowedGroupsDropdown);

    dropdown.append(trigger, menu);
    box.appendChild(dropdown);
    updateSummary();
}

function getSelectedAllowedGroups() {
    return Array.from(document.querySelectorAll('#allowed-groups-list input:checked')).map(input => input.value);
}

function renderWelcomeSteps() {
    const list = document.getElementById('welcome-steps-list');
    list.innerHTML = '';
    
    if (!settingsData.welcomeSteps || settingsData.welcomeSteps.length === 0) {
        settingsData.welcomeSteps = [
            { icon: "⭐", title: "Bookmark this Page!", text: "Press <b>Ctrl + D</b> (or Cmd + D) to save this page so you can easily return to the portal later." },
            { icon: "⬅️", title: "Use the Sidebar", text: "The menu lives on the left.<br><br> Click the <b>Star Icon</b> at the top to <b>Minimize/Maximize</b> the menu." }
        ];
    }

    settingsData.welcomeSteps.forEach((step, index) => {
        const div = document.createElement('div');
        div.style.background = "#1a1a20";
        div.style.border = "1px solid #444";
        div.style.padding = "10px";
        div.style.borderRadius = "6px";
        div.style.display = "flex";
        div.style.gap = "10px";

        div.innerHTML = `
            <div style="width: 50px;">
                <input type="text" class="step-icon" value="${escapeHtml(step.icon)}" placeholder="Emoji" style="text-align:center; font-size: 18px; padding: 8px;">
            </div>
            <div style="flex: 1; display: flex; flex-direction: column; gap: 5px;">
                <input type="text" class="step-title" value="${escapeHtml(step.title)}" placeholder="Step Title">
                <textarea class="step-text" style="min-height: 40px;" placeholder="HTML allowed (e.g. <b>bold</b> or <br>)">${escapeHtml(step.text)}</textarea>
            </div>
            <div>
                <button class="btn btn-danger btn-remove-step" data-idx="${index}">X</button>
            </div>
        `;
        list.appendChild(div);
    });

    document.querySelectorAll('.btn-remove-step').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const idx = parseInt(e.target.getAttribute('data-idx'));
            saveWelcomeStepsToData(); 
            settingsData.welcomeSteps.splice(idx, 1);
            renderWelcomeSteps();
        });
    });
}

function saveWelcomeStepsToData() {
    const list = document.getElementById('welcome-steps-list');
    const items = list.children;
    const newSteps = [];
    for (let i = 0; i < items.length; i++) {
        newSteps.push({
            icon: items[i].querySelector('.step-icon').value,
            title: items[i].querySelector('.step-title').value,
            text: items[i].querySelector('.step-text').value
        });
    }
    settingsData.welcomeSteps = newSteps;
}

function readAlertsFromContainer(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return [];
    return normalizeAlerts(Array.from(container.querySelectorAll('.alert-admin-card')).map(card => {
        const alert = {
            id: card.dataset.alertId,
            enabled: card.querySelector('.alert-enabled')?.checked,
            severity: card.querySelector('.alert-severity')?.value,
            scope: card.querySelector('.alert-scope')?.value,
            placement: card.querySelector('.alert-placement')?.value,
            title: card.querySelector('.alert-title')?.value,
            message: card.querySelector('.alert-message')?.value,
            dismissible: card.querySelector('.alert-dismissible')?.checked,
            reshowOnEdit: card.querySelector('.alert-reshow-on-edit')?.checked,
            dismissVersion: card.querySelector('.alert-dismiss-version')?.value || "",
            startAt: alertValueFromDateTimeInput(card.querySelector('.alert-start')?.value || ''),
            endAt: alertValueFromDateTimeInput(card.querySelector('.alert-end')?.value || ''),
            targetUrls: parseAlertTargetUrls(card.querySelector('.alert-target-urls')?.value || "[]")
        };
        const originalFingerprint = card.dataset.alertFingerprint || "";
        const currentFingerprint = getAlertFingerprint(alert);
        if (alert.reshowOnEdit && originalFingerprint && originalFingerprint !== currentFingerprint) {
            alert.dismissVersion = `v_${Date.now()}_${Math.floor(Math.random() * 100000)}`;
        }
        return alert;
    }));
}

function setAlertsForContainer(containerId, alerts) {
    const normalized = normalizeAlerts(alerts);
    if (containerId === 'global-alerts-list') {
        settingsData.globalAlerts = normalized;
    }
}

function formatAlertChoice(value = "") {
    return String(value || "")
        .replace(/-/g, " ")
        .replace(/\b\w/g, char => char.toUpperCase());
}

function getCardTargetUrls(card) {
    return parseAlertTargetUrls(card.querySelector('.alert-target-urls')?.value || "[]");
}

function setCardTargetUrls(card, urls = []) {
    const hidden = card.querySelector('.alert-target-urls');
    if (!hidden) return;
    hidden.value = JSON.stringify([...new Set(urls.map(url => String(url || "").trim()).filter(Boolean))]);
}

function updateAlertCardSummary(card, index = null) {
    if (!card) return;
    enforceAlertPlacementRule(card);
    const title = card.querySelector('.alert-title')?.value?.trim() || "Untitled alert";
    const severity = card.querySelector('.alert-severity')?.value || "info";
    const scope = card.querySelector('.alert-scope')?.value || "global";
    const placement = card.querySelector('.alert-placement')?.value || "sidebar";
    const enabled = card.querySelector('.alert-enabled')?.checked !== false;
    const targetCount = getCardTargetUrls(card).length;
    const titleEl = card.querySelector('.alert-admin-title');
    const metaEl = card.querySelector('.alert-admin-meta');
    const targetSummary = card.querySelector('.alert-target-summary');
    const prefix = Number.isInteger(index) && index >= 0 ? `Alert ${index + 1}` : "Alert";

    if (titleEl) titleEl.textContent = `${prefix}: ${title}`;
    if (metaEl) {
        const pageText = scope === "page" ? ` • ${targetCount} page${targetCount === 1 ? "" : "s"}` : "";
        metaEl.textContent = `${enabled ? "Enabled" : "Disabled"} • ${formatAlertChoice(severity)} • ${formatAlertChoice(scope)} • ${formatAlertChoice(placement)}${pageText}`;
    }
    if (targetSummary) {
        targetSummary.textContent = `${targetCount} page${targetCount === 1 ? "" : "s"} selected`;
    }
    card.classList.toggle('is-page-alert', scope === 'page');
}

function enforceAlertPlacementRule(card) {
    const scopeSelect = card?.querySelector('.alert-scope');
    const placementSelect = card?.querySelector('.alert-placement');
    if (!scopeSelect || !placementSelect) return;
    const isPageSpecific = scopeSelect.value === "page";
    if (isPageSpecific) placementSelect.value = "overlay";
    placementSelect.disabled = isPageSpecific;
    placementSelect.title = isPageSpecific ? "Page-specific alerts are always overlays." : "";
}

function setAlertCardExpanded(card, isExpanded) {
    if (!card) return;
    card.classList.toggle('is-collapsed', !isExpanded);
    const toggle = card.querySelector('.alert-collapse-toggle');
    if (toggle) {
        toggle.textContent = isExpanded ? 'Collapse' : 'Expand';
        toggle.title = isExpanded ? 'Collapse Alert' : 'Expand Alert';
        toggle.setAttribute('aria-expanded', String(isExpanded));
    }
}

function openAlertTargetModal(card) {
    activeAlertTargetCard = card;
    activeAlertTargetSelection = new Set(getCardTargetUrls(card));
    alertTargetSearch = "";
    alertTargetCollapsedFolders = new Set(getFolderIdsFromTargetTree(getAlertTargetTree()));
    const search = document.getElementById('alert-target-search');
    if (search) search.value = "";
    const modal = document.getElementById('alert-target-modal');
    if (modal) {
        modal.classList.add('open');
        modal.setAttribute('aria-hidden', 'false');
    }
    renderAlertTargetModal();
    setTimeout(() => search?.focus(), 0);
}

function closeAlertTargetModal() {
    const modal = document.getElementById('alert-target-modal');
    if (modal) {
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden', 'true');
    }
    activeAlertTargetCard = null;
    activeAlertTargetSelection = new Set();
    alertTargetSearch = "";
}

function saveAlertTargetModal() {
    if (!activeAlertTargetCard) return closeAlertTargetModal();
    setCardTargetUrls(activeAlertTargetCard, [...activeAlertTargetSelection]);
    updateAlertCardSummary(activeAlertTargetCard, getAlertCardIndex(activeAlertTargetCard));
    setAlertsForContainer('global-alerts-list', readAlertsFromContainer('global-alerts-list'));
    closeAlertTargetModal();
}

function getAlertCardIndex(card) {
    if (!card) return -1;
    return Array.from(card.parentElement?.querySelectorAll('.alert-admin-card') || []).indexOf(card);
}

function renderAlertTargetModal() {
    const treeContainer = document.getElementById('alert-target-tree');
    const selectedList = document.getElementById('alert-target-selected-list');
    const countEl = document.getElementById('alert-target-selected-count');
    if (!treeContainer || !selectedList || !countEl) return;

    const visibleTree = getVisibleAlertTargetTree();
    treeContainer.replaceChildren();
    if (visibleTree.length === 0) {
        treeContainer.innerHTML = '<div class="alert-empty-state">No matching pages found.</div>';
    } else {
        visibleTree.forEach(node => treeContainer.appendChild(renderTargetTreeNode(node)));
    }

    const selectedUrls = [...activeAlertTargetSelection];
    const optionsByUrl = getAlertTargetOptionsByUrl();
    countEl.textContent = `${selectedUrls.length} selected`;
    selectedList.replaceChildren();

    if (selectedUrls.length === 0) {
        selectedList.innerHTML = '<div class="alert-empty-state">No pages selected yet.</div>';
        return;
    }

    selectedUrls
        .map(url => ({ url, ...(optionsByUrl.get(url) || { label: "Missing menu item", path: "Missing menu item" }) }))
        .sort((a, b) => String(a.path || a.label).localeCompare(String(b.path || b.label)))
        .forEach(target => {
            const row = document.createElement('div');
            row.className = 'selected-target-row';
            const label = document.createElement('span');
            label.className = 'target-tree-label';
            label.title = target.url;
            label.textContent = target.path || target.label || target.url;
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'btn btn-danger';
            remove.style.padding = '4px 10px';
            remove.style.fontSize = '11px';
            remove.textContent = 'Remove';
            remove.addEventListener('click', () => {
                activeAlertTargetSelection.delete(target.url);
                renderAlertTargetModal();
            });
            row.appendChild(label);
            row.appendChild(remove);
            selectedList.appendChild(row);
        });
}

function renderTargetTreeNode(node) {
    const wrapper = document.createElement('div');
    const row = document.createElement('div');
    row.className = 'target-tree-row';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';

    if (node.type === "page") {
        checkbox.checked = activeAlertTargetSelection.has(node.url);
        checkbox.addEventListener('change', () => {
            if (checkbox.checked) activeAlertTargetSelection.add(node.url);
            else activeAlertTargetSelection.delete(node.url);
            renderAlertTargetModal();
        });
        const label = document.createElement('span');
        label.className = 'target-tree-label';
        label.title = node.url;
        label.textContent = node.label;
        row.appendChild(checkbox);
        row.appendChild(label);
        wrapper.appendChild(row);
        return wrapper;
    }

    const urls = getPageUrlsFromTargetTree(node.children || []);
    const selectedCount = urls.filter(url => activeAlertTargetSelection.has(url)).length;
    const isSearching = Boolean(String(alertTargetSearch || "").trim());
    const isCollapsed = !isSearching && alertTargetCollapsedFolders.has(node.id);
    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'btn-icon target-tree-toggle';
    toggle.textContent = isCollapsed ? '+' : '-';
    toggle.title = isCollapsed ? 'Expand Folder' : 'Collapse Folder';
    toggle.addEventListener('click', () => {
        if (isCollapsed) alertTargetCollapsedFolders.delete(node.id);
        else alertTargetCollapsedFolders.add(node.id);
        renderAlertTargetModal();
    });
    checkbox.checked = urls.length > 0 && selectedCount === urls.length;
    checkbox.indeterminate = selectedCount > 0 && selectedCount < urls.length;
    checkbox.addEventListener('change', () => {
        const shouldSelect = selectedCount < urls.length;
        urls.forEach(url => {
            if (shouldSelect) activeAlertTargetSelection.add(url);
            else activeAlertTargetSelection.delete(url);
        });
        renderAlertTargetModal();
    });

    const label = document.createElement('span');
    label.className = 'target-tree-label';
    label.textContent = node.label;
    const count = document.createElement('span');
    count.className = 'target-tree-count';
    count.textContent = `${selectedCount}/${urls.length}`;
    row.appendChild(toggle);
    row.appendChild(checkbox);
    row.appendChild(label);
    row.appendChild(count);
    wrapper.appendChild(row);

    if (!isCollapsed) {
        const children = document.createElement('div');
        children.className = 'target-tree-children';
        (node.children || []).forEach(child => children.appendChild(renderTargetTreeNode(child)));
        wrapper.appendChild(children);
    }
    return wrapper;
}

function renderAlertsEditor(containerId, alerts = [], emptyText = "No alerts configured.", expandAlertId = null) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const normalized = normalizeAlerts(alerts);
    setAlertsForContainer(containerId, normalized);
    container.innerHTML = '';

    if (normalized.length === 0) {
        container.innerHTML = `<div class="alert-empty-state">${escapeHtml(emptyText)}</div>`;
        return;
    }

    normalized.forEach((alert, index) => {
        const card = document.createElement('div');
        card.className = 'alert-admin-card is-collapsed';
        card.dataset.alertId = alert.id;
        card.dataset.alertFingerprint = getAlertFingerprint(alert);
        const targetJson = escapeHtml(JSON.stringify(alert.targetUrls || []));
        card.innerHTML = `
            <div class="alert-admin-header">
                <button class="btn-icon alert-collapse-toggle" type="button" title="Expand Alert" aria-expanded="false">Expand</button>
                <div class="alert-admin-heading">
                    <div class="alert-admin-title">Alert ${index + 1}</div>
                    <div class="alert-admin-meta"></div>
                </div>
                <div class="alert-admin-actions">
                    <button class="btn-icon alert-move-up" type="button" title="Move Up">Up</button>
                    <button class="btn-icon alert-move-down" type="button" title="Move Down">Down</button>
                    <button class="btn btn-danger alert-delete" type="button" style="padding:4px 10px; font-size:11px;">Delete</button>
                </div>
            </div>
            <div class="alert-admin-body">
                <div class="alert-admin-grid">
                    <div>
                        <label>Title</label>
                        <input type="text" class="alert-title" value="${escapeHtml(alert.title)}" placeholder="Alert title">
                    </div>
                    <div>
                        <label>Severity</label>
                        <select class="alert-severity">
                            <option value="info" ${alert.severity === 'info' ? 'selected' : ''}>Info</option>
                            <option value="warning" ${alert.severity === 'warning' ? 'selected' : ''}>Warning</option>
                            <option value="critical" ${alert.severity === 'critical' ? 'selected' : ''}>Critical</option>
                        </select>
                    </div>
                    <div>
                        <label>Scope</label>
                        <select class="alert-scope">
                            <option value="global" ${alert.scope === 'global' ? 'selected' : ''}>Global</option>
                            <option value="page" ${alert.scope === 'page' ? 'selected' : ''}>Page Specific</option>
                        </select>
                    </div>
                    <div>
                        <label>Placement</label>
                        <select class="alert-placement">
                            <option value="sidebar" ${alert.placement === 'sidebar' ? 'selected' : ''}>Sidebar</option>
                            <option value="overlay" ${alert.placement === 'overlay' ? 'selected' : ''}>Overlay</option>
                        </select>
                    </div>
                    <div style="grid-column: 1 / -1;">
                        <label>Message</label>
                        <textarea class="alert-message" placeholder="Plain text message">${escapeHtml(alert.message)}</textarea>
                    </div>
                </div>
                <div class="alert-options-row">
                    <div class="check-group">
                        <input type="checkbox" class="alert-enabled" ${alert.enabled ? 'checked' : ''}>
                        <label>Enabled</label>
                    </div>
                    <div class="check-group">
                        <input type="checkbox" class="alert-dismissible" ${alert.dismissible ? 'checked' : ''}>
                        <label>Dismissible</label>
                    </div>
                    <div class="check-group">
                        <input type="checkbox" class="alert-reshow-on-edit" ${alert.reshowOnEdit ? 'checked' : ''}>
                        <label>Show Again After Edits</label>
                    </div>
                    <div>
                        <label>Starts At</label>
                        <input type="datetime-local" class="alert-start" value="${escapeHtml(alertValueForDateTimeInput(alert.startAt))}">
                    </div>
                    <div>
                        <label>Ends At</label>
                        <input type="datetime-local" class="alert-end" value="${escapeHtml(alertValueForDateTimeInput(alert.endAt))}">
                    </div>
                </div>
                <div class="alert-target-compact">
                    <label>Page Assignments</label>
                    <div class="field-note" style="margin-bottom: 10px;">Use the structured picker to assign this alert to one or more report/menu pages.</div>
                    <div class="alert-target-row">
                        <button class="btn btn-secondary alert-assign-pages" type="button">Assign Pages</button>
                        <span class="alert-target-summary"></span>
                    </div>
                    <input type="hidden" class="alert-target-urls" value="${targetJson}">
                    <input type="hidden" class="alert-dismiss-version" value="${escapeHtml(alert.dismissVersion)}">
                </div>
            </div>
        `;
        container.appendChild(card);
    });

    container.querySelectorAll('.alert-admin-card').forEach((card, index) => {
        updateAlertCardSummary(card, index);

        if (card.dataset.alertId === expandAlertId) setAlertCardExpanded(card, true);

        const toggle = card.querySelector('.alert-collapse-toggle');
        toggle?.addEventListener('click', () => {
            setAlertCardExpanded(card, card.classList.contains('is-collapsed'));
        });

        card.querySelector('.alert-assign-pages')?.addEventListener('click', () => openAlertTargetModal(card));
    });

    container.querySelectorAll('input, textarea, select').forEach(input => {
        const syncAlertState = () => {
            const card = input.closest('.alert-admin-card');
            updateAlertCardSummary(card, getAlertCardIndex(card));
            setAlertsForContainer(containerId, readAlertsFromContainer(containerId));
        };
        input.addEventListener('input', syncAlertState);
        input.addEventListener('change', syncAlertState);
    });

    container.querySelectorAll('.alert-delete').forEach((button, index) => {
        button.addEventListener('click', () => {
            const nextAlerts = readAlertsFromContainer(containerId);
            nextAlerts.splice(index, 1);
            renderAlertsEditor(containerId, nextAlerts, emptyText);
        });
    });

    container.querySelectorAll('.alert-move-up').forEach((button, index) => {
        button.addEventListener('click', () => {
            if (index === 0) return;
            const nextAlerts = readAlertsFromContainer(containerId);
            [nextAlerts[index - 1], nextAlerts[index]] = [nextAlerts[index], nextAlerts[index - 1]];
            renderAlertsEditor(containerId, nextAlerts, emptyText);
        });
    });

    container.querySelectorAll('.alert-move-down').forEach((button, index) => {
        button.addEventListener('click', () => {
            const nextAlerts = readAlertsFromContainer(containerId);
            if (index >= nextAlerts.length - 1) return;
            [nextAlerts[index + 1], nextAlerts[index]] = [nextAlerts[index], nextAlerts[index + 1]];
            renderAlertsEditor(containerId, nextAlerts, emptyText);
        });
    });
}

function renderGlobalAlerts(expandAlertId = null) {
    renderAlertsEditor('global-alerts-list', settingsData.globalAlerts || [], "No alerts configured.", expandAlertId);
}

function saveGlobalAlertsToData() {
    const container = document.getElementById('global-alerts-list');
    settingsData.globalAlerts = container ? readAlertsFromContainer('global-alerts-list') : normalizeAlerts(settingsData.globalAlerts || []);
}

function saveGlobalSettings() {
    settingsData.portalName = document.getElementById('set-portal-name').value;
    settingsData.defaultSide = document.getElementById('set-default-side').value;
    settingsData.showLayoutBtns = document.getElementById('set-show-layout').checked;
    settingsData.welcomeTitle = document.getElementById('set-welcome-title').value;
    settingsData.welcomeDesc = document.getElementById('set-welcome-desc').value;
    settingsData.approvedDomains = normalizeApprovedDomains(document.getElementById('set-approved-domains').value);
    settingsData.accessDeniedTitle = document.getElementById('set-access-denied-title').value;
    settingsData.accessDeniedMessage = document.getElementById('set-access-denied-message').value;
    settingsData.customCss = document.getElementById('set-custom-css').value;
    
    saveWelcomeStepsToData(); 
    saveGlobalAlertsToData();
    saveSecurityGroupsToData();
    renderAllowedGroups(selectedPath ? getSelectedAllowedGroups() : []);
    toast("Global Settings Saved to Memory (Don't forget to Publish!)");
}

function testIdentity() {
    const out = document.getElementById('dev-output');
    out.innerText = "Requesting identity from background script...";
    
    if (chrome && chrome.runtime) {
        chrome.runtime.sendMessage({ action: 'GET_USER_IDENTITY' }, (response) => {
            if (chrome.runtime.lastError) {
                out.innerText = "Error: " + chrome.runtime.lastError.message;
            } else {
                out.innerText = "Success!\n\n" + JSON.stringify(response, null, 2);
            }
        });
    } else {
        out.innerText = "Error: Extension APIs not available. Are you running this packed?";
    }
}

function testGroups() {
    const out = document.getElementById('dev-output');
    out.innerText = "Requesting group claims from captured Power BI/Fabric tokens...";
    
    if (chrome && chrome.runtime) {
        chrome.runtime.sendMessage({ action: 'GET_USER_GROUPS' }, (response) => {
            if (chrome.runtime.lastError) {
                out.innerText = "Error: " + chrome.runtime.lastError.message;
            } else {
                out.innerText = "Success!\n\n" + JSON.stringify(response, null, 2);
            }
        });
    } else {
        out.innerText = "Error: Extension APIs not available. Are you running this packed?";
    }
}

function cloneJson(value) {
    return JSON.parse(JSON.stringify(value ?? null));
}

function cleanMenuData(items = []) {
    return items.map(item => {
        const newItem = { ...item };
        delete newItem._expanded;
        delete newItem._moveId;
        if (newItem.items) newItem.items = cleanMenuData(newItem.items);
        return newItem;
    });
}

function flattenMenuItems(items = [], path = []) {
    const rows = [];
    items.forEach((item, index) => {
        const label = item.category || item.name || 'Untitled';
        const nextPath = [...path, label];
        rows.push({
            key: item.url ? `url:${item.url}` : `path:${nextPath.join(' > ')}:${index}`,
            json: JSON.stringify(item),
            allowedGroups: Array.isArray(item.allowedGroups) ? item.allowedGroups : []
        });
        if (Array.isArray(item.items)) rows.push(...flattenMenuItems(item.items, nextPath));
    });
    return rows;
}

function summarizeMenuChanges(beforeMenu, afterMenu) {
    const beforeRows = flattenMenuItems(beforeMenu);
    const afterRows = flattenMenuItems(afterMenu);
    const beforeMap = new Map(beforeRows.map(row => [row.key, row]));
    const afterMap = new Map(afterRows.map(row => [row.key, row]));
    let added = 0, removed = 0, changed = 0, restrictedAdded = 0, restrictedRemoved = 0;

    afterMap.forEach((afterRow, key) => {
        const beforeRow = beforeMap.get(key);
        if (!beforeRow) {
            added++;
            if (afterRow.allowedGroups.length > 0) restrictedAdded++;
            return;
        }
        if (beforeRow.json !== afterRow.json) changed++;
        if (beforeRow.allowedGroups.length === 0 && afterRow.allowedGroups.length > 0) restrictedAdded++;
        if (beforeRow.allowedGroups.length > 0 && afterRow.allowedGroups.length === 0) restrictedRemoved++;
    });
    beforeMap.forEach((beforeRow, key) => {
        if (!afterMap.has(key)) removed++;
    });

    return { added, removed, changed, restrictedAdded, restrictedRemoved, totalItems: afterRows.length };
}

function summarizeSettingsChanges(beforeSettings = {}, afterSettings = {}) {
    const keys = new Set([...Object.keys(beforeSettings || {}), ...Object.keys(afterSettings || {})]);
    const changedKeys = [];
    keys.forEach(key => {
        if (JSON.stringify(beforeSettings?.[key]) !== JSON.stringify(afterSettings?.[key])) changedKeys.push(key);
    });

    const beforeGroups = Array.isArray(beforeSettings.securityGroups) ? beforeSettings.securityGroups : [];
    const afterGroups = Array.isArray(afterSettings.securityGroups) ? afterSettings.securityGroups : [];
    const beforeGroupMap = new Map(beforeGroups.map(group => [group.id, group]));
    const afterGroupMap = new Map(afterGroups.map(group => [group.id, group]));
    let groupsChanged = 0;
    afterGroupMap.forEach((group, id) => {
        if (beforeGroupMap.has(id) && JSON.stringify(beforeGroupMap.get(id)) !== JSON.stringify(group)) groupsChanged++;
    });

    return {
        changedKeys,
        groupsAdded: afterGroups.filter(group => !beforeGroupMap.has(group.id)).length,
        groupsRemoved: beforeGroups.filter(group => !afterGroupMap.has(group.id)).length,
        groupsChanged,
        totalGroups: afterGroups.length,
        totalMembers: afterGroups.reduce((count, group) => count + (group.emails || []).length, 0)
    };
}

function makeTimestamp() {
    const pad = value => String(value).padStart(2, '0');
    const now = new Date();
    return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

function makeBackupPath(filePath, timestamp) {
    const cleanPath = String(filePath || '').replace(/^\/+/, '');
    const slashIndex = cleanPath.lastIndexOf('/');
    const folder = slashIndex >= 0 ? cleanPath.slice(0, slashIndex + 1) : '';
    const filename = slashIndex >= 0 ? cleanPath.slice(slashIndex + 1) : cleanPath;
    return `${folder}backups/${filename.replace(/\.json$/i, '')}-${timestamp}.json`;
}

function buildPublishPreview(menuSummary, settingsSummary, backupPaths) {
    return [
        'Publish preview',
        '',
        `Menu: ${menuSummary.added} added, ${menuSummary.removed} removed, ${menuSummary.changed} changed (${menuSummary.totalItems} total items).`,
        `Security rules: ${menuSummary.restrictedAdded} newly restricted, ${menuSummary.restrictedRemoved} opened back up.`,
        `Settings: ${settingsSummary.changedKeys.length} section(s) changed${settingsSummary.changedKeys.length ? ` (${settingsSummary.changedKeys.join(', ')})` : ''}.`,
        `Groups: ${settingsSummary.groupsAdded} added, ${settingsSummary.groupsRemoved} removed, ${settingsSummary.groupsChanged} changed (${settingsSummary.totalGroups} total groups, ${settingsSummary.totalMembers} total members).`,
        '',
        'Backups will be created before live files are overwritten:',
        `Menu backup: ${backupPaths.menu}`,
        backupPaths.settings ? `Settings backup: ${backupPaths.settings}` : 'Settings backup: skipped because no settings file is loaded yet.',
        '',
        'Continue publishing live to Power BI users?'
    ].join('\n');
}


// ==========================================
// GITHUB ACTIONS
// ==========================================
async function saveCreds() {
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const path = document.getElementById('gh-path').value.trim();
    const settingsPath = document.getElementById('gh-settings-path').value.trim();
    const token = document.getElementById('gh-token').value.trim();
    const branch = portalConfig.githubBranch || 'main';
    
    localStorage.setItem('gh_owner', owner);
    localStorage.setItem('gh_repo', repo);
    localStorage.setItem('gh_path', path);
    localStorage.setItem('gh_settings_path', settingsPath);
    sessionStorage.setItem('gh_token', token);
    localStorage.removeItem('gh_token');

    const statusEl = document.getElementById('gh-status');
    statusEl.innerHTML = '⏳ Testing Connection...';
    statusEl.className = 'status-msg active';
    
    if(!token || !owner || !repo) {
        statusEl.innerHTML = '❌ Missing Fields';
        statusEl.classList.add('error');
        return;
    }

    try {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
        const res = await fetch(`${url}?ref=${encodeURIComponent(branch)}&t=${new Date().getTime()}`, { 
            method: 'GET',
            headers: { Authorization: `token ${token}` } 
        });
        
        if(res.ok) {
            statusEl.innerHTML = '✅ Connection Verified!';
            statusEl.classList.add('success');
            setTimeout(() => {
               document.getElementById('details-settings').removeAttribute('open');
               statusEl.classList.remove('active');
            }, 1500);

            if (rootData.length === 0) loadFromCloud();
            else toast("Credentials Saved & Verified");
        } else {
            throw new Error(`GitHub Error: ${res.status} (${res.statusText})`);
        }
    } catch(e) {
        statusEl.innerHTML = `❌ Failed: ${e.message}`;
        statusEl.classList.add('error');
    }
}

async function loadFromCloud() {
    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const menuPath = document.getElementById('gh-path').value.trim();
    const settingsPath = document.getElementById('gh-settings-path').value.trim();
    const branch = portalConfig.githubBranch || 'main';

    if(!token || !owner) return toast("⚠️ Check Settings");

    toast("⏳ Loading Files...");
    
    const fetchGithubFile = async (filePath) => {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`;
        const res = await fetch(`${url}?ref=${encodeURIComponent(branch)}&t=${new Date().getTime()}`, { 
            headers: { Authorization: `token ${token}` } 
        });
        if (!res.ok) return null;
        return await res.json();
    };

    try {
        const [menuData, settingsResData] = await Promise.all([
            fetchGithubFile(menuPath),
            fetchGithubFile(settingsPath)
        ]);

        if (!menuData) throw new Error("Could not load Menu file.");
        
        currentMenuSha = menuData.sha;
        const menuJsonStr = decodeURIComponent(escape(window.atob(menuData.content)));
        const parsedMenu = JSON.parse(menuJsonStr);
        
        if (Array.isArray(parsedMenu)) {
            rootData = parsedMenu;
        } else if (parsedMenu.menu) {
            rootData = parsedMenu.menu;
            if (!settingsResData && parsedMenu.settings) {
                settingsData = parsedMenu.settings; 
            }
        }

        if (settingsResData) {
            currentSettingsSha = settingsResData.sha;
            const settingsJsonStr = decodeURIComponent(escape(window.atob(settingsResData.content)));
            const parsedSettings = JSON.parse(settingsJsonStr);
            settingsData = { ...settingsData, ...parsedSettings };
            settingsData.approvedDomains = normalizeApprovedDomains(settingsData.approvedDomains || []);
            settingsData.globalAlerts = normalizeAlerts(settingsData.globalAlerts || []);
        } else {
            console.log("Settings file not found. A new one will be created on publish.");
            currentSettingsSha = null; 
        }

        loadedMenuSnapshot = cloneJson(cleanMenuData(rootData));
        loadedSettingsSnapshot = cloneJson(settingsData);
        migratePageAlertsIntoSettings();
        
        populateGlobalSettingsUI();
        renderTree();
        toast("✅ Loaded Both Files");
        
        document.getElementById('editor-ui').style.display = 'none';
        document.getElementById('empty-msg').style.display = 'flex';

    } catch(e) {
        alert("Load Error: " + e.message);
    }
}

async function publishToCloud() {
    if(!currentMenuSha) return alert("You must LOAD first before publishing.");
    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const menuPath = document.getElementById('gh-path').value.trim();
    const settingsPath = document.getElementById('gh-settings-path').value.trim();
    const branch = portalConfig.githubBranch || 'main';

    toast("⏳ Publishing...");
    
    saveSecurityGroupsToData();
    saveGlobalAlertsToData();
    const finalMenuArray = cleanMenuData(rootData);
    const finalSettingsData = cloneJson(settingsData);
    const timestamp = makeTimestamp();
    const backupPaths = {
        menu: makeBackupPath(menuPath, timestamp),
        settings: currentSettingsSha ? makeBackupPath(settingsPath, timestamp) : null
    };
    const menuSummary = summarizeMenuChanges(loadedMenuSnapshot, finalMenuArray);
    const settingsSummary = summarizeSettingsChanges(loadedSettingsSnapshot, finalSettingsData);

    if (!confirm(buildPublishPreview(menuSummary, settingsSummary, backupPaths))) return;

    const pushFile = async (filePath, contentObj, fileSha) => {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`;
        const contentStr = JSON.stringify(contentObj, null, 2);
        const encoded = window.btoa(unescape(encodeURIComponent(contentStr)));

        const payload = { message: "Update via Admin Tool", content: encoded, branch };
        if (fileSha) payload.sha = fileSha;

        const res = await fetch(url, {
            method: 'PUT',
            headers: { Authorization: `token ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        if(!res.ok) throw new Error(res.statusText);
        return await res.json();
    };

    const pushBackup = async (filePath, contentObj, sourcePath) => {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`;
        const contentStr = JSON.stringify(contentObj, null, 2);
        const encoded = window.btoa(unescape(encodeURIComponent(contentStr)));
        const res = await fetch(url, {
            method: 'PUT',
            headers: { Authorization: `token ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: `Backup ${sourcePath} before Admin Tool publish`,
                content: encoded,
                branch
            })
        });

        if(!res.ok) throw new Error(`Backup failed for ${filePath}: ${res.statusText}`);
        return await res.json();
    };

    try {
        toast("Creating backups...");
        await pushBackup(backupPaths.menu, loadedMenuSnapshot, menuPath);
        if (backupPaths.settings) await pushBackup(backupPaths.settings, loadedSettingsSnapshot, settingsPath);

        toast("Publishing...");
        const menuResult = await pushFile(menuPath, finalMenuArray, currentMenuSha);
        currentMenuSha = menuResult.content.sha;

        const settingsResult = await pushFile(settingsPath, finalSettingsData, currentSettingsSha);
        currentSettingsSha = settingsResult.content.sha;
        loadedMenuSnapshot = cloneJson(finalMenuArray);
        loadedSettingsSnapshot = cloneJson(finalSettingsData);

        toast("🚀 Published Both Files Successfully!");
    } catch(e) {
        alert("Publish Error: " + e.message);
    }
}

// ==========================================
// TREE RENDERER
// ==========================================
function renderTree() {
    const container = document.getElementById('tree-root');
    container.innerHTML = '';

    function buildNode(item, path) {
        const wrapper = document.createElement('div');
        if (item._expanded) wrapper.className = 'expanded';

        const nodeDiv = document.createElement('div');
        const isSel = selectedPath && JSON.stringify(path) === JSON.stringify(selectedPath);
        const isFolder = item.items !== undefined || item.type === 'workspace';
        const hasKids = isFolder && item.items && item.items.length > 0;

        let classes = 'node ' + (isSel ? 'selected' : '');
        if (item.inDevelopment === true) classes += ' dev-flag';
        nodeDiv.className = classes;
        nodeDiv.draggable = true;
        
        if (item.isHidden) nodeDiv.style.opacity = '0.4';
        
        const label = item.category || item.name || 'Untitled';
        
        const arrowSpan = document.createElement('span');
        arrowSpan.className = 'toggle-icon';
        arrowSpan.style.pointerEvents = 'auto'; 
        arrowSpan.style.marginRight = '5px';
        
        if (isFolder && item.type !== 'workspace') {
            arrowSpan.innerText = item._expanded ? '▼' : '▶'; 
            arrowSpan.onclick = (e) => {
                e.stopPropagation(); 
                item._expanded = !item._expanded;
                if (item._expanded) {
                    wrapper.classList.add('expanded');
                    arrowSpan.innerText = '▼';
                } else {
                    wrapper.classList.remove('expanded');
                    arrowSpan.innerText = '▶';
                }
            };
        } else {
            arrowSpan.innerText = ''; 
        }

        let iconChar = '🔗';
        if (item.type === 'workspace') iconChar = '☁️';
        else if (isFolder) iconChar = '📁';
        else if (item.linkType === 'excel') iconChar = '📗';
        
        if (item.inDevelopment === true) iconChar = '🚧 ' + iconChar;

        const textSpan = document.createElement('span');
        textSpan.innerText = `${iconChar} ${label}`;
        
        if (isFolder && item.color) {
            textSpan.style.color = item.color;
        }

        nodeDiv.appendChild(arrowSpan);
        nodeDiv.appendChild(textSpan);
        if (Array.isArray(item.allowedGroups) && item.allowedGroups.length > 0) {
            const securityIcon = document.createElement('span');
            securityIcon.className = 'security-indicator';
            securityIcon.title = `Restricted to ${item.allowedGroups.length} security group${item.allowedGroups.length === 1 ? '' : 's'}`;
            securityIcon.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"></rect><path d="M8 11V7a4 4 0 0 1 8 0v4"></path></svg>';
            nodeDiv.appendChild(securityIcon);
        }

        if (isFolder && item.type !== 'workspace') {
            const actionsDiv = document.createElement('div');
            actionsDiv.className = 'node-actions';
            
            const plusBtn = document.createElement('div');
            plusBtn.className = 'action-btn btn-plus';
            plusBtn.title = "Add Child Item";
            
            const expandGroup = document.createElement('div');
            expandGroup.style.display = 'none';
            expandGroup.style.gap = '4px';

            const addLinkBtn = document.createElement('div');
            addLinkBtn.className = 'action-btn btn-add-link';
            addLinkBtn.title = "Add Link";
            
            const addFolderBtn = document.createElement('div');
            addFolderBtn.className = 'action-btn btn-add-folder';
            addFolderBtn.title = "Add Folder";

            plusBtn.onclick = (e) => {
                e.stopPropagation();
                plusBtn.style.display = 'none';
                expandGroup.style.display = 'flex';
                expandGroup.classList.add('actions-expanded');
                actionsDiv.classList.add('active'); 
            };

            addLinkBtn.onclick = (e) => { e.stopPropagation(); addItemToPath(path, 'report'); };
            addFolderBtn.onclick = (e) => { e.stopPropagation(); addItemToPath(path, 'folder'); };

            expandGroup.appendChild(addFolderBtn);
            expandGroup.appendChild(addLinkBtn);
            actionsDiv.appendChild(plusBtn);
            actionsDiv.appendChild(expandGroup);

            nodeDiv.addEventListener('mouseleave', () => {
                plusBtn.style.display = 'flex';
                expandGroup.style.display = 'none';
                actionsDiv.classList.remove('active');
            });
            nodeDiv.appendChild(actionsDiv);
        }

        nodeDiv.addEventListener('click', (e) => { e.stopPropagation(); select(path); });

        // --- DRAG EVENTS ---
        nodeDiv.addEventListener('dragstart', (e) => {
            e.stopPropagation(); dragSrcPath = path; e.dataTransfer.effectAllowed = 'move';
            nodeDiv.style.opacity = '0.5';
        });

        nodeDiv.addEventListener('dragend', () => { 
            nodeDiv.style.opacity = item.isHidden ? '0.4' : '1'; 
            clearDragClasses(); 
        });

        nodeDiv.addEventListener('dragover', (e) => {
            e.preventDefault(); e.stopPropagation(); clearDragClasses();
            const rect = nodeDiv.getBoundingClientRect();
            const relY = e.clientY - rect.top;
            const height = rect.height;
            
            if (relY < height * 0.25) {
                nodeDiv.classList.add('drop-above'); nodeDiv.style.borderTop = "2px solid #9575cd";
            } else if (relY > height * 0.75) {
                nodeDiv.classList.add('drop-below'); nodeDiv.style.borderBottom = "2px solid #9575cd";
            } else {
                if (isFolder && item.type !== 'workspace') { nodeDiv.classList.add('drop-inside'); nodeDiv.style.background = "rgba(149, 117, 205, 0.3)"; } 
                else { nodeDiv.classList.add('drop-below'); nodeDiv.style.borderBottom = "2px solid #9575cd"; }
            }
        });

        nodeDiv.addEventListener('dragleave', () => clearDragClasses());

        nodeDiv.addEventListener('drop', (e) => {
            e.stopPropagation(); e.preventDefault();
            let action = 'inside';
            if (nodeDiv.classList.contains('drop-above')) action = 'above';
            else if (nodeDiv.classList.contains('drop-below')) action = 'below';
            clearDragClasses(); handleDrop(path, action);
        });

        wrapper.appendChild(nodeDiv);
        if(hasKids) {
            const kidsBox = document.createElement('div');
            kidsBox.className = 'children'; 
            item.items.forEach((k, i) => kidsBox.appendChild(buildNode(k, [...path, i])));
            wrapper.appendChild(kidsBox);
        }
        return wrapper;
    }

    rootData.forEach((item, i) => container.appendChild(buildNode(item, [i])));
}

function clearDragClasses() {
    document.querySelectorAll('.node').forEach(el => {
        el.style.borderTop = "none"; el.style.borderBottom = "none";
        if (!el.classList.contains('selected')) el.style.background = "";
        else el.style.background = "rgba(149, 117, 205, 0.15)";
        el.classList.remove('drop-above', 'drop-below', 'drop-inside');
    });
}

function handleDrop(targetPath, action) {
    if (!dragSrcPath) return;
    if (JSON.stringify(dragSrcPath) === JSON.stringify(targetPath)) return;

    let srcParent = rootData;
    if (dragSrcPath.length > 1) {
        for(let i=0; i<dragSrcPath.length-1; i++) srcParent = srcParent[dragSrcPath[i]].items;
    }
    const srcIndex = dragSrcPath[dragSrcPath.length-1];
    const itemToMove = srcParent[srcIndex];

    const uniqueId = Date.now() + Math.random();
    itemToMove._moveId = uniqueId;
    
    const clonedItem = JSON.parse(JSON.stringify(itemToMove));
    delete clonedItem._moveId; 

    let destNode = rootData[targetPath[0]];
    for(let i=1; i<targetPath.length; i++) destNode = destNode.items[targetPath[i]];

    let isBecomingRoot = false;

    if (action === 'inside') {
        if(!destNode.items) destNode.items = [];
        destNode.items.push(clonedItem);
        destNode._expanded = true;
    } else {
        if (targetPath.length === 1) isBecomingRoot = true;
        
        let destParent = rootData;
        if (targetPath.length > 1) {
            for(let i=0; i<targetPath.length-1; i++) destParent = destParent[targetPath[i]].items;
        }
        const destIndex = targetPath[targetPath.length-1];
        const insertAt = action === 'above' ? destIndex : destIndex + 1;
        destParent.splice(insertAt, 0, clonedItem);
    }

    if (isBecomingRoot) {
        if (clonedItem.name && !clonedItem.category) { clonedItem.category = clonedItem.name; delete clonedItem.name; }
    } else {
        if (clonedItem.category && !clonedItem.name) { clonedItem.name = clonedItem.category; delete clonedItem.category; }
    }

    deleteById(rootData, uniqueId);
    delete itemToMove._moveId; 
    dragSrcPath = null; selectedPath = null;
    renderTree(); toast("Moved & Saved State");
}

function deleteById(items, id) {
    for (let i = 0; i < items.length; i++) {
        if (items[i]._moveId === id) { items.splice(i, 1); return true; }
        if (items[i].items) { if (deleteById(items[i].items, id)) return true; }
    }
    return false;
}

// ==========================================
// EDITOR ACTIONS
// ==========================================
function select(path) {
    selectedPath = path;
    activateTab('view-editor');
    renderTree();
    
    let node = getSelectedNode();
    if (!node) return;

    document.getElementById('editor-ui').style.display = 'block';
    document.getElementById('empty-msg').style.display = 'none';
    
    let typeVal = 'report';
    if (node.type === 'workspace') typeVal = 'workspace';
    else if (node.items !== undefined) typeVal = 'folder';
    
    document.getElementById('inp-type').value = typeVal;
    document.getElementById('inp-name').value = node.category || node.name || "";
    document.getElementById('inp-url').value = node.url || "";
    document.getElementById('inp-page-css').value = node.pageCss || "";
    document.getElementById('inp-folder-url').value = node.folderUrl || "";
    document.getElementById('inp-workspace-id').value = node.workspaceId || "personal";
    document.getElementById('inp-hidden').checked = node.isHidden === true;
    
    const linkTypeEl = document.getElementById('inp-link-type');
    if (linkTypeEl) linkTypeEl.value = node.linkType || 'report';
    
    const devBox = document.getElementById('inp-dev');
    if (devBox) devBox.checked = node.inDevelopment === true;
    
    // Check our new Allow Build checkbox
    const buildBox = document.getElementById('inp-allow-build');
    if (buildBox) buildBox.checked = node.allowBuild === true;
    
    const newTabBox = document.getElementById('inp-new-tab');
    if (newTabBox) newTabBox.checked = node.openNewTab === true;

    const colorBox = document.getElementById('inp-folder-color');
    if (colorBox) colorBox.value = node.color || "#aea0c0";
    renderAllowedGroups(node.allowedGroups || []);
    
    toggleUI();
}

function updateItem() {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const node = parent[index];
    const name = document.getElementById('inp-name').value;
    const type = document.getElementById('inp-type').value;

    if(selectedPath.length === 1) { 
        node.category = name; delete node.name; 
    } else { 
        node.name = name; delete node.category; 
    }

    node.isHidden = document.getElementById('inp-hidden').checked;
    node.type = type;
    const allowedGroups = getSelectedAllowedGroups();
    if (allowedGroups.length > 0) node.allowedGroups = allowedGroups;
    else delete node.allowedGroups;

    if(type === 'report') {
        node.url = document.getElementById('inp-url').value.trim();
        node.linkType = document.getElementById('inp-link-type').value;
        node.inDevelopment = document.getElementById('inp-dev').checked;
        node.allowBuild = document.getElementById('inp-allow-build').checked;
        node.openNewTab = document.getElementById('inp-new-tab').checked;
        node.pageCss = document.getElementById('inp-page-css').value;
        
        delete node.items; delete node.color; delete node.folderUrl; delete node.workspaceId;
    } else if (type === 'workspace') {
        node.workspaceId = document.getElementById('inp-workspace-id').value;
        node.folderUrl = document.getElementById('inp-folder-url').value.trim();
        const colorVal = document.getElementById('inp-folder-color').value;
        
        if (colorVal !== "#aea0c0") node.color = colorVal; else delete node.color;
        
        node.items = []; 
        delete node.url; delete node.linkType; delete node.inDevelopment; delete node.allowBuild; delete node.openNewTab; delete node.pageCss; delete node.pageAlerts;
    } else { // folder
        node.folderUrl = document.getElementById('inp-folder-url').value.trim();
        const colorVal = document.getElementById('inp-folder-color').value;
        if (colorVal !== "#aea0c0") node.color = colorVal;
        else delete node.color;
        
        if(!node.items) node.items = [];
        
        delete node.url; delete node.linkType; delete node.inDevelopment; delete node.allowBuild; delete node.openNewTab; delete node.pageCss; delete node.pageAlerts; delete node.workspaceId;
    }
    
    if(!node.isHidden) delete node.isHidden; 
    
    renderTree();
    toast("Saved Successfully");
}

function addItem(isRoot, type) {
    if(isRoot) {
        rootData.push({ category: "New Root", items: [] });
        select([rootData.length-1]);
    } else {
        if (!selectedPath) return toast("Select a folder first");
        addItemToPath(selectedPath, type);
    }
}

function addItemToPath(parentPath, type) {
    let node = rootData[parentPath[0]];
    for(let i=1; i<parentPath.length; i++) node = node.items[parentPath[i]];
    if(!node.items) node.items = [];
    node._expanded = true;

    const newItem = type === 'folder' 
        ? { name: "New Folder", items: [] } 
        : { name: "New Link", url: "", linkType: "report" };
            
    const newIndex = node.items.push(newItem) - 1;
    const newPath = [...parentPath, newIndex];
    renderTree(); select(newPath); toast(`Added new ${type}`);
}

function deleteItem() {
    if(!confirm("Are you sure you want to delete this item?")) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    parent.splice(index, 1);
    selectedPath = null;
    
    document.getElementById('editor-ui').style.display = 'none';
    document.getElementById('empty-msg').style.display = 'flex';
    renderTree(); toast("Item Deleted");
}

function moveItem(dir) {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const newIdx = index + dir;
    if(newIdx >= 0 && newIdx < parent.length) {
        [parent[index], parent[newIdx]] = [parent[newIdx], parent[index]];
        selectedPath[selectedPath.length-1] = newIdx;
        renderTree();
    }
}

function getParentAndIndex(path) {
    let parent = rootData;
    if(path.length > 1) { for(let i=0; i<path.length-1; i++) parent = parent[path[i]].items; }
    return { parent, index: path[path.length-1] };
}

function getSelectedNode() {
    if (!selectedPath) return null;
    let node = rootData[selectedPath[0]];
    for (let i = 1; i < selectedPath.length; i++) {
        if (!node || !Array.isArray(node.items)) return null;
        node = node.items[selectedPath[i]];
    }
    return node || null;
}

function toggleUI() {
    const type = document.getElementById('inp-type').value;
    document.getElementById('box-url').style.display = type === 'report' ? 'grid' : 'none';
    document.getElementById('box-folder').style.display = (type === 'folder' || type === 'workspace') ? 'grid' : 'none';
    document.getElementById('box-workspace').style.display = type === 'workspace' ? 'grid' : 'none';
}

function toast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg; t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 3000);
}
