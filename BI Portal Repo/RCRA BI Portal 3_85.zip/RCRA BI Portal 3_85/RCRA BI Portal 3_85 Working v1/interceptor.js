// ==================================================
// interceptor.js
// ==================================================
(function() {
    if (window.rcraTokenInterceptorLoaded) return;
    window.rcraTokenInterceptorLoaded = true;

    console.log("RCRA: Token Interceptor Injected into MAIN world!");
    const BRIDGE_SOURCE = 'RCRA_BI_PORTAL_TOKEN_BRIDGE_V1';
    
    function captureToken(headerValue, urlStr) {
        if (!headerValue || !headerValue.startsWith('Bearer ')) return;
        const url = (urlStr || '').toLowerCase();
        const cleanToken = headerValue.replace('Bearer ', '');
        
        // Split tokens based on their destination API to prevent Audience Mismatch 403s
        if (url.includes('fabric.microsoft.com')) {
            window.postMessage({ source: BRIDGE_SOURCE, action: 'RCRA_FABRIC_TOKEN', token: cleanToken }, window.location.origin);
        } else if (url.includes('powerbi.com') || url.includes('analysis.windows.net')) {
            window.postMessage({ source: BRIDGE_SOURCE, action: 'RCRA_PBI_TOKEN', token: cleanToken }, window.location.origin);
        }
    }
    
    // Hijack Fetch API
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        try {
            const [resource, config] = args;
            const url = typeof resource === 'string' ? resource : (resource && resource.url ? resource.url : '');
            if (config && config.headers) {
                let authHeader = null;
                if (config.headers instanceof Headers) {
                    authHeader = config.headers.get('Authorization');
                } else if (typeof config.headers === 'object') {
                    const authKey = Object.keys(config.headers).find(k => k.toLowerCase() === 'authorization');
                    if (authKey) authHeader = config.headers[authKey];
                }
                captureToken(authHeader, url);
            }
        } catch(e) {} 
        return originalFetch.apply(this, args);
    };
    
    // Hijack XMLHttpRequest
    const originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        this._rcraUrl = url;
        return originalOpen.apply(this, arguments);
    };

    const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
        try {
            if (header.toLowerCase() === 'authorization') {
                captureToken(value, this._rcraUrl);
            }
        } catch(e) {}
        return originalSetRequestHeader.apply(this, arguments);
    };
})();
